// 音の加工（js/sound-effects.js）のテスト。
//   第1部: 数値検証（ブラウザ不要。js/sound-core.js と js/sound-effects.js を Node で読み込む）
//   第2部: 画面操作（実ブラウザ。FX_UNIT_ONLY=1 のときは実行しない）
// 実行例: node tests/sound-effects.mjs          （第2部は プロジェクトのルートを配信しておく）
import assert from "node:assert/strict";
import fs from "node:fs";
import vm from "node:vm";
import { fileURLToPath } from "node:url";
import path from "node:path";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
globalThis.window = globalThis;
for (const f of ["sound-core.js", "sound-effects.js"])
  vm.runInThisContext(fs.readFileSync(path.join(root, "js", f), "utf8"), { filename: f });
const fx = PaintAudio.fx;

const checks = [];
async function check(name, fn) {
  await fn();
  checks.push(name);
  console.log("PASS", name);
}
const SR = 44100;
const mono = (n, f) => ({ sampleRate: SR, channels: [Float32Array.from({ length: n }, (_, i) => f(i))] });
const rms = (c, a = 0, b = c.length) => {
  let s = 0;
  for (let i = a; i < b; i++) s += c[i] * c[i];
  return Math.sqrt(s / (b - a));
};
const peak = (c) => c.reduce((m, v) => Math.max(m, Math.abs(v)), 0);
const near = (a, b, tol, msg) => assert.ok(Math.abs(a - b) <= tol, `${msg || ""} ${a} ≠ ${b} (±${tol})`);
const run = (name, pcm, params) => fx.run(name, pcm, params).promise;
const db = (v) => 20 * Math.log10(v);
let seed = 7;
const rnd = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296) * 2 - 1;

// ------------------------------------------------------------------ 第1部
await check("定義済みの加工が14種類そろっている", () => {
  assert.deepEqual(
    [...fx.names].sort(),
    ["crush", "distort", "echo", "fadeIn", "fadeOut", "filter", "gain", "normalize", "reverb", "reverse", "robot", "silence", "tremolo", "vibrato"].sort(),
  );
});

await check("フェードイン: 先頭0・末尾は元のまま・直線的に増える（全体／秒指定）", async () => {
  const one = mono(1001, () => 1);
  const r = (await run("fadeIn", one, { seconds: 0 })).channels[0];
  assert.equal(r.length, 1001);
  assert.equal(r[0], 0);
  assert.equal(r[1000], 1);
  near(r[500], 0.5, 1e-6, "中央");
  for (let i = 1; i < r.length; i++) assert.ok(r[i] >= r[i - 1]);
  const long = mono(SR, () => 1); // 1秒。先頭0.25秒だけフェード
  const q = (await run("fadeIn", long, { seconds: 0.25 })).channels[0];
  const L = Math.round(0.25 * SR);
  assert.equal(q[0], 0);
  near(q[L - 1], 1, 1e-6);
  assert.ok(q.subarray(L).every((v) => v === 1), "フェード後は元のまま");
  const over = (await run("fadeIn", one, { seconds: 99 })).channels[0]; // 長すぎる指定は全体に収まる
  assert.equal(over[0], 0);
  assert.equal(over[1000], 1);
});

await check("フェードアウト: 末尾0・先頭は元のまま・直線的に減る", async () => {
  const one = mono(1001, () => 1);
  const r = (await run("fadeOut", one, { seconds: 0 })).channels[0];
  assert.equal(r[0], 1);
  assert.equal(r[1000], 0);
  near(r[500], 0.5, 1e-6);
  const long = mono(SR, () => 1);
  const q = (await run("fadeOut", long, { seconds: 0.25 })).channels[0];
  const L = Math.round(0.25 * SR);
  assert.ok(q.subarray(0, SR - L).every((v) => v === 1));
  assert.equal(q[SR - 1], 0);
});

await check("逆再生: 並びが逆になり、2回かけると元に戻る（ステレオも左右別々）", async () => {
  const st = { sampleRate: SR, channels: [Float32Array.from([1, 2, 3, 4]), Float32Array.from([-1, -2, -3, -4])] };
  const r = await run("reverse", st);
  assert.deepEqual([...r.channels[0]], [4, 3, 2, 1]);
  assert.deepEqual([...r.channels[1]], [-4, -3, -2, -1]);
  const back = await run("reverse", r);
  assert.deepEqual([...back.channels[0]], [1, 2, 3, 4]);
});

await check("ノーマライズ: 最大音量が −1 dB になる／無音は拒否", async () => {
  const r = await run("normalize", mono(1000, (i) => 0.2 * Math.sin(i / 7)));
  near(peak(r.channels[0]), 10 ** (-1 / 20), 1e-4);
  await assert.rejects(run("normalize", mono(100, () => 0)), /無音/);
});

await check("音量: +6dBで約2倍・−6dBで約半分・上限を超えたら音割れを知らせる", async () => {
  const base = mono(100, () => 0.25);
  near((await run("gain", base, { db: 6 })).channels[0][0], 0.25 * 10 ** (6 / 20), 1e-6);
  near((await run("gain", base, { db: -6 })).channels[0][0], 0.25 * 10 ** (-6 / 20), 1e-6);
  const job = fx.run("gain", mono(100, () => 0.9), { db: 12 });
  const out = await job.promise;
  assert.equal(peak(out.channels[0]), 1);
  assert.ok(job.notes.some((n) => /音割れ/.test(n)));
});

await check("無音化: 長さそのままで全部0", async () => {
  const r = await run("silence", mono(500, () => 0.7));
  assert.equal(r.channels[0].length, 500);
  assert.equal(peak(r.channels[0]), 0);
});

await check("エコー: 間隔どおりに 0.5 → 0.25 → 0.125 と減衰し、余韻のぶん長くなる", async () => {
  const D = Math.round(0.1 * SR);
  const imp = mono(SR, (i) => (i === 0 ? 1 : 0));
  const r = (await run("echo", imp, { delayMs: 100, decay: 50, level: 50 })).channels[0];
  assert.ok(r.length > imp.channels[0].length, "余韻のぶん長い");
  near(r[0], 1, 1e-6, "原音");
  near(r[D], 0.5, 1e-6, "1回目");
  near(r[2 * D], 0.25, 1e-6, "2回目");
  near(r[3 * D], 0.125, 1e-6, "3回目");
  near(r[D + 5], 0, 1e-9, "エコーの間は無音");
  assert.equal(r[r.length - 1], 0, "末尾はぶつっと切れない");
});

await check("エコー: 入力は書き換えない／音割れしない／左右が別々に処理される", async () => {
  // 入力(0.45秒)を間隔(50ms)より長くして、原音とエコーが重なるようにする
  const src = { sampleRate: SR, channels: [Float32Array.from({ length: 20000 }, () => 1), new Float32Array(20000)] };
  const before = src.channels[0].slice();
  const job = fx.run("echo", src, { delayMs: 50, decay: 90, level: 100 });
  const r = await job.promise;
  assert.deepEqual(src.channels[0], before, "入力が変わっていない");
  assert.ok(peak(r.channels[0]) <= 1 + 1e-6, "音割れしない");
  assert.ok(job.notes.some((n) => /音割れ/.test(n)));
  assert.equal(peak(r.channels[1]), 0, "無音の右チャンネルは無音のまま");
  assert.equal(r.channels[0].length, r.channels[1].length);
});

await check("リバーブ: 余韻で長くなり減衰する／強さ0なら原音のまま", async () => {
  const noise = mono(SR, () => 0.3 * rnd());
  const r = (await run("reverb", noise, { room: 50, level: 30 })).channels[0];
  assert.ok(r.length > SR + 0.5 * SR, "余韻が付く");
  const after = rms(r, SR, SR + 4410), late = rms(r, r.length - 8820, r.length - 4410);
  assert.ok(after > 0.01 && late < after * 0.2, `余韻が減衰する (${after} → ${late})`);
  assert.equal(r[r.length - 1], 0);
  const dry = (await run("reverb", noise, { room: 80, level: 0 })).channels[0];
  for (let i = 0; i < SR; i += 997) assert.equal(dry[i], noise.channels[0][i]);
  const small = (await run("reverb", noise, { room: 0, level: 50 })).channels[0].length;
  const big = (await run("reverb", noise, { room: 100, level: 50 })).channels[0].length;
  assert.ok(big > small, "広いほど余韻が長い");
});

await check("フィルター: ローパス/ハイパス/バンドパスが周波数どおりに効く", async () => {
  const tone = (f) => mono(SR, (i) => 0.5 * Math.sin((2 * Math.PI * f * i) / SR));
  const gainAt = async (type, freq, tone_f) => {
    const out = (await run("filter", tone(tone_f), { type, freq })).channels[0];
    return rms(out, SR / 2, SR) / rms(tone(tone_f).channels[0], SR / 2, SR); // 定常部分の比
  };
  const lowKeep = await gainAt("lowpass", 1000, 100), lowCut = await gainAt("lowpass", 1000, 8000);
  assert.ok(lowKeep > 0.95, `LP: 100Hzは通る ${lowKeep}`);
  assert.ok(db(lowCut) < -30, `LP: 8kHzは大きく減る ${db(lowCut).toFixed(1)}dB`);
  const hiKeep = await gainAt("highpass", 1000, 8000), hiCut = await gainAt("highpass", 1000, 100);
  assert.ok(hiKeep > 0.95, `HP: 8kHzは通る ${hiKeep}`);
  assert.ok(db(hiCut) < -30, `HP: 100Hzは大きく減る ${db(hiCut).toFixed(1)}dB`);
  const bpMid = await gainAt("bandpass", 1000, 1000);
  assert.ok(bpMid > 0.9, `BP: 中心は通る ${bpMid}`);
  assert.ok(db(await gainAt("bandpass", 1000, 100)) < -15 && db(await gainAt("bandpass", 1000, 10000)) < -15, "BP: 両端は減る");
});

await check("ロボット声/ビブラート/トレモロ/ひずみ/8bit風: 長さ維持・意図どおりの変化", async () => {
  const dc = mono(SR, () => 0.5);
  const sine = mono(SR, (i) => 0.5 * Math.sin((2 * Math.PI * 440 * i) / SR));
  const robot = (await run("robot", dc, { amount: 100 })).channels[0];
  near(rms(robot), 0.5 * Math.SQRT1_2, 0.01, "ロボット(リング変調)");
  near(rms((await run("robot", sine, { amount: 1 })).channels[0]), rms(sine.channels[0]), 0.01, "強さ最小はほぼ原音");
  const vib = (await run("vibrato", dc, { amount: 100 })).channels[0];
  assert.equal(vib.length, SR);
  assert.ok(vib.subarray(1000).every((v) => Math.abs(v - 0.5) < 1e-6), "定数の音は揺らしても変わらない");
  const vs = (await run("vibrato", sine, { amount: 100 })).channels[0];
  assert.ok(rms(vs.map((v, i) => v - sine.channels[0][i])) > 0.01, "音は実際に揺れている");
  const trem = (await run("tremolo", mono(SR, () => 1), { amount: 100 })).channels[0];
  near(Math.min(...trem), 0, 1e-3, "最小");
  near(Math.max(...trem), 1, 1e-3, "最大");
  const dist = (await run("distort", sine, { amount: 100 })).channels[0];
  assert.ok(peak(dist) <= 1 + 1e-6);
  assert.ok(rms(dist) > rms(sine.channels[0]) * 1.5, "ひずませると音が太くなる");
  const crush = (await run("crush", sine, { amount: 100 })).channels[0];
  const kinds = new Set(crush).size;
  assert.ok(kinds <= 2 ** 3 + 1, `3bit相当の段数 (${kinds})`);
  assert.ok(new Set((await run("crush", sine, { amount: 1 })).channels[0]).size > kinds * 4, "弱ければ細かい");
});

await check("引数の補正: 範囲外・空・不正な値でも安全な値になる", () => {
  const n = fx.normalize("echo", { delayMs: 99999, decay: -5, level: "abc" });
  assert.deepEqual(n, { delayMs: 2000, decay: 5, level: 50 });
  assert.equal(fx.normalize("filter", { type: "evil", freq: "" }).type, "lowpass");
  assert.equal(fx.normalize("filter", { type: "evil", freq: "" }).freq, 1000);
  assert.equal(fx.normalize("fadeIn", { seconds: null }).seconds, 0);
  assert.throws(() => fx.normalize("nope"), /未対応/);
});

await check("10分を超える結果は拒否される（余韻で超える場合も）", async () => {
  const long = { sampleRate: 8000, channels: [new Float32Array(8000 * 599)] };
  await assert.rejects(run("echo", long, { delayMs: 2000, decay: 90, level: 100 }), /10分/);
});

await check("キャンセル: 処理中でも素早く AbortError で止まる／進捗は0〜99%", async () => {
  const big = { sampleRate: SR, channels: [new Float32Array(SR * 120), new Float32Array(SR * 120)] };
  const seen = [];
  const job = fx.run("reverb", big, { room: 80, level: 50 }, (p) => seen.push(p));
  await new Promise((r) => setTimeout(r, 60));
  const t0 = Date.now();
  job.cancel();
  await assert.rejects(job.promise, (e) => e.name === "AbortError");
  assert.ok(Date.now() - t0 < 300, "すぐ止まる");
  assert.ok(seen.length > 0 && seen.every((p) => p >= 0 && p <= 99), `進捗 ${seen.slice(0, 5)}…`);
  assert.ok(seen.every((p, i) => i === 0 || p >= seen[i - 1]), "進捗は戻らない");
});

await check("処理中も画面が固まらない（長い音でも処理を譲りながら進む）", async () => {
  const big = { sampleRate: SR, channels: [new Float32Array(SR * 60), new Float32Array(SR * 60)] };
  let ticks = 0;
  const timer = setInterval(() => ticks++, 5);
  await run("reverb", big, { room: 50, level: 30 });
  clearInterval(timer);
  assert.ok(ticks >= 5, `処理中にタイマーが動いた回数 ${ticks}`);
});

console.log(`\nPASS 第1部（数値検証） ${checks.length} checks`);
if (process.env.FX_UNIT_ONLY) process.exit(0);

// ------------------------------------------------------------------ 第2部（実ブラウザ）
const { chromium } = await import(process.env.PLAYWRIGHT_MODULE || "playwright-core");
const { mkdtemp, writeFile, rm } = await import("node:fs/promises");
const { tmpdir } = await import("node:os");
const temp = await mkdtemp(path.join(tmpdir(), "paint-fx-"));
function wav16(rate, channels, frames, fn) {
  const buf = Buffer.alloc(44 + frames * channels * 2);
  buf.write("RIFF", 0); buf.writeUInt32LE(buf.length - 8, 4); buf.write("WAVEfmt ", 8);
  buf.writeUInt32LE(16, 16); buf.writeUInt16LE(1, 20); buf.writeUInt16LE(channels, 22);
  buf.writeUInt32LE(rate, 24); buf.writeUInt32LE(rate * channels * 2, 28); buf.writeUInt16LE(channels * 2, 32);
  buf.writeUInt16LE(16, 34); buf.write("data", 36); buf.writeUInt32LE(frames * channels * 2, 40);
  for (let i = 0; i < frames; i++)
    for (let c = 0; c < channels; c++) buf.writeInt16LE(Math.round(fn(i, c) * 32767), 44 + (i * channels + c) * 2);
  return buf;
}
const toneFile = path.join(temp, "tone.wav"), longFile = path.join(temp, "long.wav");
// 2秒・ステレオ。cos なので先頭が 0.5（フェードやエコーの確認がしやすい）
await writeFile(toneFile, wav16(SR, 2, SR * 2, (i, c) => (c ? 0.4 : 0.5) * Math.cos((2 * Math.PI * (c ? 660 : 440) * i) / SR)));
// 600秒(10分)・モノラル 22.05kHz。キャンセル操作の確認用
await writeFile(longFile, wav16(22050, 1, 22050 * 600, (i) => 0.3 * Math.sin(i / 9)));

const browser = await chromium.launch({
  executablePath: process.env.CHROMIUM || "/usr/bin/chromium",
  args: ["--no-sandbox", "--autoplay-policy=no-user-gesture-required"],
});
const page = await browser.newPage({ viewport: { width: 1360, height: 900 } });
const errors = [];
page.on("pageerror", (e) => errors.push(e.message));
page.on("console", (m) => {
  if (m.location().url.endsWith("/favicon.ico")) return;
  if (m.type() === "error" && !m.text().includes("net::")) errors.push(m.text() + " " + m.location().url);
});
const ui = [];
async function uiCheck(name, fn) {
  await fn();
  ui.push(name);
  console.log("PASS", name);
}
const evaluate = (fn, arg) => page.evaluate(fn, arg);
const idle = () => page.waitForFunction(() => !PaintSoundEditor.state.busy);
const statusText = () => evaluate(() => document.querySelector(".se-status").textContent);
const statusIsError = () => evaluate(() => document.querySelector(".se-status").classList.contains("error"));
const at = (i, ch = 0) => evaluate(([i, ch]) => PaintSoundEditor.state.record.pcm.channels[ch][i], [i, ch]);
const frameCount = () => evaluate(() => PaintSoundEditor.state.record.pcm.channels[0].length);
const peakNow = () => evaluate(() => PaintSoundEditor.state.record.pcm.channels.reduce((m, c) => c.reduce((k, v) => Math.max(k, Math.abs(v)), m), 0));
const snap = () => evaluate(() => (window.__base = PaintSoundEditor.state.record.pcm.channels.map((c) => c.slice())));
const sameAsBase = () =>
  evaluate(() => {
    const now = PaintSoundEditor.state.record.pcm.channels;
    return now.length === __base.length && now.every((c, k) => c.length === __base[k].length && c.every((v, i) => v === __base[k][i]));
  });
const rmsBetween = (a, b) =>
  evaluate(([a, b]) => { const c = PaintSoundEditor.state.record.pcm.channels[0]; let s = 0; for (let i = a; i < b; i++) s += c[i] * c[i]; return Math.sqrt(s / (b - a)); }, [a, b]);
const click = (action) => page.click(`[data-action="${action}"]`);
const apply = async (action) => { await click(action); await idle(); };
const undo = async () => { await click("undo"); await idle(); };
const setValue = (id, v) => evaluate(([id, v]) => { document.querySelector("#" + id).value = v; }, [id, v]);
const selectRange = (a, b) => evaluate(([a, b]) => PaintSoundEditor.select(a, b), [a, b]);

try {
  await page.goto((process.env.PREVIEW_URL || "http://localhost:3000") + "/index.html");
  await page.waitForFunction(() => !!window.PaintSoundEditor && !!PaintAudio.fx);
  await page.click("#sound_open");
  await page.locator("#se_file").setInputFiles(toneFile);
  await page.waitForFunction(() => PaintSoundEditor.state.owner.ex.sounds?.length >= 1);
  await idle();
  await evaluate(async () => { await PaintSoundEditor.selectSound(PaintSoundEditor.state.owner.ex.sounds[0]); });
  const N = await frameCount();
  assert.equal(N, SR * 2);
  await snap();
  const first = await at(0);
  near(first, 0.5, 2e-3, "テスト音の先頭");

  await uiCheck("UI: 加工パネルが表示され、ボタン・入力欄が小さい（28px以下）／画面幅を変えてもはみ出さない", async () => {
    for (const [w, h] of [[1360, 900], [820, 1180], [390, 844]]) {
      await page.setViewportSize({ width: w, height: h });
      await page.waitForTimeout(150);
      const m = await evaluate(() => {
        const panel = document.querySelector("#sound-editor .se-fx"), main = document.querySelector("#sound-editor .se-main");
        const hs = [...panel.querySelectorAll("button,select,input")].map((e) => Math.round(e.getBoundingClientRect().height));
        return { visible: panel.getClientRects().length > 0, maxH: Math.max(...hs), n: hs.length, overflowX: main.scrollWidth > main.clientWidth + 1, panelH: Math.round(panel.getBoundingClientRect().height) };
      });
      assert.ok(m.visible && m.n === 21, `部品数 ${m.n}`); // ボタン5+入力1(クイック行) + 音量2・エコー4・リバーブ3・フィルター3・変化3
      assert.ok(m.maxH <= 30, `${w}px: 部品の最大高さ ${m.maxH}px`);
      assert.ok(!m.overflowX, `${w}px: 横にはみ出す`);
      if (w === 1360) assert.ok(m.panelH <= 240, `パネル高さ ${m.panelH}px`);
    }
    await page.setViewportSize({ width: 1360, height: 900 });
  });

  await uiCheck("UI: 全部のボタンに名前（aria-label）が付いている", async () => {
    const bad = await evaluate(() => [...document.querySelectorAll("#sound-editor .se-fx button, #sound-editor .se-fx input, #sound-editor .se-fx select")].filter((e) => !(e.getAttribute("aria-label") || "").trim()).length);
    assert.equal(bad, 0);
  });

  await uiCheck("フェードイン（音全体）: 先頭が0になり、元に戻すで完全に元通り", async () => {
    await apply("fx-fadeIn");
    near(await at(0), 0, 1e-6, "先頭");
    assert.equal(await frameCount(), N);
    assert.match(await statusText(), /フェードインを適用/);
    near(await at(N - 1), await evaluate((n) => __base[0][n - 1], N), 1e-5, "末尾は元のまま");
    await undo();
    assert.ok(await sameAsBase(), "元に戻した音が完全に一致");
  });

  await uiCheck("フェードアウト（範囲を選んで長さ0.25秒）: 範囲の終わりが0になり、範囲の外は変わらない", async () => {
    const a = Math.round(0.5 * SR), b = Math.round(1.5 * SR);
    await selectRange(a, b);
    await setValue("se_fade", "0.25");
    await apply("fx-fadeOut");
    near(await at(b - 1), 0, 1e-6, "範囲の終わり");
    assert.equal(await at(b), await evaluate((i) => __base[0][i], b), "範囲の外は変わらない");
    assert.equal(await at(a), await evaluate((i) => __base[0][i], a), "範囲の手前も変わらない");
    near(await at(b - Math.round(0.25 * SR) - 5), await evaluate((i) => __base[0][i], b - Math.round(0.25 * SR) - 5), 1e-6, "フェード開始より前は変わらない");
    await undo();
    assert.ok(await sameAsBase());
    await setValue("se_fade", "");
  });

  await uiCheck("エコー: 余韻のぶん長くなり、元に戻すで長さも中身も元通り（強さの範囲外入力は補正）", async () => {
    await selectRange(0, N);
    await setValue("se_echo_ms", "99999");
    await apply("fx-echo");
    assert.ok((await frameCount()) > N + SR * 0.5, "余韻が付いた");
    assert.match(await statusText(), /エコーを適用.*余韻のぶん/);
    assert.equal(await evaluate(() => document.querySelector("#se_echo_ms").value), "2000", "入力欄が補正後の値に");
    assert.ok((await peakNow()) <= 1 + 1e-6);
    await undo();
    assert.ok(await sameAsBase());
    await setValue("se_echo_ms", "300");
  });

  await uiCheck("リバーブ: 余韻が付いて長くなり、音割れせず、元に戻せる", async () => {
    await selectRange(0, N);
    await apply("fx-reverb");
    assert.ok((await frameCount()) > N + SR * 0.5);
    assert.ok((await peakNow()) <= 1 + 1e-6);
    assert.equal(await statusIsError(), false);
    await undo();
    assert.ok(await sameAsBase());
  });

  await uiCheck("フィルター: ハイパス(8000Hz)で低い音が大きく減る／ローパスでは通る", async () => {
    await selectRange(0, N);
    const dry = await rmsBetween(SR / 2, SR);
    await evaluate(() => { const s = document.querySelector("#se_filter_type"); s.value = "highpass"; });
    await setValue("se_filter_freq", "8000");
    await apply("fx-filter");
    const hp = await rmsBetween(SR / 2, SR);
    assert.ok(20 * Math.log10(hp / dry) < -30, `HPで ${(20 * Math.log10(hp / dry)).toFixed(1)}dB`);
    await undo();
    await evaluate(() => { document.querySelector("#se_filter_type").value = "lowpass"; });
    await apply("fx-filter");
    assert.ok((await rmsBetween(SR / 2, SR)) / dry > 0.95, "LP(1000Hz)では440Hzは通る");
    await undo();
    assert.ok(await sameAsBase());
  });

  await uiCheck("音量・ノーマライズ・逆再生: 期待どおりの値になる", async () => {
    await selectRange(0, N);
    await setValue("se_gain", "6");
    await apply("fx-gain");
    near(await at(0), first * 10 ** (6 / 20), 2e-3, "+6dB");
    await undo();
    await setValue("se_gain", "999");
    await apply("fx-gain");
    assert.equal(await evaluate(() => document.querySelector("#se_gain").value), "30", "範囲外は30に補正");
    assert.match(await statusText(), /音割れ/);
    await undo();
    await apply("fx-normalize");
    near(await peakNow(), 10 ** (-1 / 20), 1e-3, "ノーマライズ");
    await undo();
    await apply("fx-reverse");
    near(await at(0), await evaluate((n) => __base[0][n - 1], N), 1e-6, "逆再生の先頭");
    await undo();
    assert.ok(await sameAsBase());
  });

  await uiCheck("選択範囲を無音に: 範囲が無いときは押せず、選ぶと範囲だけ無音になる", async () => {
    await selectRange(1000, 1000);
    assert.equal(await evaluate(() => document.querySelector('[data-action="fx-silence"]').disabled), true);
    const a = Math.round(0.5 * SR), b = Math.round(1.0 * SR);
    await selectRange(a, b);
    assert.equal(await evaluate(() => document.querySelector('[data-action="fx-silence"]').disabled), false);
    await apply("fx-silence");
    assert.equal(await frameCount(), N);
    assert.equal(await rmsBetween(a, b), 0);
    assert.equal(await at(a - 1), await evaluate((i) => __base[0][i], a - 1));
    assert.equal(await at(b), await evaluate((i) => __base[0][i], b));
    await undo();
    assert.ok(await sameAsBase());
  });

  await uiCheck("変化（ロボット声／ビブラート／トレモロ／ひずみ／8bit風）: 5種類とも長さを保って変化し、元に戻せる", async () => {
    await selectRange(0, N);
    for (const type of ["robot", "vibrato", "tremolo", "distort", "crush"]) {
      await evaluate((t) => { document.querySelector("#se_voice_type").value = t; }, type);
      await apply("fx-voice");
      assert.equal(await frameCount(), N, type);
      assert.equal(await statusIsError(), false, type);
      assert.equal(await sameAsBase(), false, `${type}: 音が実際に変わった`);
      await undo();
      assert.ok(await sameAsBase(), `${type}: 元に戻る`);
    }
  });

  await uiCheck("保存データ: 加工後も Scratch互換WAV（RIFF・md5一致・長さ/サンプル数一致）として保存される", async () => {
    await selectRange(0, N);
    await apply("fx-echo");
    const m = await evaluate(() => {
      const r = PaintSoundEditor.state.record, bytes = PaintSoundEditor.state.owner.snd[r.meta.md5ext];
      return { fmt: new TextDecoder().decode(bytes.slice(0, 4)), md5ok: md5(bytes) === r.meta.assetId, ext: r.meta.dataFormat, count: r.meta.sampleCount, frames: r.pcm.channels[0].length, rate: r.meta.rate, sr: r.pcm.sampleRate };
    });
    assert.equal(m.fmt, "RIFF");
    assert.ok(m.md5ok);
    assert.equal(m.ext, "wav");
    assert.equal(m.count, m.frames);
    assert.equal(m.rate, m.sr);
    await undo();
    assert.ok(await sameAsBase());
  });

  await uiCheck("数値入力欄での Delete/Backspace が、音の削除として扱われない", async () => {
    await selectRange(1000, 5000);
    await page.focus("#se_echo_ms");
    await page.keyboard.press("Backspace");
    await page.keyboard.press("Delete");
    assert.equal(await frameCount(), N);
    await evaluate(() => document.activeElement.blur());
  });

  await uiCheck("10分の長い音でも処理中に画面が応答し、キャンセルで音は変わらず、その後も加工できる", async () => {
    await page.locator("#se_file").setInputFiles(longFile);
    await page.waitForFunction(() => PaintSoundEditor.state.owner.ex.sounds.length >= 2);
    await idle();
    await evaluate(async () => { const l = PaintSoundEditor.state.owner.ex.sounds; await PaintSoundEditor.selectSound(l[l.length - 1]); });
    const n = await frameCount();
    assert.equal(n, SR * 600); // 読み込み時に 44.1kHz へ変換されるため 10分 = 26,460,000 サンプル
    await snap();
    await setValue("se_rev_room", "100");
    await click("fx-reverb");
    await page.waitForFunction(() => PaintSoundEditor.state.busy);
    assert.equal(await evaluate(() => document.querySelector('[data-action="cancel"]').hidden), false, "処理中はキャンセルが出る");
    assert.equal(await evaluate(() => document.querySelector('[data-action="fx-echo"]').disabled), true, "処理中は他の加工が押せない");
    await page.waitForFunction(() => /処理中… \d+%/.test(document.querySelector(".se-status").textContent));
    await click("cancel");
    await idle();
    assert.match(await statusText(), /キャンセル/);
    assert.ok(await sameAsBase(), "キャンセルしても音は変わらない");
    assert.equal(await evaluate(() => PaintSoundEditor.state.record.undo.length), 0, "履歴も増えない");
    await selectRange(0, SR);
    await apply("fx-fadeOut");
    assert.equal(await statusIsError(), false);
    near(await at(SR - 1), 0, 1e-9, "フェードアウトの終端"); // 負の値×0 は -0 になるため厳密比較はしない
  });

  await uiCheck("既存機能（スピード・音程）は従来どおり動く", async () => {
    await evaluate(async () => { await PaintSoundEditor.selectSound(PaintSoundEditor.state.owner.ex.sounds[0]); });
    await snap();
    await selectRange(0, N);
    await page.selectOption("#se_tempo", "2");
    await apply("tempo");
    near((await frameCount()) / N, 0.5, 0.02, "2倍速で半分の長さ");
    await undo();
    await page.selectOption("#se_pitch", "12");
    await apply("pitch");
    assert.equal(await statusIsError(), false);
    await undo();
    assert.ok(await sameAsBase());
  });

  assert.deepEqual(errors, [], "ページにエラーが出ていない");
  console.log(`\nPASS 第2部（画面操作） ${ui.length} checks, no uncaught page errors`);
} catch (error) {
  console.error(error);
  process.exitCode = 1;
} finally {
  await browser.close();
  await rm(temp, { recursive: true, force: true });
}
