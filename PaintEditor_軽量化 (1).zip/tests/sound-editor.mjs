import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { mkdtemp, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
const { chromium } = await import(process.env.PLAYWRIGHT_MODULE || "playwright-core");
const temp = await mkdtemp(join(tmpdir(), "paint-audio-"));
const fixtures = {};
for (const [ext, codec] of [
  ["wav", "pcm_s16le"],
  ["mp3", "libmp3lame"],
  ["ogg", "libvorbis"],
  ["m4a", "aac"],
  ["flac", "flac"],
]) {
  fixtures[ext] = join(temp, "tone." + ext);
  execFileSync("ffmpeg", [
    "-hide_banner",
    "-loglevel",
    "error",
    "-f",
    "lavfi",
    "-i",
    "sine=frequency=440:duration=2:sample_rate=44100",
    "-c:a",
    codec,
    fixtures[ext],
  ]);
}
const adpcm = join(temp, "scratch-adpcm.wav");
execFileSync("ffmpeg", [
  "-hide_banner",
  "-loglevel",
  "error",
  "-f",
  "lavfi",
  "-i",
  "sine=frequency=440:duration=1:sample_rate=22050",
  "-c:a",
  "adpcm_ima_wav",
  adpcm,
]);
const browser = await chromium.launch({
  executablePath: process.env.CHROMIUM || "/usr/bin/chromium",
  args: ["--no-sandbox", "--autoplay-policy=no-user-gesture-required"],
});
const page = await browser.newPage({ viewport: { width: 1360, height: 900 } });
const errors = [];
page.on("pageerror", (e) => errors.push(e.message));
page.on("console", (m) => {
  // The supplied editor has no favicon.ico. It is unrelated to audio functionality.
  if (m.location().url.endsWith("/favicon.ico")) return;
  if (m.type() === "error" && !m.text().includes("net::"))
    errors.push(m.text() + " " + m.location().url);
});
const checks = [];
async function check(name, fn) {
  await fn();
  checks.push(name);
  console.log("PASS", name);
}
const evaluate = (fn) => page.evaluate(fn);
async function idle() {
  await page.waitForFunction(() => !PaintSoundEditor.state.busy);
}
async function firstSound() {
  await evaluate(async () => {
    await PaintSoundEditor.selectSound(PaintSoundEditor.state.owner.ex.sounds[0]);
    const r = PaintSoundEditor.state.record;
    PaintSoundEditor.select(0, PaintAudio.length(r.pcm));
  });
}
try {
  await page.goto((process.env.PREVIEW_URL || "http://localhost:3000") + "/index.html");
  await page.waitForFunction(() => !!window.PaintSoundEditor);
  await check(
    "sound entry sits immediately to the right of Animation; opens accessible editor",
    async () => {
      assert.equal(
        await evaluate(() => document.querySelector("#scn_open").nextElementSibling.id),
        "sound_open",
      );
      await page.click("#sound_open");
      assert.equal(
        await page.getByRole("dialog", { name: "音エディター", exact: true }).isVisible(),
        true,
      );
      assert.equal(await evaluate(() => SCN.S.open), false);
    },
  );
  await check(
    "WAV, MP3, OGG, M4A and FLAC imports decode and become valid Scratch WAV assets",
    async () => {
      await page.locator("#se_file").setInputFiles(Object.values(fixtures));
      await page.waitForFunction(() => PaintSoundEditor.state.owner.ex.sounds?.length === 5);
      await idle();
      const info = await evaluate(() =>
        PaintSoundEditor.state.owner.ex.sounds.map((s) => {
          const bytes = PaintSoundEditor.state.owner.snd[s.md5ext];
          return {
            name: s.name,
            ext: s.dataFormat,
            asset: md5(bytes) === s.assetId,
            format: new TextDecoder().decode(bytes.slice(0, 4)),
            samples: s.sampleCount,
            rate: s.rate,
          };
        }),
      );
      assert.equal(new Set(info.map((s) => s.name)).size, 5);
      for (const s of info) {
        assert.equal(s.ext, "wav");
        assert.ok(s.asset);
        assert.equal(s.format, "RIFF");
        assert.ok(Math.abs(s.samples / s.rate - 2) < 0.05);
      }
      await firstSound();
      assert.ok(await evaluate(() => document.querySelector("#se_wave").width > 0));
    },
  );
  await check(
    "legacy Scratch IMA ADPCM WAV sounds decode at their native rate and can be edited",
    async () => {
      await page.locator("#se_file").setInputFiles(adpcm);
      await page.waitForFunction(() => PaintSoundEditor.state.owner.ex.sounds.length === 6);
      await idle();
      const result = await evaluate(() => {
        const r = PaintSoundEditor.state.record,
          c = r.pcm.channels[0],
          rate = r.pcm.sampleRate;
        let crossings = 0;
        for (let i = 1; i < c.length; i++) if (c[i - 1] <= 0 && c[i] > 0) crossings++;
        return {
          rate,
          seconds: c.length / rate,
          hz: (crossings * rate) / c.length,
          format: r.meta.dataFormat,
        };
      });
      assert.equal(result.rate, 22050);
      assert.ok(Math.abs(result.seconds - 1) < 0.1);
      assert.ok(Math.abs(result.hz - 440) < 10, JSON.stringify(result));
      assert.equal(result.format, "wav");
      await firstSound();
    },
  );
  await check(
    "cut, internal clipboard paste, delete/trim and undo/redo change real sample counts",
    async () => {
      const result = await evaluate(() => {
        const e = PaintSoundEditor,
          r = e.state.record,
          original = PaintAudio.length(r.pcm),
          rate = r.pcm.sampleRate;
        e.select(0, Math.round(rate * 0.5));
        e.actions.cut();
        const cut = PaintAudio.length(r.pcm);
        e.select(cut, cut);
        e.actions.paste();
        const pasted = PaintAudio.length(r.pcm);
        e.actions.undo();
        const undo = PaintAudio.length(r.pcm);
        e.actions.redo();
        const redo = PaintAudio.length(r.pcm);
        e.actions.undo();
        e.actions.undo();
        e.select(0, Math.round(rate * 0.25));
        e.actions.trim();
        const trimmed = PaintAudio.length(r.pcm);
        e.actions.undo();
        return {
          original,
          cut,
          pasted,
          undo,
          redo,
          trimmed,
          restored: PaintAudio.length(r.pcm),
          rate,
        };
      });
      assert.equal(result.cut, result.original - result.rate / 2);
      assert.equal(result.pasted, result.original);
      assert.equal(result.undo, result.cut);
      assert.equal(result.redo, result.pasted);
      assert.equal(result.trimmed, result.rate / 4);
      assert.equal(result.restored, result.original);
    },
  );
  await check(
    "waveform dragging and keyboard copy/paste are isolated from costume editing",
    async () => {
      const before = await evaluate(() => JSON.stringify(C().sh));
      const box = await page.locator("#se_wave").boundingBox();
      await page.mouse.move(box.x + box.width * 0.2, box.y + 60);
      await page.mouse.down();
      await page.mouse.move(box.x + box.width * 0.4, box.y + 90);
      await page.mouse.up();
      await page.keyboard.press("Control+c");
      const copied = await evaluate(() => PaintAudio.length(PaintSoundEditor.state.clipboard));
      assert.ok(Math.abs(copied / 44100 - 0.4) < 0.02);
      await evaluate(() => {
        const e = PaintSoundEditor;
        e.select(PaintAudio.length(e.state.record.pcm), PaintAudio.length(e.state.record.pcm));
      });
      await page.keyboard.press("Control+v");
      assert.ok(await evaluate(() => PaintAudio.length(PaintSoundEditor.state.record.pcm) > 88000));
      await page.keyboard.press("Control+z");
      assert.equal(await evaluate(() => JSON.stringify(C().sh)), before);
    },
  );
  await evaluate(() => {
    window.measureTone = (pcm) => {
      const c = pcm.channels[0],
        start = Math.floor(0.2 * pcm.sampleRate),
        end = c.length - Math.floor(0.2 * pcm.sampleRate);
      let crossings = 0,
        energy = 0;
      for (let i = start + 1; i < end; i++) {
        if (c[i - 1] <= 0 && c[i] > 0) crossings++;
        energy += c[i] ** 2;
      }
      return {
        length: c.length,
        seconds: c.length / pcm.sampleRate,
        hz: (crossings * pcm.sampleRate) / (end - start),
        rms: Math.sqrt(energy / (end - start)),
      };
    };
  });
  for (const [speed, duration] of [
    ["2", 1],
    [".5", 4],
  ]) {
    await check(`${speed}x speed renders expected duration while keeping 440Hz pitch`, async () => {
      await firstSound();
      await page.selectOption("#se_tempo", speed);
      await page.click('[data-action="tempo"]');
      await idle();
      const result = await evaluate(() => measureTone(PaintSoundEditor.state.record.pcm));
      assert.ok(Math.abs(result.seconds - duration) < 0.002, JSON.stringify(result));
      assert.ok(Math.abs(result.hz - 440) < 5, JSON.stringify(result));
      assert.ok(result.rms > 0.02);
      await page.click('[data-action="undo"]');
    });
  }
  for (const [pitch, hz] of [
    ["12", 880],
    ["-12", 220],
  ]) {
    await check(
      `${pitch} semitone pitch shift keeps duration and changes actual waveform frequency`,
      async () => {
        await firstSound();
        await page.selectOption("#se_pitch", pitch);
        await page.click('[data-action="pitch"]');
        await idle();
        const result = await evaluate(() => measureTone(PaintSoundEditor.state.record.pcm));
        assert.ok(Math.abs(result.seconds - 2) < 0.002, JSON.stringify(result));
        assert.ok(Math.abs(result.hz - hz) < 6, JSON.stringify(result));
        assert.ok(result.rms > 0.02);
        await page.click('[data-action="undo"]');
      },
    );
  }
  await check(
    "partial-selection effects retain samples outside selection; cancellation commits nothing",
    async () => {
      const result = await evaluate(async () => {
        const e = PaintSoundEditor,
          r = e.state.record,
          rate = r.pcm.sampleRate,
          original = r.pcm;
        e.select(rate / 2, rate);
        document.querySelector("#se_pitch").value = "7";
        await e.actions.pitch();
        const outside =
          r.pcm.channels[0].slice(0, rate / 2).every((v, i) => v === original.channels[0][i]) &&
          r.pcm.channels[0].slice(rate).every((v, i) => v === original.channels[0][rate + i]);
        e.actions.undo();
        e.select(0, PaintAudio.length(r.pcm));
        const before = r.bytes;
        const pending = e.actions.pitch();
        e.actions.cancel();
        await pending;
        return { outside, unchanged: r.bytes === before, busy: e.state.busy };
      });
      assert.deepEqual(result, { outside: true, unchanged: true, busy: false });
    },
  );
  await check("stereo DSP and cross-sample-rate paste keep channel information", async () => {
    const result = await evaluate(async () => {
      const a = PaintAudio,
        rate = 48000;
      const channels = [440, 660].map((hz) =>
        Float32Array.from(
          { length: rate },
          (_, i) => 0.3 * Math.sin((i * hz * 2 * Math.PI) / rate),
        ),
      );
      const pcm = { channels, sampleRate: rate };
      const shifted = await a.transform(pcm, { semitones: 12 }).promise;
      const mono = { channels: [new Float32Array(44100)], sampleRate: 44100 };
      const pasted = a.replace(mono, 44100, 44100, shifted);
      const freq = (c) => {
        let n = 0;
        for (let i = 5000; i < c.length - 5000; i++) if (c[i - 1] <= 0 && c[i] > 0) n++;
        return (n * rate) / (c.length - 10000);
      };
      return {
        channels: pasted.channels.length,
        length: a.length(pasted),
        rate: pasted.sampleRate,
        left: freq(shifted.channels[0]),
        right: freq(shifted.channels[1]),
      };
    });
    assert.equal(result.channels, 2);
    assert.equal(result.length, 88200);
    assert.equal(result.rate, 44100);
    assert.ok(Math.abs(result.left - 880) < 8);
    assert.ok(Math.abs(result.right - 1320) < 8);
  });
  await check("play/stop uses an AudioBufferSource and releases live voices", async () => {
    await firstSound();
    await page.click('[data-action="play"]');
    await page.waitForFunction(() => PaintAudio.activeCount === 1);
    assert.equal(await evaluate(() => PaintAudio.audioContext().state), "running");
    assert.equal(
      await evaluate(() => PaintSoundEditor.state.preview.source.buffer.numberOfChannels),
      1,
    );
    await page.click('[data-action="stop"]');
    assert.equal(await evaluate(() => PaintAudio.activeCount), 0);
  });
  await check(
    "rename and undo update both Scratch menu references and scene sound blocks",
    async () => {
      const result = await evaluate(() => {
        const e = PaintSoundEditor,
          r = e.state.record;
        SCN.open();
        SCN.addObj(C(), "Audio actor");
        SCN.close();
        e.state.owner.ex.blocks ||= {};
        e.state.owner.ex.blocks.menu = {
          opcode: "sound_sounds_menu",
          fields: { SOUND_MENU: [r.meta.name, null] },
        };
        SCN.scene().objs[0].sc = [
          {
            id: "sound-name",
            x: 0,
            y: 0,
            b: [
              { op: "event_whenflag", in: {} },
              { op: "sound_start", in: { S: r.meta.name } },
            ],
          },
        ];
        const input = document.querySelector("#se_name");
        input.value = "Renamed tone";
        input.dispatchEvent(new Event("change"));
        const renamed = e.state.owner.ex.blocks.menu.fields.SOUND_MENU[0];
        const editor = SCN.scene().objs[0].sc[0].b[1].in.S;
        e.actions.undo();
        return {
          renamed,
          editor,
          original: r.meta.name,
          undoRef: e.state.owner.ex.blocks.menu.fields.SOUND_MENU[0],
        };
      });
      assert.equal(result.renamed, "Renamed tone");
      assert.equal(result.editor, result.renamed);
      assert.equal(result.original, result.undoRef);
    },
  );
  await check(
    "sprite3 and sb3 load embedded audio and retain exported Scratch metadata/assets",
    async () => {
      await page.click('[data-action="close"]');
      const bytes = [...(await readFile(fixtures.mp3))];
      const pending = page.evaluate(async (bytes) => {
        const cv = document.createElement("canvas");
        cv.width = cv.height = 10;
        const png = b2u(cv.toDataURL().split(",")[1]);
        const sound = {
          name: "Archive MP3",
          assetId: "original",
          md5ext: "original.mp3",
          dataFormat: "mp3",
          rate: 44100,
          sampleCount: 88200,
        };
        const target = {
          isStage: false,
          name: "Audio sprite",
          variables: {},
          lists: {},
          broadcasts: {},
          blocks: {
            flag: { opcode: "event_whenflagclicked", topLevel: true, next: "wait" },
            menu: {
              opcode: "sound_sounds_menu",
              shadow: true,
              fields: { SOUND_MENU: ["Archive MP3", null] },
            },
            wait: {
              opcode: "sound_playuntildone",
              next: "move",
              inputs: { SOUND_MENU: [1, "menu"] },
            },
            move: { opcode: "motion_setx", inputs: { X: [1, [4, "123"]] } },
          },
          sounds: [sound],
          costumes: [
            {
              name: "costume1",
              md5ext: "c.png",
              dataFormat: "png",
              bitmapResolution: 1,
              rotationCenterX: 5,
              rotationCenterY: 5,
            },
          ],
        };
        const zip = zipMake([
          ["sprite.json", te(JSON.stringify(target))],
          ["original.mp3", new Uint8Array(bytes)],
          ["c.png", png],
        ]);
        await s3in(new File([zip], "audio.sprite3"));
      }, bytes);
      await page.getByRole("button", { name: "新しいスプライトとして追加", exact: true }).click();
      await page.getByRole("button", { name: "OK", exact: true }).click();
      await pending;
      await page.click("#sound_open");
      await idle();
      assert.equal(await evaluate(() => PaintSoundEditor.state.record.meta.name), "Archive MP3");
      assert.equal(await evaluate(() => PaintSoundEditor.state.record.meta.dataFormat), "mp3");
      const info = await evaluate(async () => {
        const owner = PaintSoundEditor.state.owner,
          files = [],
          seen = new Set();
        const target = await spTarget(owner, 1, files, seen);
        // Exercise the .sb3/project.json path with actual ZIP assets, not fabricated owner state.
        const project = zipMake([
          [
            "project.json",
            te(
              JSON.stringify({
                targets: [{ ...target, isStage: true, name: "Stage", blocks: {} }, target],
              }),
            ),
          ],
          ...files,
        ]);
        window.audioProjectFile = new File([project], "audio.sb3");
        return {
          sounds: target.sounds.length,
          exists: files.some(([name]) => name === target.sounds[0].md5ext),
        };
      });
      assert.deepEqual(info, { sounds: 1, exists: true });
      await page.click('[data-action="close"]');
      const projectLoad = page.evaluate(() => s3in(audioProjectFile));
      await page.getByRole("button", { name: "置き換えて読み込む", exact: true }).click();
      await page.getByRole("button", { name: "OK", exact: true }).click();
      await projectLoad;
      await page.click("#sound_open");
      await idle();
      assert.equal(await evaluate(() => PaintSoundEditor.state.owner.ex.sounds.length), 1);
      await evaluate(async () => {
        await PaintSoundEditor.selectOwner(SPS.find((s) => s.stage));
      });
      assert.equal(await evaluate(() => PaintSoundEditor.state.record.meta.name), "Archive MP3");
      await evaluate(async () => {
        await PaintSoundEditor.selectOwner(SPS.find((s) => !s.stage));
      });
    },
  );
  await check(
    "imported sound-play-until-done waits for real playback and resumes after stop",
    async () => {
      await page.click('[data-action="close"]');
      await evaluate(() => {
        SCN.open();
      });
      await page.locator("#scn button.flag").click();
      await page.waitForFunction(() => PaintAudio.activeCount === 1);
      const before = await evaluate(() => ({
        x: SCN.rt.list.find((t) => !t.stage).x,
        threads: SCN.rt.threads.length,
      }));
      assert.notEqual(before.x, 123);
      assert.ok(before.threads > 0);
      const volume = await evaluate(() => {
        const target = SCN.rt.list.find((t) => !t.stage);
        SCN.BK.sound_setvolume.fn(target, { V: 60 });
        SCN.BK.sound_changevolume.fn(target, { V: -20 });
        return SCN.BK.sound_volume.fn(target, {});
      });
      assert.equal(volume, 40);
      await evaluate(() =>
        SCN.BK.sound_stopall.fn(
          SCN.rt.list.find((t) => !t.stage),
          {},
        ),
      );
      await page.waitForFunction(() => SCN.rt.list.find((t) => !t.stage).x === 123);
      assert.equal(await evaluate(() => PaintAudio.activeCount), 0);
      await evaluate(() => SCN.close());
    },
  );
  await check(
    "edited sounds survive project JSON and Scratch re-export; corrupt imports do not alter sounds",
    async () => {
      await page.click("#sound_open");
      await idle();
      await page.selectOption("#se_pitch", "12");
      await page.click('[data-action="pitch"]');
      await idle();
      const result = await evaluate(async () => {
        const e = PaintSoundEditor,
          owner = e.state.owner;
        const before = owner.snd[owner.ex.sounds[0].md5ext].slice();
        const project = ser();
        e.close();
        await loadAsync(project);
        await e.open();
        const after = e.state.owner.snd[e.state.owner.ex.sounds[0].md5ext];
        const files = [],
          target = await spTarget(e.state.owner, 1, files, new Set());
        const meta = target.sounds[0],
          asset = files.find(([n]) => n === meta.md5ext)?.[1];
        const n = e.state.owner.ex.sounds.length;
        await e.importFiles([new File(["not audio"], "corrupt.mp3", { type: "audio/mpeg" })]);
        return {
          same: before.length === after.length && before.every((v, i) => v === after[i]),
          asset: md5(asset) === meta.assetId,
          ext: meta.dataFormat,
          corruptKeptCount: n === e.state.owner.ex.sounds.length,
          failed: document.querySelector(".se-status").classList.contains("error"),
        };
      });
      assert.deepEqual(result, {
        same: true,
        asset: true,
        ext: "wav",
        corruptKeptCount: true,
        failed: true,
      });
    },
  );
  await check("closing during DSP cancels worker and leaves asset bytes unchanged", async () => {
    const result = await evaluate(async () => {
      const e = PaintSoundEditor,
        r = e.state.record,
        bytes = r.bytes;
      const pending = e.actions.pitch();
      e.close();
      await pending;
      return {
        unchanged: r.bytes === bytes,
        worker: e.state.worker === null,
        playing: PaintAudio.activeCount,
      };
    });
    assert.deepEqual(result, { unchanged: true, worker: true, playing: 0 });
  });
  assert.deepEqual(errors, []);
  console.log(`PASS ${checks.length} checks, no uncaught page/audio-console errors`);
} finally {
  await browser.close();
  await rm(temp, { recursive: true, force: true });
}
