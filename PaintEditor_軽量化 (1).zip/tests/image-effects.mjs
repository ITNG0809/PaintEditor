// 画像効果(渦巻き・魚眼など)のGPU計算とCPU計算が同じ見た目になるか・速いかを確認する。
// 先にプロジェクトのルートを配信しておく(例: python3 -m http.server 3000)。
import assert from "node:assert/strict";
const { chromium } = await import(process.env.PLAYWRIGHT_MODULE || "playwright-core");
const browser = await chromium.launch({
  executablePath: process.env.CHROMIUM || undefined,
  args: ["--no-sandbox", "--use-gl=angle", "--use-angle=swiftshader", "--enable-unsafe-swiftshader", "--ignore-gpu-blocklist"],
});
const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
const errors = [];
page.on("pageerror", (e) => errors.push(e.message));
try {
  await page.goto((process.env.PREVIEW_URL || "http://localhost:3000") + "/index.html");
  await page.waitForFunction(() => !!window.SCN);
  await page.evaluate(() => {
    SCN.open();
    const bc = document.createElement("canvas");
    bc.width = bc.height = 200;
    const g = bc.getContext("2d");
    for (let i = 0; i < 8; i++) { g.fillStyle = `hsl(${i * 45},80%,50%)`; g.fillRect(i * 25, 0, 25, 200); }
    g.fillStyle = "#000"; g.fillRect(0, 90, 200, 20); g.beginPath(); g.arc(100, 100, 60, 0, 7); g.lineWidth = 8; g.strokeStyle = "#fff"; g.stroke();
    const bmp = { n: "fx", k: "b", w: 200, h: 200, cx: 100, cy: 100, res: 1, bc, sh: [] };
    cs.push(bmp); SCN.reindex(); SCN.addObj(bmp, "A"); SCN.flag();
  });
  const cases = {
    whirl: { whirl: 200 }, fisheye: { fisheye: 150 }, both: { whirl: -120, fisheye: 80 },
    pixelate: { pixelate: 300 }, mosaic: { mosaic: 40 }, color: { color: 60 }, bright: { bright: 40 },
    all: { whirl: 90, fisheye: 60, color: 30, bright: -20, pixelate: 100, mosaic: 20 },
  };
  const res = await page.evaluate((cases) => {
    const T = SCN.H.list()[0]; const out = {};
    const render = () => { const cv = document.createElement("canvas"); cv.width = 480; cv.height = 360; const x = cv.getContext("2d"); SCN.drawObjFx(x, T, 1); return x.getImageData(0, 0, 480, 360).data; };
    for (const [name, fx] of Object.entries(cases)) {
      T.fx = { color: 0, fisheye: 0, whirl: 0, pixelate: 0, mosaic: 0, bright: 0, ...fx };
      SCN.fxForceCPU(false); const a = render(); const mode = SCN.fxMode();
      SCN.fxForceCPU(true); const b = render();
      let big = 0, sum = 0, n = 0;
      for (let i = 0; i < a.length; i += 4) { if (a[i + 3] || b[i + 3]) { n++; const d = Math.max(Math.abs(a[i] - b[i]), Math.abs(a[i + 1] - b[i + 1]), Math.abs(a[i + 2] - b[i + 2]), Math.abs(a[i + 3] - b[i + 3])); sum += d; if (d > 24) big++; } }
      out[name] = { mode, pixels: n, bigDiffRatio: big / Math.max(1, n), meanDiff: sum / Math.max(1, n) };
    }
    // 速度: 渦巻き+魚眼を60回描く
    T.fx = { color: 0, fisheye: 100, whirl: 180, pixelate: 0, mosaic: 0, bright: 0 };
    const bench = (cpu) => { SCN.fxForceCPU(cpu); const cv = document.createElement("canvas"); cv.width = 480; cv.height = 360; const x = cv.getContext("2d"); const t0 = performance.now(); for (let i = 0; i < 60; i++) { T.fx.whirl = 180 + i; SCN.drawObjFx(x, T, 2); } x.getImageData(0, 0, 1, 1); return (performance.now() - t0) / 60; };
    bench(false); out.bench = { gpuMs: bench(false), cpuMs: bench(true) };
    return out;
  }, cases);
  console.log(JSON.stringify(res, null, 1));
  for (const [k, v] of Object.entries(res)) { if (k === "bench") continue; assert.equal(v.mode, "gpu", k + " はGPUで計算されるはず"); assert.ok(v.pixels > 1000, k + " 描画あり"); assert.ok(v.bigDiffRatio < 0.02, `${k}: GPU/CPU差が大きい ${v.bigDiffRatio}`); }

  // 使い回しの確認: 大きさ・コスチュームを変えたら絵も変わる / 大きいスプライトの速度
  const cache = await page.evaluate(() => {
    const T = SCN.H.list()[0];
    const render = (k = 1) => { const cv = document.createElement("canvas"); cv.width = 480; cv.height = 360; const x = cv.getContext("2d"); SCN.drawObjFx(x, T, k); return x.getImageData(0, 0, 480, 360).data; };
    const area = (d) => { let n = 0; for (let i = 3; i < d.length; i += 4) if (d[i] > 10) n++; return n; };
    const red = (d) => { let n = 0; for (let i = 0; i < d.length; i += 4) if (d[i + 3] > 200 && d[i] > 200 && d[i + 1] < 60 && d[i + 2] < 60) n++; return n; };
    SCN.fxForceCPU(false);
    T.fx = { color: 0, fisheye: 60, whirl: 100, pixelate: 0, mosaic: 0, bright: 0 };
    T.size = 100; const a100 = area(render()); const a100b = area(render());
    T.size = 50; const a50 = area(render());
    T.size = 100; const a100c = area(render());
    const c0 = T.c; const bc = document.createElement("canvas"); bc.width = bc.height = 200; const g = bc.getContext("2d"); g.fillStyle = "#ff0000"; g.fillRect(0, 0, 200, 200);
    const bmp = { n: "red", k: "b", w: 200, h: 200, cx: 100, cy: 100, res: 1, bc, sh: [] }; cs.push(bmp); SCN.reindex();
    const redBefore = red(render()); T.c = bmp; const redAfter = red(render()); T.c = c0; const redBack = red(render());
    // 大きいスプライト(1000x1000)・k=2
    const big = document.createElement("canvas"); big.width = big.height = 1000; const bg = big.getContext("2d"); bg.fillStyle = "#39c"; bg.fillRect(0, 0, 1000, 1000);
    const B = { n: "big", k: "b", w: 1000, h: 1000, cx: 500, cy: 500, res: 1, bc: big, sh: [] }; cs.push(B); SCN.reindex(); T.c = B; T.size = 100;
    const bench = (cpu) => { SCN.fxForceCPU(cpu); const cv = document.createElement("canvas"); cv.width = 960; cv.height = 720; const x = cv.getContext("2d"); const t0 = performance.now(); for (let i = 0; i < 20; i++) { T.fx.whirl = 100 + i; SCN.drawObjFx(x, T, 2); } x.getImageData(0, 0, 1, 1); return (performance.now() - t0) / 20; };
    bench(false); const bigGpu = bench(false), bigCpu = bench(true);
    return { a100, a100b, a50, a100c, redBefore, redAfter, redBack, bigGpu, bigCpu };
  });
  console.log(JSON.stringify(cache));
  assert.equal(cache.a100, cache.a100b); assert.ok(cache.a50 < cache.a100 * 0.5); assert.equal(cache.a100c, cache.a100);
  assert.ok(cache.redAfter > cache.redBefore * 3); assert.equal(cache.redBack, cache.redBefore);

  // 大きいスプライト(大きさ400)・スタンプ連打: 同じ効果の2回目以降は使い回され、効果を変えれば更新される
  const stamp = await page.evaluate(() => {
    const T = SCN.H.list()[0]; SCN.fxForceCPU(false); T.c = cs.find(c => c.n === "fx"); T.size = 400;
    const cv = document.createElement("canvas"); cv.width = 1440; cv.height = 1080; const x = cv.getContext("2d"); x.setTransform(3, 0, 0, 3, 0, 0);
    const snap = () => { x.clearRect(0, 0, 480, 360); SCN.drawObjFx(x, T, 3); const d = x.getImageData(0, 0, 1440, 1080).data; let h = 7, n = 0; for (let i = 0; i < d.length; i += 4) { h = (h * 31 + d[i] + d[i + 1] * 3 + d[i + 2] * 7 + d[i + 3]) | 0; if (d[i + 3]) n++; } return h + ":" + n; };
    T.fx = { color: 0, fisheye: 50, whirl: 120, pixelate: 0, mosaic: 0, bright: 0 };
    const h1 = snap(), h2 = snap(), h3 = snap(); T.fx.whirl = 60; const h4 = snap();
    const t0 = performance.now(); T.fx.whirl = 120; for (let i = 0; i < 30; i++) { T.x = i * 3; SCN.drawObjFx(x, T, 3); } const ms = (performance.now() - t0) / 30; T.x = 0; T.size = 100;
    return { same: h1 === h2 && h2 === h3, changed: h4 !== h3, msPerStamp: ms };
  });
  console.log(JSON.stringify(stamp));
  assert.ok(stamp.same && stamp.changed);
  assert.deepEqual(errors, []);
  console.log("PASS image-effects");
} finally { await browser.close(); }
