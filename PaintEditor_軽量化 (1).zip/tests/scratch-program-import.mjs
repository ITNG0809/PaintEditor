import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";

const { chromium } = await import(process.env.PLAYWRIGHT_MODULE || "playwright-core");
const browser = await chromium.launch({
  executablePath: process.env.CHROMIUM || "/usr/bin/chromium",
  args: ["--no-sandbox"],
});
const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
const errors = [];
page.on("pageerror", (e) => errors.push(e.message));
const checks = [];
async function check(name, fn) {
  await fn();
  checks.push(name);
  console.log("PASS", name);
}
function builder() {
  const blocks = {};
  let counter = 0;
  const add = (opcode, inputs = {}, fields = {}, extra = {}) => {
    const id = "b" + ++counter;
    blocks[id] = {
      opcode,
      next: null,
      parent: null,
      inputs,
      fields,
      shadow: false,
      topLevel: false,
      ...extra,
    };
    return id;
  };
  const link = (...ids) => {
    ids.forEach((id, i) => {
      if (i) blocks[ids[i - 1]].next = id;
    });
    return ids[0];
  };
  const top = (...ids) => {
    const id = link(...ids);
    Object.assign(blocks[id], { topLevel: true, x: counter * 3, y: counter * 4 });
    return id;
  };
  return { blocks, add, link, top };
}
const num = (n) => [1, [4, String(n)]],
  text = (s) => [1, [10, s]],
  ref = (id) => [2, id];
function runner() {
  const { blocks, add, link, top } = builder();
  const local = ["score", "L"],
    global = ["score", "G"],
    list = ["trail", "LL"];
  const body = link(
    add("data_changevariableby", { VALUE: num(1) }, { VARIABLE: local }),
    add("motion_movesteps", { STEPS: num(2) }),
    add("data_addtolist", { ITEM: [3, [12, "score", "L"], [10, ""]] }, { LIST: list }),
  );
  const condition = add("operator_gt", {
    OPERAND1: [3, [12, "score", "L"], [10, ""]],
    OPERAND2: num(0),
  });
  const menu = add(
    "control_create_clone_of_menu",
    {},
    { CLONE_OPTION: ["_myself_", null] },
    { shadow: true },
  );
  top(
    add("event_whenflagclicked"),
    add("data_setvariableto", { VALUE: num(10) }, { VARIABLE: global }),
    add("control_repeat", { TIMES: num(3), SUBSTACK: ref(body) }),
    add(
      "procedures_call",
      { ARG0: num(4), ARG1: ref(condition) },
      {},
      { mutation: { proccode: "advance %s %b", argumentids: '["ARG0","ARG1"]', warp: "true" } },
    ),
    add("event_broadcastandwait", { BROADCAST_INPUT: [1, [11, "go", "M"]] }),
    add("control_create_clone_of", { CLONE_OPTION: [1, menu] }),
  );
  const prototype = add(
    "procedures_prototype",
    {},
    {},
    {
      shadow: true,
      mutation: {
        proccode: "advance %s %b",
        argumentids: '["ARG0","ARG1"]',
        argumentnames: '["steps","enabled"]',
        argumentdefaults: '["",false]',
        warp: "true",
      },
    },
  );
  const arg = add("argument_reporter_string_number", {}, { VALUE: ["steps", null] });
  const bool = add("argument_reporter_boolean", {}, { VALUE: ["enabled", null] });
  top(
    add("procedures_definition", { custom_block: [1, prototype] }),
    add("control_if", {
      CONDITION: ref(bool),
      SUBSTACK: ref(add("motion_changexby", { DX: ref(arg) })),
    }),
  );
  top(
    add("event_whenbroadcastreceived", {}, { BROADCAST_OPTION: ["go", "M"] }),
    add("motion_changeyby", { DY: num(7) }),
  );
  top(
    add("event_whenkeypressed", {}, { KEY_OPTION: ["right arrow", null] }),
    add("motion_changexby", { DX: num(3) }),
  );
  top(add("event_whenthisspriteclicked"), add("looks_say", { MESSAGE: text("Imported click") }));
  top(
    add("control_start_as_clone"),
    add("motion_sety", { Y: num(70) }),
    add("control_wait", { DURATION: num(0.1) }),
    add("control_delete_this_clone"),
  );
  return {
    isStage: false,
    name: "Runner",
    blocks,
    variables: { L: ["score", 5] },
    lists: { LL: ["trail", []] },
    broadcasts: { M: "go" },
    x: 10,
    y: 20,
    size: 80,
    direction: 90,
    visible: true,
    currentCostume: 0,
    layerOrder: 1,
    rotationStyle: "all around",
    costumes: [],
  };
}
async function importArchive(data, name, choice) {
  const pending = page.evaluate(
    async ({ data, name }) => {
      // Exercise the original ZIP writer and original ZIP/file importer end-to-end.
      const cv = document.createElement("canvas");
      cv.width = cv.height = 16;
      cv.getContext("2d").fillStyle = "#ff6600";
      cv.getContext("2d").fillRect(0, 0, 16, 16);
      const asset = b2u(cv.toDataURL().split(",")[1]);
      const targets = data.targets || [data];
      for (const target of targets)
        target.costumes = [
          {
            name: "costume1",
            md5ext: "fixture.png",
            dataFormat: "png",
            bitmapResolution: 1,
            rotationCenterX: 8,
            rotationCenterY: 8,
          },
        ];
      const zip = zipMake([
        [data.targets ? "project.json" : "sprite.json", te(JSON.stringify(data))],
        ["fixture.png", asset],
      ]);
      await s3in(new File([zip], name));
    },
    { data, name },
  );
  await page.getByRole("button", { name: choice, exact: true }).click();
  await page.getByRole("button", { name: "OK", exact: true }).waitFor();
  const message = await page.locator("#uidlg").innerText();
  await page.getByRole("button", { name: "OK", exact: true }).click();
  await pending;
  assert.ok(!message.includes("読み込みに失敗"), message);
  return message;
}
try {
  await page.goto((process.env.PREVIEW_URL || "http://localhost:3000") + "/index.html");
  await page.waitForFunction(() => !!window.SCN);
  await page.evaluate(() => {
    SCN.open();
    SCN.addObj(C(), "Existing");
    SCN.close();
  });
  const original = runner();
  await check(
    "sprite3 original archive import reflects six editable scripts without auto-executing",
    async () => {
      const message = await importArchive(original, "runner.sprite3", "新しいスプライトとして追加");
      assert.ok(message.includes("6本のスクリプト"), message);
      assert.ok(!message.includes("注意:"), message);
      const state = await page.evaluate(() => {
        const o = SCN.scene().objs.find((o) => o.name === "Runner");
        return {
          objects: SCN.scene().objs.length,
          scripts: o.sc.length,
          x: o.x,
          y: o.y,
          size: o.size,
          defs: SCN.scene().defs.length,
          running: !!SCN.rt,
          vars: o.vars,
          globals: SCN.scene().gvars,
          original: SPS.find((s) => s.n === "Runner").ex.blocks,
        };
      });
      assert.equal(state.objects, 2);
      assert.equal(state.scripts, 6);
      assert.deepEqual(
        [state.x, state.y, state.size, state.defs, state.running],
        [10, 20, 80, 1, false],
      );
      assert.deepEqual(state.vars, { "score (2)": 5 });
      assert.deepEqual(state.globals, { score: 0 });
      assert.deepEqual(state.original, original.blocks);
    },
  );
  await check(
    "flag, nested repeat/reporters, procedures/boolean args, globals/locals, lists and broadcasts execute",
    async () => {
      await page.evaluate(() => {
        SCN.open();
        SCN.flag();
      });
      await page.waitForFunction(() => SCN.rt.threads.length === 0 && SCN.rt.clones === 0);
      const result = await page.evaluate(() => {
        const T = SCN.rt.list.find((t) => t.name === "Runner");
        return {
          x: T.x,
          y: T.y,
          vars: T.vars,
          lists: T.lists,
          global: SCN.rt.g.score,
          error: SCN.rt.err?.message,
        };
      });
      assert.deepEqual([result.x, result.y, result.global], [20, 27, "10"]);
      assert.deepEqual(result.vars, { "score (2)": 8 });
      assert.deepEqual(result.lists, { trail: [6, 7, 8] });
      assert.equal(result.error, undefined);
    },
  );
  await check("imported key and click events work", async () => {
    await page.keyboard.press("ArrowRight");
    await page.waitForFunction(() => SCN.rt.list.find((t) => t.name === "Runner").x === 23);
    await page.evaluate(() => SCN.click(263, 153));
    await page.waitForFunction(
      () => SCN.rt.list.find((t) => t.name === "Runner").say?.t === "Imported click",
    );
    await page.evaluate(() => SCN.close());
  });
  await check("costume-only sprite3 mode preserves existing scene and programs", async () => {
    const before = await page.evaluate(() => JSON.stringify(SCN.pack()));
    const msg = await importArchive(
      original,
      "costumes.sprite3",
      "現在のスプライトにコスチュームを追加",
    );
    const after = await page.evaluate(() => JSON.stringify(SCN.pack()));
    assert.equal(after, before);
    assert.ok(msg.includes("画像のみ"));
  });
  await check("manually adding an imported sprite also reflects its program", async () => {
    const result = await page.evaluate(() => {
      SCN.open();
      const sp = SPS.find((s) => s.n === "Runner");
      const o = SCN.addObj(sp.cs[0], "Manual copy");
      const result = { scripts: o.sc.length, x: o.x, vars: o.vars, defs: SCN.scene().defs.length };
      SCN.close();
      return result;
    });
    assert.equal(result.scripts, 6);
    assert.equal(result.defs, 2);
    assert.equal(result.vars["score (2)"], 5);
    const roundtrip = await page.evaluate(async () => {
      const before = JSON.stringify(SCN.scene().defs);
      await loadAsync(ser());
      SCN.open();
      const after = JSON.stringify(SCN.scene().defs);
      const calls = SCN.scene()
        .objs.flatMap((o) => o.sc.flatMap((s) => s.b))
        .filter((b) => b.op.startsWith("pc:"))
        .map((b) => b.op.slice(3));
      const defined = SCN.scene().defs.map((d) => d.id);
      SCN.close();
      return {
        before,
        after,
        validCalls: calls.length === 2 && calls.every((id) => defined.includes(id)),
      };
    });
    assert.equal(roundtrip.before, roundtrip.after);
    assert.ok(roundtrip.validCalls);
  });
  const stageGraph = builder(),
    first = builder(),
    second = builder();
  stageGraph.top(
    stageGraph.add("event_whenflagclicked"),
    stageGraph.add("data_setvariableto", { VALUE: num(40) }, { VARIABLE: ["shared", "G"] }),
  );
  first.top(
    first.add("event_whenflagclicked"),
    first.add("event_broadcastandwait", { BROADCAST_INPUT: [1, [11, "ping", "M"]] }),
    first.add("data_changevariableby", { VALUE: num(2) }, { VARIABLE: ["shared", "G"] }),
  );
  second.top(
    second.add("event_whenbroadcastreceived", {}, { BROADCAST_OPTION: ["ping", "M"] }),
    second.add("data_changevariableby", { VALUE: num(3) }, { VARIABLE: ["shared", "G"] }),
  );
  const project = {
    targets: [
      {
        ...runner(),
        name: "Receiver",
        blocks: second.blocks,
        variables: {},
        lists: {},
        layerOrder: 2,
      },
      {
        isStage: true,
        name: "Stage",
        blocks: stageGraph.blocks,
        variables: { G: ["shared", 0] },
        lists: { GL: ["global list", ["a"]] },
        broadcasts: { M: "ping" },
        currentCostume: 0,
      },
      {
        ...runner(),
        name: "Sender",
        blocks: first.blocks,
        variables: {},
        lists: {},
        layerOrder: 1,
      },
    ],
    extensions: [],
    monitors: [],
  };
  await check(
    "sb3 imports stage + all sprite programs, globals, and layer order into a replacement scene",
    async () => {
      const msg = await importArchive(project, "broadcast.sb3", "置き換えて読み込む");
      assert.ok(msg.includes("3本のスクリプト"), msg);
      const result = await page.evaluate(() => ({
        names: SCN.scene().objs.map((o) => o.name),
        stage: SCN.scene().objs[0].stage,
        scripts: SCN.scene().objs.map((o) => o.sc.length),
        globals: SCN.scene().gvars,
        lists: SCN.scene().glists,
      }));
      assert.deepEqual(result, {
        names: ["Stage", "Sender", "Receiver"],
        stage: true,
        scripts: [1, 1, 1],
        globals: { shared: 0 },
        lists: { "global list": ["a"] },
      });
      await page.evaluate(() => {
        SCN.open();
        SCN.flag();
      });
      await page.waitForFunction(() => SCN.rt.threads.length === 0);
      assert.equal(await page.evaluate(() => SCN.rt.g.shared), 45);
    },
  );
  await check("converted programs and stage identity survive JSON save/load", async () => {
    const result = await page.evaluate(async () => {
      SCN.close();
      const serialized = ser(),
        before = SCN.scene().objs.map((o) => JSON.stringify(o.sc.map((s) => s.b)));
      await loadAsync(serialized);
      SCN.open();
      const after = SCN.scene().objs.map((o) => JSON.stringify(o.sc.map((s) => s.b)));
      const stage = SCN.scene().objs[0].stage;
      SCN.flag();
      return { before, after, stage };
    });
    assert.deepEqual(result.before, result.after);
    assert.ok(result.stage);
    await page.waitForFunction(() => SCN.rt.threads.length === 0);
    assert.equal(await page.evaluate(() => SCN.rt.g.shared), 45);
  });
  await check(
    "unsupported blocks remain visible, report opcode, preserve originals and halt that script",
    async () => {
      const unsupported = builder();
      unsupported.top(
        unsupported.add("event_whenflagclicked"),
        unsupported.add("music_playNoteForBeats", { NOTE: num(60), BEATS: num(1) }),
        unsupported.add("motion_setx", { X: num(999) }),
      );
      const msg = await importArchive(
        { ...runner(), name: "Unsupported", blocks: unsupported.blocks },
        "unsupported.sprite3",
        "新しいスプライトとして追加",
      );
      assert.ok(msg.includes("music_playNoteForBeats"), msg);
      const result = await page.evaluate(() => {
        const o = SCN.scene().objs.find((o) => o.name === "Unsupported");
        const saved = SPS.find((s) => s.n === "Unsupported").ex.blocks;
        const ops = o.sc[0].b.map((b) => b.op);
        SCN.flag();
        return { ops, saved };
      });
      assert.deepEqual(result.ops, ["event_whenflag", "scratch_unsupported", "motion_xset"]);
      assert.deepEqual(result.saved, unsupported.blocks);
      await page.waitForFunction(() => !!SCN.rt.err);
      assert.equal(
        await page.evaluate(() => SCN.rt.list.find((t) => t.name === "Unsupported").x),
        10,
      );
      await page.evaluate(() => SCN.close());
    },
  );
  await check(
    "cyclic block graphs terminate with a warning instead of hanging import",
    async () => {
      const result = await page.evaluate(() => {
        const s = SCN.newScene("cycle");
        const conv = ScratchProgramImport.convert(
          {
            blocks: {
              flag: { opcode: "event_whenflagclicked", topLevel: true, next: "cycle" },
              cycle: {
                opcode: "control_repeat",
                next: "cycle",
                inputs: { TIMES: [1, [4, "2"]], SUBSTACK: [2, "cycle"] },
              },
            },
          },
          {
            registry: SCN.BK,
            makeId: SCN.uid,
            globalVars: s.gvars,
            globalLists: {},
            globalVarIds: new Map(),
            globalListIds: new Map(),
          },
        );
        return conv.warnings;
      });
      assert.ok(result.some((s) => /cyclic/.test(s)));
    },
  );
  // Loading extension code remains an explicit trust decision, never inferred from project IDs.
  if (process.env.TEXT_SOURCE) {
    const code = await readFile(process.env.TEXT_SOURCE, "utf8");
    await check(
      "already-loaded Animated Text blocks import through registered argument names",
      async () => {
        const result = await page.evaluate((code) => {
          const src = SCN.H.extensions.load(code, { name: "Animated Text" });
          const scene = SCN.newScene("Extension");
          const converted = ScratchProgramImport.convert(
            {
              blocks: {
                flag: { opcode: "event_whenflagclicked", topLevel: true, next: "show" },
                show: {
                  opcode: "text_setText",
                  inputs: { TEXT: [1, [10, "Imported text"]] },
                  next: null,
                },
              },
            },
            {
              registry: SCN.BK,
              makeId: SCN.uid,
              globalVars: scene.gvars,
              globalLists: {},
              globalVarIds: new Map(),
              globalListIds: new Map(),
            },
          );
          SCN.close();
          const o = SCN.test.newObj(C(), "Imported extension");
          o.sc = converted.scripts;
          scene.objs.push(o);
          SCN.S.scenes = [scene];
          SCN.S.cur = 0;
          window.importedTextSource = src;
          SCN.open();
          SCN.flag();
          return converted;
        }, code);
        assert.deepEqual(result.warnings, []);
        assert.equal(result.scripts[0].b[1].op, "text.setText");
        assert.deepEqual(result.scripts[0].b[1].in, { A0: "Imported text" });
        await page.waitForFunction(() => SCN.rt.threads.length === 0);
        const displayed = await page.evaluate(() => {
          SCN.drawNow();
          const target = importedTextSource.rt.targets[0];
          const skin = importedTextSource.canvas.renderer._allDrawables[target.drawableID].skin;
          return { text: skin.text, width: skin.canvas.width, error: SCN.rt.err?.message };
        });
        assert.equal(displayed.text, "Imported text");
        assert.ok(displayed.width > 0);
        assert.equal(displayed.error, undefined);
      },
    );
  }
  assert.deepEqual(errors, []);
  console.log(`PASS ${checks.length} checks, no uncaught page errors`);
} finally {
  await browser.close();
}
