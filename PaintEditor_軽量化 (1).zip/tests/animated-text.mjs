// Serve the project root first (e.g. `python3 -m http.server 3000`). playwright-core may be installed outside the app.
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { createHash } from "node:crypto";

const { chromium } = await import(process.env.PLAYWRIGHT_MODULE || "playwright-core");
const code = process.env.TEXT_SOURCE
  ? await readFile(process.env.TEXT_SOURCE, "utf8")
  : await (await fetch("https://extensions.turbowarp.org/lab/text.js")).text();
assert.match(code, /class TextCostumeSkin extends Skin/);
console.log("Official source SHA256:", createHash("sha256").update(code).digest("hex"));
const browser = await chromium.launch({
  executablePath: process.env.CHROMIUM || "/usr/bin/chromium",
  args: ["--no-sandbox"],
});
const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
const errors = [];
page.on("pageerror", (e) => errors.push(e.message));
page.on("console", (msg) => {
  if (msg.type() === "error" && msg.text().includes("[拡張機能]")) errors.push(msg.text());
});
const checks = [];
async function check(name, fn) {
  await fn();
  checks.push(name);
  console.log("PASS", name);
}
try {
  await page.goto((process.env.PREVIEW_URL || "http://localhost:3000") + "/index.html");
  await page.waitForFunction(() => !!window.SCN);
  await page.evaluate(() => {
    SCN.open();
    const c = C();
    // Draw through the existing bitmap engine without replacing any renderer.
    const bitmap = {
      n: "Regression bitmap",
      k: "b",
      w: 32,
      h: 32,
      cx: 16,
      cy: 16,
      res: 1,
      bc: document.createElement("canvas"),
      sh: [],
    };
    bitmap.bc.width = bitmap.bc.height = 32;
    bitmap.bc.getContext("2d").fillStyle = "#ff0000";
    bitmap.bc.getContext("2d").fillRect(0, 0, 32, 32);
    cs.push(bitmap);
    SCN.reindex();
    SCN.addObj(bitmap, "First");
    SCN.addObj(c, "Second");
    SCN.flag();
    window.testEnv = {
      bitmap,
      hash() {
        SCN.drawNow();
        const cv = document.querySelector("#scs");
        const data = cv.getContext("2d").getImageData(0, 0, cv.width, cv.height).data;
        let h = 2166136261,
          colored = 0;
        for (let i = 0; i < data.length; i++) h = Math.imul(h ^ data[i], 16777619);
        for (let i = 0; i < data.length; i += 4)
          if (data[i] < 240 || data[i + 1] < 240 || data[i + 2] < 240) colored++;
        return { h, colored };
      },
    };
    testEnv.baseline = testEnv.hash();
  });
  await check("normal bitmap Canvas rendering before extension", async () => {
    assert.ok((await page.evaluate(() => testEnv.baseline.colored)) > 500);
  });
  await check(
    "existing sample loads through original dialog and executes registered blocks",
    async () => {
      await page.evaluate(() => SCN.H.exDialog());
      await page.locator(".ex-tabs").getByRole("button", { name: "テキスト", exact: true }).click();
      await page.getByRole("button", { name: "サンプルを入れる", exact: true }).click();
      await page.evaluate(() => {
        const code = document.querySelector(".ex-dl textarea").value;
        testEnv.sample = SCN.H.extensions.load(code, { name: "Sample" });
        document.querySelector(".sc-ov").remove();
        const T = SCN.rt.list[0],
          d = SCN.BK["sampleext.greet"];
        const value = d.fn(T, { A0: "こんにちは", A1: "ネコ" }, {});
        if (value !== "こんにちは ネコさん") throw Error("sample reporter regression");
        if (!SCN.BK["sampleext.isEven"].fn(T, { A0: 4 }, {}))
          throw Error("sample boolean regression");
        const script = {
          id: "sample-regression",
          b: [
            { op: "event_whenflag", in: {} },
            {
              op: "sampleext.times",
              in: { A0: 3 },
              c: { SUB: [{ op: "sampleext.diag", in: { A0: 10 } }] },
            },
          ],
        };
        SCN.startScript(T, script);
      });
      await page.waitForFunction(() => SCN.rt.threads.length === 0);
      const xy = await page.evaluate(() => [SCN.rt.list[0].x, SCN.rt.list[0].y]);
      assert.ok(Math.abs(xy[0] - 30 / Math.SQRT2) < 1e-6);
      assert.equal(xy[0], xy[1]);
      await page.evaluate(() => {
        SCN.rt.list[0].x = SCN.rt.list[0].y = 0;
      });
    },
  );
  await check("unmodified official Animated Text registers with renderer exports", async () => {
    const info = await page.evaluate((code) => {
      const src = SCN.H.extensions.load(code, {
        name: "Official Animated Text",
        url: "https://extensions.turbowarp.org/lab/text.js",
      });
      Object.assign(testEnv, { src, ext: src.exts[0].inst, target: src.rt.targets[0] });
      testEnv.util = { target: testEnv.target, runtime: src.rt };
      return { id: src.exts[0].id, blocks: src.exts[0].ops.length, warnings: src.exts[0].warn };
    }, code);
    assert.equal(info.id, "text");
    assert.ok(info.blocks >= 20);
    assert.deepEqual(info.warnings, []);
  });
  await check("text pixels, text color and outlined multiline wrapping", async () => {
    const result = await page.evaluate(() => {
      const e = testEnv;
      e.ext.setText({ TEXT: "Hello Canvas" }, e.util);
      e.ext.setColor({ COLOR: "#0000ff" }, e.util);
      e.ext.setWidth({ WIDTH: 220, ALIGN: "center" }, e.util);
      const before = e.hash();
      const d = e.src.canvas.renderer._allDrawables[e.target.drawableID],
        s = d.skin;
      const image = s.canvas
        .getContext("2d")
        .getImageData(0, 0, s.canvas.width, s.canvas.height).data;
      let blue = 0;
      for (let i = 0; i < image.length; i += 4)
        if (image[i + 2] > 200 && image[i] < 20 && image[i + 3] > 100) blue++;
      e.ext.setOutlineWidth({ WIDTH: 2 }, e.util);
      e.ext.addLine({ TEXT: "日本語 longwordwrappingcheck" }, e.util);
      e.ext.setWidthValue({ WIDTH: 100 }, e.util);
      e.hash();
      return {
        blue,
        rendered: before.h !== e.baseline.h,
        lines: e.ext.getLinesV2({ WITH_WORD_WRAP: "with word wrap" }, e.util),
      };
    });
    assert.ok(result.blue > 30);
    assert.ok(result.rendered);
    assert.ok(result.lines >= 3);
  });
  for (const mode of ["rainbow", "zoom", "shake", "type"]) {
    await check(`${mode}: actual Canvas updates over time and Promise finishes`, async () => {
      const first = await page.evaluate((mode) => {
        const e = testEnv;
        e.ext.setWidth({ WIDTH: 260, ALIGN: "center" }, e.util);
        e.ext.setTypeDelay({ NUM: 0.04 }, e.util);
        e.ext.setAnimateDuration({ ANIMATE: mode, NUM: 0.6 }, e.util);
        e.done = false;
        e.ext.animateText({ TEXT: "Animation testing", ANIMATE: mode }, e.util).then(() => {
          e.done = true;
        });
        const h = e.hash();
        const s = e.src.canvas.renderer._allDrawables[e.target.drawableID].skin;
        return { h: h.h, text: s.text, center: [...s.rotationCenter] };
      }, mode);
      await page.waitForTimeout(170);
      const second = await page.evaluate(() => {
        const e = testEnv,
          s = e.src.canvas.renderer._allDrawables[e.target.drawableID].skin;
        return {
          h: e.hash().h,
          text: s.text,
          center: [...s.rotationCenter],
          active: e.ext.isAnimating({}, e.util),
        };
      });
      assert.ok(second.active);
      if (mode === "shake") assert.notDeepEqual(second.center, first.center);
      else assert.notEqual(second.h, first.h);
      if (mode === "type") assert.ok(second.text.length > first.text.length);
      await page.waitForFunction(() => testEnv.done);
      assert.equal(await page.evaluate(() => testEnv.ext.isAnimating({}, testEnv.util)), false);
    });
  }
  await check("rainbow creates multicolor gradient pixels", async () => {
    const count = await page.evaluate(() => {
      const e = testEnv;
      e.ext.animateText({ TEXT: "Rainbow gradient", ANIMATE: "rainbow" }, e.util);
      e.hash();
      const s = e.src.canvas.renderer._allDrawables[e.target.drawableID].skin;
      const data = s.canvas
        .getContext("2d")
        .getImageData(0, 0, s.canvas.width, s.canvas.height).data;
      const colors = new Set();
      for (let i = 0; i < data.length; i += 4)
        if (data[i + 3] > 240)
          colors.add([data[i] >> 5, data[i + 1] >> 5, data[i + 2] >> 5].join());
      return colors.size;
    });
    assert.ok(count > 10);
  });
  await check(
    "position, size, visibility, ghost, multiple independent targets and order",
    async () => {
      const results = await page.evaluate(() => {
        const e = testEnv,
          second = e.src.rt.targets[1],
          u2 = { target: second, runtime: e.src.rt };
        e.ext.setText({ TEXT: "First" }, e.util);
        e.ext.setText({ TEXT: "Second" }, u2);
        e.ext.setColor({ COLOR: "#ff0000" }, e.util);
        e.ext.setColor({ COLOR: "#0000ff" }, u2);
        e.target.setXY(-90, 40);
        second.setXY(90, -40);
        const multiple = e.hash().h;
        second.setVisible(false);
        const hidden = e.hash().h;
        second.setVisible(true);
        const visible = e.hash().h;
        second.setSize(160);
        const sized = e.hash().h;
        second.setXY(-90, 40);
        const overlap = e.hash().h;
        SCN.BK.looks_layer.fn(SCN.rt.list[1], { D: "b", N: 1 });
        const reordered = e.hash().h;
        SCN.rt.list.find((t) => t.name === "Second").ghost = 100;
        const transparent = e.hash().h;
        return { multiple, hidden, visible, sized, overlap, reordered, transparent };
      });
      assert.equal(results.multiple, results.visible);
      assert.notEqual(results.hidden, results.multiple);
      assert.notEqual(results.sized, results.visible);
      assert.notEqual(results.overlap, results.reordered);
      assert.notEqual(results.transparent, results.reordered);
    },
  );
  await check(
    "native clone creation invokes official makeClone patch and owns independent skin",
    async () => {
      const result = await page.evaluate(() => {
        const e = testEnv,
          T = e.target.nativeTarget;
        const n = SCN.H.createClone(T, "_myself_");
        const clone = e.src.rt.targets.find((t) => t.id === n.id);
        const r = e.src.canvas.renderer,
          originalSkin = r._allDrawables[e.target.drawableID].skin;
        const cloneSkin = r._allDrawables[clone.drawableID].skin;
        e.ext.setText({ TEXT: "Clone independent" }, { target: clone, runtime: e.src.rt });
        clone.setXY(60, 80);
        const rendered = e.hash().colored;
        const originalText = originalSkin.text;
        const id = cloneSkin.id;
        e.ext.animateText(
          { TEXT: "Delete during typing", ANIMATE: "type" },
          { target: clone, runtime: e.src.rt },
        );
        SCN.H.deleteClone(n, {});
        return {
          independent: originalSkin !== cloneSkin,
          originalText,
          rendered,
          freed: !r._allSkins[id],
          canvasFreed: cloneSkin.canvas === null,
          typingCancelled: !cloneSkin.isTyping,
        };
      });
      assert.ok(result.independent && result.freed && result.canvasFreed && result.typingCancelled);
      assert.equal(result.originalText, "First");
      assert.ok(result.rendered > 100);
    },
  );
  await check(
    "show sprite restores costume and extension deletion releases textures/timers",
    async () => {
      const result = await page.evaluate(() => {
        const e = testEnv;
        e.ext.clearText({}, e.util);
        const cleared = !e.ext.textActive({}, e.util);
        e.ext.animateText({ TEXT: "unload running", ANIMATE: "type" }, e.util);
        e.hash();
        const renderer = e.src.canvas.renderer;
        const skin = renderer._allDrawables[e.target.drawableID].skin;
        const texture = skin._texture;
        SCN.H.extensions.unload(e.src, true);
        return {
          cleared,
          noSkins: renderer._allSkins.filter(Boolean).length === 0,
          noTextures: texture.disposed,
          cancelled: !skin.isTyping,
          sampleKept: !!SCN.BK["sampleext.greet"],
        };
      });
      assert.deepEqual(result, {
        cleared: true,
        noSkins: true,
        noTextures: true,
        cancelled: true,
        sampleKept: true,
      });
      await page.waitForTimeout(120);
    },
  );
  await check("reload does not stack clone hooks; reset releases all target data", async () => {
    const result = await page.evaluate((code) => {
      const src = SCN.H.extensions.load(code, { name: "Reload" });
      const ext = src.exts[0].inst,
        target = src.rt.targets.find((t) => t.getName() === "First");
      ext.setText({ TEXT: "Reloaded" }, { target, runtime: src.rt });
      target.makeClone();
      testEnv.hash();
      const count = src.canvas.renderer._allSkins.filter(Boolean).length;
      SCN.reset();
      const released =
        src.canvas.renderer._allSkins.filter(Boolean).length === 0 &&
        src.canvas.renderer._allDrawables.filter(Boolean).length === 0;
      SCN.H.extensions.unload(src, true);
      return { count, released };
    }, code);
    assert.equal(result.count, 2);
    assert.ok(result.released);
  });
  await check(
    "project + scene serialization roundtrip preserves bitmap pixels and blocks",
    async () => {
      const loading = page.evaluate(async () => {
        const before = testEnv.bitmap.bc.toDataURL();
        const scene = SCN.test.exportScenes(true);
        const serialized = ser();
        const packed = JSON.parse(serialized);
        // Existing async importer and scene reference rebinding, not an alternative serializer.
        await loadAsync(serialized);
        SCN.open();
        const bitmap = AC().find((c) => c.n === "Regression bitmap");
        const after = bitmap.bc.toDataURL();
        const hasSample = !!SCN.BK["sampleext.greet"];
        const sceneJSON = JSON.parse(scene);
        return {
          pixelsSame: before === after,
          costumes: packed.sp.length,
          sceneObjects: sceneJSON.scenes[0].objs.length,
          hasSample,
          loadedObjects: SCN.scene().objs.length,
          kind: sceneJSON.kind,
        };
      });
      await page.getByRole("button", { name: "実行を許可", exact: true }).click();
      const result = await loading;
      assert.ok(result.pixelsSame);
      assert.equal(result.sceneObjects, 2);
      assert.equal(result.loadedObjects, 2);
      assert.equal(result.kind, "ced-scene");
      assert.ok(result.hasSample);
    },
  );
  assert.deepEqual(errors, []);
  console.log(`PASS ${checks.length} checks, no extension/page errors`);
} finally {
  await browser.close();
}
