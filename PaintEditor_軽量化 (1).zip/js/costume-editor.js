/* ======================================================================
   costume-editor.js — コスチュームエディター本体
   描画・図形・ビットマップ・保存/読込(.sprite3/.sb3)・ブール演算(Paper.js)・
   オフセットパス・文字のベクター化・メニューバー 等。
   （旧 paint-editor.html の1つ目の <script> をそのまま移動）
   ====================================================================== */
const $=s=>document.querySelector(s),cv=$('#cv'),g=cv.getContext('2d');
let cs=[],ci=0,tool='sel',sel=[],z=1,ox=0,oy=0,multi=0,tmp=null,drag=null,dirty=0,band=null,gid=1,curShape=0,fonts=[],selPt=-1,gm='s',clip=null;
const C=()=>cs[ci],rep=(k,v)=>k=='im'?undefined:v,esc=s=>String(s).replace(/[&<>"]/g,m=>'&#'+m.charCodeAt(0)+';');

/* ===== 複数スプライト =====
   cs / ci は「いま編集中のスプライト」のコスチューム配列と番号(従来の編集処理はそのまま動く)。他のスプライトは SPS に退避する。
   ex = Scratchのターゲット情報(ブロック・変数・サウンドの定義・位置など。読み込んだものをそのまま保持して書き出す)、snd = サウンドファイル */
const SPD=()=>({variables:{},lists:{},broadcasts:{},blocks:{},comments:{},volume:100,layerOrder:1,visible:true,x:0,y:0,size:100,direction:90,draggable:false,rotationStyle:'all around'}),STD=()=>({variables:{},lists:{},broadcasts:{},blocks:{},comments:{},volume:100,layerOrder:0,tempo:60,videoTransparency:50,videoState:'on',textToSpeechLanguage:null});
let SPS=[{n:'スプライト1',cs:null,ci:0,ex:SPD(),snd:{},stage:false}],SPI=0,PRJ={monitors:[],extensions:[]};
const BLANK_BD="<svg version=\"1.1\" width=\"2\" height=\"2\" viewBox=\"-1 -1 2 2\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\">\n  <!-- Exported by Scratch - http://scratch.mit.edu/ -->\n</svg>";
function spSave(){const s=SPS[SPI];if(s){s.cs=cs;s.ci=ci}}
const AC=()=>{spSave();return SPS.flatMap(s=>s.cs||[])};
const u2b=u=>{let s='';for(let i=0;i<u.length;i+=0x8000)s+=String.fromCharCode.apply(null,u.subarray(i,i+0x8000));return btoa(s)},b2u=b=>Uint8Array.from(atob(b),c=>c.charCodeAt(0));
function cpName(n,used){used=used||new Set(cs.map(c=>c.n));const m=n.match(/^(.*?)(\d+)$/),b=m?m[1]:n;let k=m?+m[2]+1:2;while(used.has(b+k))k++;return b+k}
function spUnique(n,skip){const used=new Set(SPS.filter(s=>s!==skip).map(s=>s.n));if(!used.has(n)&&n!='Stage')return n;const m=n.match(/^(.*?)(\d+)$/),b=m?m[1]:n;let k=m?+m[2]+1:2;while(used.has(b+k)||b+k=='Stage')k++;return b+k}
/* スプライトタブのサムネイル(最後に開いていたコスチューム) */
function spThumb(t,c){if(!t||!c)return;try{const x=t.getContext('2d');x.clearRect(0,0,72,54);const bb=thumbBox(c),bx=bb?bb[0]:0,by=bb?bb[1]:0,bw=bb?bb[2]-bb[0]:c.w,bh=bb?bb[3]-bb[1]:c.h,k=Math.min(72/bw,54/bh);x.save();x.imageSmoothingEnabled=!(bb&&k>=1&&c.k=='b');x.translate((72-bw*k)/2,(54-bh*k)/2);x.scale(k,k);x.translate(-bx,-by);dc(x,c);x.restore()}catch(e){}}
function spThumbCur(){clearTimeout(spThumbCur.t);spThumbCur.t=setTimeout(()=>{const t=document.querySelector('#spl .sp.on canvas');if(t&&cs[ci])spThumb(t,cs[ci])},250)}
function spLeave(){if(TE)teEnd();bcommit();sel=[];selPt=-1;pvClear()}
function spSwitch(k){if(k==SPI||!SPS[k])return;spLeave();spSave();SPI=k;cs=SPS[k].cs;ci=Math.min(SPS[k].ci,cs.length-1);list.force=1;go(ci);spUI()}
/* ファイル: スプライト名を「〇〇//□□」と付けると、〇〇ファイルの中の□□として一覧にまとめる(名前はそのまま保存・書き出し)。ファイルをタップで開閉 */
/* コスチューム一覧のファイル(名前 〇〇//□□ の「〇〇」が同じで連続するコスチュームを1つにまとめる。並び順は変えない) */
const CIS=()=>[...$('#list').children].filter(e=>e.classList.contains('ci')),CFO=new Set();
function cfOpenCur(){const c=C(),f=c&&spFile(c.n);if(f)CFO.add(f)}
function cfLayout(force){const L=$('#list');if(!L)return;const ci_=CIS();if(ci_.length!=cs.length)return;const sig=cs.map(c=>c.n).join('\u0001')+'|'+[...CFO].join(',')+'|'+ci;if(!force&&L._sig===sig)return;L._sig=sig;
L.querySelectorAll(':scope>.cf').forEach(e=>e.remove());let prev=null;
ci_.forEach((d,i)=>{const f=spFile(cs[i].n);d.classList.remove('cfh','cfm');if(!f){prev=null;return}d.classList.add('cfm');const open=CFO.has(f);
if(prev!==f){let m=0;while(i+m<cs.length&&spFile(cs[i+m].n)===f)m++;const h=document.createElement('button');h.type='button';h.className='cf'+(open?' open':'')+(ci>=i&&ci<i+m?' has':'');
h.innerHTML='<b class="ar"></b><svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><path d="M3 6.5A1.5 1.5 0 0 1 4.5 5H9l2 2.5h8.5A1.5 1.5 0 0 1 21 9v9.5a1.5 1.5 0 0 1-1.5 1.5h-15A1.5 1.5 0 0 1 3 18.5z" fill="currentColor" opacity=".85"/></svg><span class="fn"></span><small></small>';h.querySelector('.fn').textContent=f;h.lastChild.textContent=m;h.title=f+'ファイル('+m+'個)  タップで'+(open?'閉じる':'開く');h.setAttribute('aria-expanded',open);
h.onclick=()=>{if(CFO.has(f))CFO.delete(f);else CFO.add(f);cfLayout(1)};L.insertBefore(h,d)}
if(!open)d.classList.add('cfh');prev=f});if(!L._sk){L._sk=1;L.addEventListener('scroll',cfStick,{passive:true});addEventListener('resize',cfStick)}cfStick()}
/* 開いているファイルの見出しは position:sticky(ブラウザ任せ=カクつかない)で上端/左端に固定し、
   ファイルの最後のコスチュームが通り過ぎる最後の一瞬だけ、押し出される分だけ動かす */
function cfStick(){const L=$('#list');if(!L)return;const horiz=getComputedStyle(L).flexDirection.startsWith('row');
L.querySelectorAll(':scope>.cf').forEach(h=>{let y=0;if(h.classList.contains('open')){let last=null,e=h.nextElementSibling;while(e&&e.classList.contains('cfm')){last=e;e=e.nextElementSibling}
if(last){const hs=horiz?h.offsetWidth:h.offsetHeight,sc=horiz?L.scrollLeft:L.scrollTop,end=horiz?last.offsetLeft+last.offsetWidth:last.offsetTop+last.offsetHeight;y=Math.max(Math.min(0,end-(sc+hs)),-hs-2)}}
const t=y<0?(horiz?'translateX('+y+'px)':'translateY('+y+'px)'):'';if(h.style.transform!==t)h.style.transform=t;
let st=false;if(y===0&&h.classList.contains('open')){const a=h.getBoundingClientRect(),b=L.getBoundingClientRect();st=horiz?(L.scrollLeft>0&&a.left<=b.left+8):(L.scrollTop>0&&a.top<=b.top+8)}h.classList.toggle('stk',st)})}
const SPO=new Set();
const spFile=n=>{const k=String(n).indexOf('//');if(k<=0)return null;const f=n.slice(0,k).trim();return f&&n.length>k+2?f:null};
const spShort=n=>{const k=String(n).indexOf('//');return spFile(n)?n.slice(k+2).trim()||n:n};
function spUI(keep){const L=$('#spl');if(!L)return;const st=L.scrollTop,sl=L.scrollLeft;
if(!keep){const f=SPS[SPI]&&!SPS[SPI].stage?spFile(SPS[SPI].n):null;if(f)SPO.add(f)}
L.innerHTML='';const seen=new Set();
const chip=(s,i,mem)=>{const b=document.createElement('button');b.type='button';b.className='sp'+(i==SPI?' on':'')+(s.stage?' stg':'')+(mem?' mem':'');b.innerHTML='<canvas width=72 height=54></canvas><span></span>';b.lastChild.textContent=s.stage?'ステージ':spShort(s.n);spThumb(b.firstChild,(i==SPI?cs:s.cs)[i==SPI?ci:s.ci]);b.title=s.stage?'ステージ(背景)':s.n;b.setAttribute('role','tab');b.setAttribute('aria-selected',i==SPI);b.onclick=()=>{if(b._lp){b._lp=0;return}spSwitch(i)};spChipEv(b,i);L.append(b)};
SPS.forEach((s,i)=>{const f=s.stage?null:spFile(s.n);if(!f){chip(s,i,false);return}if(seen.has(f))return;seen.add(f);
const mem=SPS.map((x,j)=>j).filter(j=>!SPS[j].stage&&spFile(SPS[j].n)===f),open=SPO.has(f),h=document.createElement('button');h.type='button';h.className='sf'+(open?' open':'')+(mem.includes(SPI)?' has':'');
h.innerHTML='<b class="ar"></b><svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><path d="M3 6.5A1.5 1.5 0 0 1 4.5 5H9l2 2.5h8.5A1.5 1.5 0 0 1 21 9v9.5a1.5 1.5 0 0 1-1.5 1.5h-15A1.5 1.5 0 0 1 3 18.5z" fill="currentColor" opacity=".85"/></svg><span class="fn"></span><small></small>';h.querySelector('.fn').textContent=f;h.lastChild.textContent=mem.length;h.title=f+'ファイル('+mem.length+'個)  タップで'+(open?'閉じる':'開く');h.setAttribute('aria-expanded',open);
h.onclick=()=>{if(SPO.has(f))SPO.delete(f);else SPO.add(f);spUI(1)};L.append(h);if(open)mem.forEach(j=>chip(SPS[j],j,true))});
const s=SPS[SPI],n=$('#spname');if(document.activeElement!==n)n.value=s.stage?'ステージ':s.n;n.disabled=!!s.stage;$('#spdup').disabled=!!s.stage;$('#spdel').disabled=!!s.stage||SPS.filter(x=>!x.stage).length<2;
if(keep){L.scrollTop=st;L.scrollLeft=sl;return}
const on=L.querySelector('.on');if(on){const l=on.offsetLeft,r=l+on.offsetWidth;if(l<L.scrollLeft)L.scrollLeft=Math.max(0,l-4);else if(r>L.scrollLeft+L.clientWidth)L.scrollLeft=r-L.clientWidth+4;const t=on.offsetTop,u=t+on.offsetHeight;if(t<L.scrollTop)L.scrollTop=Math.max(0,t-4);else if(u>L.scrollTop+L.clientHeight)L.scrollTop=u-L.clientHeight+4}}

/* スプライトのメニュー(右クリック / 長押し): コスチュームと同じ「コピー・書き出し・削除」 */
function spMenu(i,x,y){const s=SPS[i];if(!s)return;cmClose();const m=document.createElement('div');m.id='cmenu';m.setAttribute('role','menu');
const add=(t,fn,dis,cls)=>{const b=document.createElement('button');b.type='button';b.setAttribute('role','menuitem');b.textContent=t;b.disabled=!!dis;if(cls)b.className=cls;b.onclick=()=>{cmClose();fn()};m.append(b)};
const at=()=>{const k=SPS.indexOf(s);if(k<0)return false;spSwitch(k);return true};
add('コピー(複製)',()=>{if(at())spDup()},s.stage);add('書き出し(.sprite3)',()=>{if(at())s3out()},s.stage);add('削除',()=>{if(at())spDel()},s.stage||SPS.filter(z=>!z.stage).length<2,'danger');
document.body.append(m);const r=m.getBoundingClientRect();m.style.left=Math.max(4,Math.min(x,innerWidth-r.width-4))+'px';m.style.top=Math.max(4,Math.min(y,innerHeight-r.height-4))+'px';CM=m;
setTimeout(()=>{if(CM!==m)return;addEventListener('pointerdown',cmOut,true);addEventListener('keydown',cmKey,true);addEventListener('resize',cmClose)},0);const f=m.querySelector('button:not(:disabled)');if(f)f.focus()}
function spChipEv(b,i){b.oncontextmenu=e=>{e.preventDefault();clearTimeout(b._t);spMenu(i,e.clientX,e.clientY)};
b.onpointerdown=e=>{b._lp=0;clearTimeout(b._t);if(e.pointerType=='mouse')return;const x0=e.clientX,y0=e.clientY;b._t=setTimeout(()=>{b._lp=1;spMenu(i,x0,y0)},550)};
b.onpointermove=m=>{if(b._t&&m.pointerType!='mouse'&&Math.abs(m.movementX)+Math.abs(m.movementY)>3)clearTimeout(b._t)};b.onpointerup=b.onpointercancel=()=>clearTimeout(b._t)}
async function spAdd(){let stage=false;if(!SPS.some(s=>s.stage)){const m=await uiDlg('何を追加しますか?',[{t:'キャンセル',v:null},{t:'ステージ(背景)',v:'s'},{t:'スプライト',v:'p'}],{esc:null,focus:2});if(!m)return;stage=m=='s'}
spLeave();spSave();const c=mk('v',stage?'背景1':'コスチューム1'),s={n:stage?'Stage':spUnique('スプライト'+(SPS.filter(x=>!x.stage).length+1)),cs:[c],ci:0,ex:stage?STD():SPD(),snd:{},stage};if(stage){SPS.unshift(s);SPI++}else SPS.push(s);spSwitch(SPS.indexOf(s))}
function spDup(){const s=SPS[SPI];if(!s||s.stage)return;spLeave();spSave();const n=s.cs.map(c=>{const d=mk(c.k,c.n);rs(d,st(c));return d});SPS.splice(SPI+1,0,{n:spUnique(s.n),cs:n,ci:s.ci,ex:JSON.parse(JSON.stringify(s.ex||SPD())),snd:Object.assign({},s.snd),stage:false});spSwitch(SPI+1)}
async function spDel(){const s=SPS[SPI];if(!s)return;if(s.stage||SPS.filter(x=>!x.stage).length<2){await uiAlert(s.stage?'ステージは削除できません':'最後のスプライトは削除できません');return}
if(!await uiConfirm('スプライト「'+s.n+'」を削除しますか?\n(コスチュームもすべて削除されます。元に戻せません)'))return;const k=SPS.indexOf(s);if(k<0)return;spLeave();spSave();SPS.splice(k,1);PRJ.monitors=(PRJ.monitors||[]).filter(m=>m.spriteName!==s.n);SPI=Math.min(k,SPS.length-1);if(SPS[SPI].stage&&SPS.length>1)SPI=Math.min(SPI+1,SPS.length-1);cs=SPS[SPI].cs;ci=Math.min(SPS[SPI].ci,cs.length-1);list.force=1;go(ci);spUI()}
function spInit(){$('#spadd').onclick=spAdd;$('#spdup').onclick=spDup;$('#spdel').onclick=spDel;const n=$('#spname');
n.onkeydown=e=>{e.stopPropagation();if(e.key=='Enter'){e.preventDefault();n.blur()}else if(e.key=='Escape'){e.preventDefault();n.value=SPS[SPI].stage?'ステージ':SPS[SPI].n;n.blur()}};n.onkeyup=e=>e.stopPropagation();
n.onchange=()=>{const s=SPS[SPI];if(!s||s.stage)return;const v=n.value.trim();if(!v){n.value=s.n;n.classList.add('err');setTimeout(()=>n.classList.remove('err'),600);return}const o=s.n;s.n=spUnique(v,s);(PRJ.monitors||[]).forEach(m=>{if(m.spriteName===o)m.spriteName=s.n});n.value=s.n;spUI()};spUI()}
const K=[[-1,-1],[1,-1],[1,1],[-1,1]],EK=[[-1,0],[1,0],[0,-1],[0,1]];
let LVN=4,OP='idle',OPPID=null,PD=null,HC=0,TE=null,TEH=null,TT=null,DT=null,snapG=null,SNAP=true,BG={c:'#ffffff',chk:true},ON={on:false,prev:true,next:true,col:true,op:.35,n:1},ONG=0,SYM=false;
// ===== リアルタイムプレビュー管理(PRV) =====
// 方針: ツール操作中の見た目は「作業コピー」「プレビュー用キャンバス」「追加表示」にだけ反映し、実データ(c.sh / c.bc / 履歴)は確定(pointerup)まで一切変更しない。
//   map : 実図形 → 作業コピー(移動・回転・拡大縮小・点編集・塗り)。描画時は実図形の代わりに、同じ重なり順で作業コピーを描く(二重表示なし)
//   list: 表示する図形リスト全体の差し替え(ベクター消しゴムの結果)
//   bm  : ビットマップの表示用キャンバス(ペン・図形・塗り・範囲の移動変形)。確定時だけ本体へ書き戻す
//   ctr : 中心点の仮位置 / cur: 消しゴムの輪 [x,y,半径] / hv: ホバー表示中の印 / hp: 直前に計算したビットマップ画素
//   (ペン・線・図形・矢印の描きかけは従来どおり tmp に仮図形として持つ。確定時にその図形がそのまま実データになる)
// 描画は paint() の dcv() だけがPRVを見る。保存(ser)・書き出し(svg/PNG)・サムネイル・Undoは dc()/c.sh を使うのでPRVは混入しない
const PRV={map:null,list:null,bm:null,ctr:null,cur:null,hv:null,hp:null,dot:null};
let SJ='round',pvT=0,pvF=null;
const vs=s=>(PRV.map&&PRV.map.get(s))||s;
const pvList=c=>PRV.list||(PRV.map?c.sh.map(vs):c.sh);
const pvClone=s=>{if(s.t=='bs')return{...s};const q=JSON.parse(JSON.stringify(s,rep));if(s.im)q.im=s.im;return q};
function pvStart(L){PRV.map=new Map();L.forEach(s=>{if(s&&!PRV.map.has(s))PRV.map.set(s,pvClone(s))})}
function pvClear(){PRV.map=PRV.list=PRV.bm=PRV.ctr=PRV.cur=PRV.hv=PRV.hp=PRV.dot=null;pvF=null}
// 重い計算(ブール演算・塗りつぶし)は 1フレームに1回だけ、最新の位置で行う
function pvSoon(f){pvF=f;if(pvT)return;pvT=requestAnimationFrame(()=>{pvT=0;const h=pvF;pvF=null;if(h){try{h()}catch(e){}}draw()})}
// ===== アイコン管理(すべてJS内SVG。追加・変更は IC に1行足すだけ) =====
const IC={
sel:'<path d="M6 3l12 8-5.5 1.5L10 18z"/>',rsh:'<path d="M4 19C7 5 17 5 20 19"/><circle cx="4" cy="19" r="2"/><circle cx="20" cy="19" r="2"/><circle cx="12" cy="7" r="2"/>',
brush:'<path d="M15 4l5 5-8 8c-2 2-5 3-8 3 0-3 1-6 3-8z"/>',pen:'<path d="M4 20l1-5L16 4l4 4L9 19z"/><path d="M14 6l4 4"/>',
eras:'<path d="M6 15l8-9 6 6-6 7H9z"/><path d="M10 11l6 6M13 20h8"/>',fill:'<path d="M5 12l7-7 7 7-7 7z"/><path d="M19 15c1 2 2 3 2 4a2 2 0 01-4 0c0-1 1-2 2-4z"/>',
pick:'<path d="M15 4l5 5-3 2-1-1-7 7-4 1 1-4 7-7-1-1z"/>',txt:'<path d="M5 6V4h14v2M12 4v16M9 20h6"/>',
line:'<path d="M5 19L19 5"/><circle cx="5" cy="19" r="1.5"/><circle cx="19" cy="5" r="1.5"/>',ell:'<ellipse cx="12" cy="12" rx="8" ry="6"/>',
rect:'<rect x="4" y="6" width="16" height="12" rx="1.5"/>',poly:'<path d="M12 3l8 6-3 11H7L4 9z"/>',
shp:'<circle cx="8" cy="8" r="4"/><rect x="11" y="11" width="9" height="9" rx="1"/>',arw:'<path d="M4 12h14M12 6l6 6-6 6"/>',
scissors:'<circle cx="6" cy="18" r="2.5"/><circle cx="18" cy="18" r="2.5"/><path d="M8 16L18 4M16 16L6 4"/>',cut:'<rect x="4" y="4" width="16" height="16" rx="2"/><path d="M4 20L20 4" stroke-dasharray="3 2"/>',
hand:'<path d="M12 3v18M3 12h18M12 3l-3 3M12 3l3 3M12 21l-3-3M12 21l3-3M3 12l3-3M3 12l3 3M21 12l-3-3M21 12l-3 3"/>',
ctr:'<circle cx="12" cy="12" r="3"/><path d="M12 3v4M12 17v4M3 12h4M17 12h4"/>',
merge:'<path d="M12 6.8A6 6 0 1 0 12 17.2A6 6 0 1 0 12 6.8z"/>',
mask:'<circle cx="9" cy="12" r="6" opacity=".35"/><circle cx="15" cy="12" r="6" opacity=".35"/><path d="M12 6.8A6 6 0 0 1 12 17.2A6 6 0 0 1 12 6.8z"/>',
sub:'<circle cx="15" cy="12" r="6" opacity=".35"/><path d="M12 6.8A6 6 0 1 0 12 17.2A6 6 0 0 1 12 6.8z"/>',
filter:'<path d="M12 6.8A6 6 0 1 0 12 17.2A6 6 0 1 0 12 6.8z"/><path d="M12 6.8A6 6 0 0 1 12 17.2A6 6 0 0 1 12 6.8z" stroke-dasharray="2 2"/>',
group:'<rect x="3" y="3" width="8" height="8" rx="1"/><rect x="13" y="13" width="8" height="8" rx="1"/><path d="M3 15v6h6M21 9V3h-6" stroke-dasharray="2 2"/>',
ungroup:'<rect x="3" y="3" width="8" height="8" rx="1"/><rect x="13" y="13" width="8" height="8" rx="1"/>',
front:'<rect x="4" y="4" width="11" height="11" rx="1" fill="currentColor" fill-opacity=".25"/><rect x="9" y="9" width="11" height="11" rx="1"/>',
back:'<rect x="9" y="9" width="11" height="11" rx="1" fill="currentColor" fill-opacity=".25"/><rect x="4" y="4" width="11" height="11" rx="1"/>',
dup:'<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 00-1-1H5a1 1 0 00-1 1v10a1 1 0 001 1h3"/>',
del:'<path d="M4 7h16M10 7V4h4v3M6 7l1 13h10l1-13M10 11v6M14 11v6"/>',
undo:'<path d="M9 7L4 12l5 5M4 12h9a6 6 0 010 8H8"/>',redo:'<path d="M15 7l5 5-5 5M20 12h-9a6 6 0 000 8h5"/>',
zin:'<circle cx="11" cy="11" r="6"/><path d="M16 16l5 5M11 8v6M8 11h6"/>',zout:'<circle cx="11" cy="11" r="6"/><path d="M16 16l5 5M8 11h6"/>',
fit:'<path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/>',z1:'<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M9 9l-2 1v5M13 9h4v6h-4z"/>',
save:'<path d="M5 4h11l3 3v13H5z"/><path d="M8 4v5h7V4M8 20v-6h8v6"/>',load:'<path d="M3 7h6l2 2h10v10H3z"/>',
png:'<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="M4 18l5-5 4 4 3-3 4 4"/>',
svg:'<path d="M6 18L12 5l6 13"/><circle cx="6" cy="18" r="1.8"/><circle cx="12" cy="5" r="1.8"/><circle cx="18" cy="18" r="1.8"/>',
bk:'<path d="M4 12a8 8 0 108-8M4 4v5h5M12 8v5l3 2"/>',addv:'<path d="M12 5v14M5 12h14"/><circle cx="19" cy="5" r="2"/>',addb:'<path d="M12 5v14M5 12h14"/><path d="M17 3h4v4h-4z"/>',
ren:'<path d="M3 12l9-9h8v8l-9 9z"/><circle cx="16" cy="8" r="1.5"/>',imp:'<path d="M12 4v11M7 11l5 5 5-5M5 20h14"/>',
multi:'<rect x="3" y="3" width="10" height="10" rx="1" stroke-dasharray="3 2"/><rect x="11" y="11" width="10" height="10" rx="1" stroke-dasharray="3 2"/>',
edit:'<path d="M4 6h9M8.5 6v8"/><path d="M13 20l1-3 6-6 2 2-6 6z"/>',font:'<path d="M5 20L11 4l6 16M7.5 14h7"/>',
addfont:'<path d="M4 20L9 6l5 14M6 15h6M18 4v6M15 7h6"/>',sysfont:'<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4M8 12l2-5 2 5"/>',
fillon:'<rect x="5" y="5" width="14" height="14" rx="2" fill="currentColor"/>',strokeon:'<rect x="5" y="5" width="14" height="14" rx="2" stroke-width="3"/>',
sw:'<path d="M4 6h16M4 12h16M4 18h16" stroke-width="1"/><path d="M4 12h16" stroke-width="3"/>',round:'<path d="M5 19V11a6 6 0 016-6h8"/>',
star:'<path d="M12 3l2.7 6 6.3.6-4.8 4.3 1.5 6.3L12 17l-5.7 3.2 1.5-6.3L3 9.6 9.3 9z"/>',filled:'<rect x="5" y="5" width="14" height="14" rx="2" fill="currentColor"/><rect x="3" y="3" width="18" height="18" rx="3" opacity=".4"/>',
ghor:'<rect x="4" y="5" width="16" height="14" rx="2"/><path d="M9 5v14M14 5v14" stroke-dasharray="1 2.5"/>',gver:'<rect x="4" y="5" width="16" height="14" rx="2"/><path d="M4 10h16M4 15h16" stroke-dasharray="1 2.5"/>',grad:'<rect x="4" y="5" width="16" height="14" rx="2"/><circle cx="12" cy="12" r="2"/><circle cx="12" cy="12" r="5" stroke-dasharray="1 2.5"/>',
grad2:'<rect x="5" y="5" width="14" height="14" rx="2" fill="currentColor" fill-opacity=".45"/>',delpt:'<rect x="4" y="4" width="8" height="8" rx="1"/><path d="M14 14l6 6M20 14l-6 6"/>',
ptmode:'<circle cx="12" cy="12" r="3"/><path d="M3 15c3 0 5-3 9-3s6 3 9 3"/>',bsel:'<rect x="4" y="4" width="13" height="13" rx="1" stroke-dasharray="3 2"/><path d="M12 12l8 3-3.5 1.5L15 20z"/>',
paste:'<rect x="6" y="5" width="12" height="16" rx="2"/><path d="M9 5V3h6v2"/>',bfh:'<path d="M12 3v18" stroke-dasharray="2 2"/><path d="M8 7L3 12l5 5zM16 7l5 5-5 5z"/>',bfv:'<path d="M3 12h18" stroke-dasharray="2 2"/><path d="M7 8l5-5 5 5zM7 16l5 5 5-5z"/>',
_:'<rect x="5" y="5" width="14" height="14" rx="2" stroke-dasharray="3 2"/>'};
IC.fall='<rect x="3" y="3" width="7" height="7" rx="1" fill="currentColor" fill-opacity=".35"/><rect x="14" y="3" width="7" height="7" rx="1" fill="currentColor" fill-opacity=".35"/><rect x="3" y="14" width="7" height="7" rx="1" fill="currentColor" fill-opacity=".35"/><rect x="14" y="14" width="7" height="7" rx="1"/>';
IC.clean='<rect x="4" y="4" width="16" height="16" rx="2" stroke-dasharray="3 2"/><path d="M8 16l8-8M8 12l4-4M12 16l4-4"/>';
IC.ftol='<path d="M4 8h16M4 16h16"/><circle cx="9" cy="8" r="2.4" fill="currentColor"/><circle cx="15" cy="16" r="2.4" fill="currentColor"/>';
IC.brect=IC.rect;IC.bell=IC.ell;IC.bline=IC.line;IC.copy=IC.dup;IC.gsolid=IC.fillon;IC.eyedrop=IC.pick;
Object.assign(IC,{joinm:'<path d="M7 21V7h14" stroke-width="6" stroke-linejoin="miter" stroke-linecap="butt"/>',joinr:'<path d="M7 21V7h14" stroke-width="6" stroke-linejoin="round" stroke-linecap="butt"/>'});
Object.assign(IC,{plus:'<path d="M12 5v14M5 12h14"/>',close:'<path d="M6 6l12 12M18 6L6 18"/>',nofill:'<rect x="5" y="5" width="14" height="14" rx="2"/><path d="M4 20L20 4" stroke="#e33"/>',
checker:'<rect x="4" y="4" width="16" height="16" rx="2"/><path d="M4 12h8V4M12 20v-8h8" fill="currentColor" fill-opacity=".35"/>',aa:'<path d="M4 19C10 19 14 5 20 5"/><path d="M3 21h4M17 3h4"/>',
penround:'<circle cx="12" cy="12" r="6" fill="currentColor"/>',pensquare:'<rect x="6" y="6" width="12" height="12" fill="currentColor"/>',penmarker:'<rect x="3" y="8" width="18" height="8" rx="1" fill="currentColor" fill-opacity=".35"/>',
pencalli:'<path d="M5 19L19 5M9 21l-4-4M19 9l-4-4"/>',penspray:'<circle cx="7" cy="8" r="1"/><circle cx="14" cy="5" r="1"/><circle cx="18" cy="11" r="1"/><circle cx="10" cy="12" r="1"/><circle cx="6" cy="17" r="1"/><circle cx="15" cy="18" r="1"/>',
pendot:'<circle cx="5" cy="12" r="1.8" fill="currentColor"/><circle cx="12" cy="12" r="1.8" fill="currentColor"/><circle cx="19" cy="12" r="1.8" fill="currentColor"/>'});
const ic=(n,s=24)=>`<svg viewBox="0 0 24 24" width="${s}" height="${s}" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">${IC[n]||IC._}</svg>`;
function setB(b,n,t,l){b.innerHTML=ic(n)+(l?`<small>${l}</small>`:'');b.title=t;b.setAttribute('aria-label',t)}
function initIcons(){document.querySelectorAll('[data-i]').forEach(b=>{if(b.tagName=='BUTTON')setB(b,b.dataset.i,b.dataset.t,b.dataset.l);else{b.innerHTML=ic(b.dataset.i);const l=b.parentNode,i=l.querySelector('input');l.title=b.dataset.t;if(i)i.setAttribute('aria-label',b.dataset.t)}})}
const TN={sel:'選択',rsh:'リシェイプ(点の編集)',brush:'ブラシ',pen:'ペン(線を描く)',eras:'消しゴム',fill:'塗りつぶし',txt:'文字',line:'線',ell:'楕円',rect:'長方形(角丸対応)',poly:'多角形・星',shp:'図形ライブラリ',arw:'矢印',cut:'切り取り(直線で分割)',hand:'画面移動',ctr:'中心点を設定',pick:'スポイト',brect:'長方形',bell:'楕円',bline:'線',bsel:'範囲選択(切り取り・コピー・変形)'};
const TV=['sel','rsh','brush','pen','eras','fill','txt','line','ell','rect','poly','shp','arw','cut','hand','ctr'],TB=['bsel','brush','eras','fill','brect','bell','bline','hand','ctr'];
// ===== 図形ライブラリ =====
function nrm(P){const xs=P.map(q=>q[0]),ys=P.map(q=>q[1]),x0=Math.min(...xs),x1=Math.max(...xs),y0=Math.min(...ys),y1=Math.max(...ys);return P.map(q=>[(q[0]-x0)/(x1-x0||1)-.5,(q[1]-y0)/(y1-y0||1)-.5])}
function ngon(n,ind){const P=[];for(let i=0;i<n;i++){const a=-Math.PI/2+i*2*Math.PI/n;P.push([Math.cos(a),Math.sin(a)]);if(ind){const b=a+Math.PI/n,r=1-ind;P.push([r*Math.cos(b),r*Math.sin(b)])}}return nrm(P)}
const PLUS=[[.35,0],[.65,0],[.65,.35],[1,.35],[1,.65],[.65,.65],[.65,1],[.35,1],[.35,.65],[0,.65],[0,.35],[.35,.35]];
const SH=[['図形',[['三角形',ngon(3)],['直角三角形',nrm([[0,0],[0,1],[1,1]])],['ひし形',ngon(4)],['台形',nrm([[.2,0],[.8,0],[1,1],[0,1]])],['平行四辺形',nrm([[.25,0],[1,0],[.75,1],[0,1]])],['五角形',ngon(5)],['六角形',ngon(6)],['八角形',ngon(8)]]],
['記号',[['星(5)',ngon(5,.62)],['星(4)',ngon(4,.6)],['星(6)',ngon(6,.5)],['プラス',nrm(PLUS)],['バツ',nrm(PLUS.map(q=>[q[0]-q[1],q[0]+q[1]]))],['右矢印',nrm([[0,.35],[.6,.35],[.6,0],[1,.5],[.6,1],[.6,.65],[0,.65]])],['上矢印',nrm([[.5,0],[1,.4],[.65,.4],[.65,1],[.35,1],[.35,.4],[0,.4]])],['シェブロン',nrm([[0,0],[.6,0],[1,.5],[.6,1],[0,1],[.4,.5]])],['ハート',{d:'M0 .45C-.55 .05 -.5 -.45 -.25 -.45C-.1 -.45 0 -.35 0 -.25C0 -.35 .1 -.45 .25 -.45C.5 -.45 .55 .05 0 .45z'}]]],
['物',[['家',nrm([[.5,0],[1,.45],[.85,.45],[.85,1],[.15,1],[.15,.45],[0,.45]])],['雲',{d:'M-.3 .3A.2 .2 0 0 1 -.35 -.1A.25 .25 0 0 1 .05 -.3A.25 .25 0 0 1 .35 -.1A.2 .2 0 0 1 .3 .3z'}],['月',{d:'M.1 -.45A.5 .5 0 1 0 .1 .45A.38 .38 0 1 1 .1 -.45z'}]]],
['吹き出し',[['角吹き出し',nrm([[0,0],[1,0],[1,.75],[.4,.75],[.2,1],[.25,.75],[0,.75]])],['丸吹き出し',{d:'M-.1 .3C-.5 .3 -.5 -.4 0 -.4C.5 -.4 .5 .3 .1 .3L-.2 .5z'}]]],
['ブロック',[['L字',nrm([[0,0],[.4,0],[.4,.6],[1,.6],[1,1],[0,1]])],['T字',nrm([[0,0],[1,0],[1,.4],[.65,.4],[.65,1],[.35,1],[.35,.4],[0,.4]])],['階段',nrm([[0,1],[0,.66],[.33,.66],[.33,.33],[.66,.33],[.66,0],[1,0],[1,1]])]]]];
const SHL=[];SH.forEach(c=>c[1].forEach(e=>SHL.push({n:e[0],pts:Array.isArray(e[1])?e[1]:0,d:e[1].d})));
const shD=e=>e.pts?'M'+e.pts.map(q=>q.join(' ')).join('L')+'z':e.d;
function buildShp(){const p=$('#shpp');p.innerHTML='';let k=0;SH.forEach(c=>{const h=document.createElement('h4');h.textContent=c[0];p.append(h);const d=document.createElement('div');c[1].forEach(()=>{const i=k++,e=SHL[i],b=document.createElement('button');b.innerHTML=`<svg viewBox="-.6 -.6 1.2 1.2" width="32" height="32" aria-hidden="true"><path d="${shD(e)}" fill="currentColor" fill-opacity=".85"/></svg>`;b.title=e.n;b.setAttribute('aria-label',e.n);b.className=i==curShape?'on':'';b.onclick=()=>{curShape=i;buildShp()};d.append(b)});p.append(d)})}
// ===== フォント =====
const FL0=[{n:'Sans Serif',css:'sans-serif'},{n:'Serif',css:'serif'},{n:'Handwriting',css:'"Segoe Script","Bradley Hand",cursive'},{n:'Marker',css:'"Marker Felt","Comic Sans MS",fantasy'},{n:'Curly',css:'"Brush Script MT",cursive'},{n:'Pixel',css:'"Courier New",monospace'},{n:'中文',css:'"Noto Sans SC","PingFang SC",sans-serif'},{n:'日本語',css:'"Noto Sans JP","Hiragino Sans","Yu Gothic",sans-serif'},{n:'한국어',css:'"Noto Sans KR","Malgun Gothic",sans-serif'}];
const WEBF=[['Archivo','Archivo'],['Archivo Black','Archivo Black'],['Playful(近似)','Fredoka'],['Bubbly(近似)','Baloo 2'],['Arcade(近似)','Press Start 2P'],['Bits and Bytes(近似)','VT323'],['Technological(近似)','Orbitron'],['Branches(近似)','Chewy']];
const baseFL=()=>FL0.concat(WEBF.map(w=>({n:w[0],fam:w[1],css:`"${w[1]}",sans-serif`,web:1})));let FL=baseFL();let pal={recent:[],custom:[]};try{Object.assign(pal,JSON.parse(localStorage.getItem('ced_pal')||'{}'))}catch(e){}
const fillFonts=()=>{const e=$('#fn'),v=e.value||'0';buildFpop();e.value=FL[+v]?v:'0'};
async function regFont(f){if(f.data){try{const ff=new FontFace(f.n,`url(${f.data})`);await ff.load();document.fonts.add(ff)}catch(e){badFont.add(f.n);alert('フォントを読み込めませんでした: '+f.n)}}
if(!FL.some(x=>x.n==f.n||x.fam==f.n))FL.push({n:f.n,css:`"${f.n}",${f.fb||'sans-serif'}`});fillFonts();cs.forEach(c=>{c._bb=undefined;c.sh.forEach(s=>s.t=='txt'&&tm(s))});thumbs(true);draw()}
const webLoaded=new Set(),webFail=new Set(),webPrev=new Set(),webOk=new Set(),badFont=new Set();
async function ensureWeb(f){if(!f.web||webLoaded.has(f.fam)||fonts.some(x=>x.n==f.fam))return;webLoaded.add(f.fam);
try{const css=await(await fetch('https://fonts.googleapis.com/css2?family='+encodeURIComponent(f.fam).replace(/%20/g,'+')+'&display=swap')).text();
const m=css.match(/\/\* latin \*\/\s*@font-face\s*\{[^}]*?url\((https:[^)]+)\)/)||css.match(/url\((https:[^)]+)\)/);const b=await(await fetch(m[1])).blob();
const data=await new Promise(r=>{const fr=new FileReader();fr.onload=()=>r(fr.result);fr.readAsDataURL(b)});const o={n:f.fam,data,fb:'sans-serif'};fonts.push(o);await regFont(o)}
catch(e){webLoaded.delete(f.fam);webFail.add(f.fam);buildFpop();alert('Webフォント「'+f.n+'」を取得できませんでした(オンライン接続が必要です)。代替フォントで表示します')}}
const curFont=()=>{const f=FL[+$('#fn').value]||FL[0];ensureWeb(f);return f.css};
// ===== モデル =====
// ビットマップの座標系: c.w/c.h/c.cx/c.cy はすべて「実ピクセル」単位。論理(Scratch)サイズ = 実ピクセル ÷ c.res。
// 新規ビットマップは res=2(実960×720=論理480×360)。ベクターは常に res=1。
const BR=2,RS=c=>c&&+c.res>0?+c.res:1;
function mk(k,n){const R=k=='b'?BR:1,c={n,k,w:480*R,h:360*R,cx:240*R,cy:180*R,res:R,sh:[],u:[],r:[]};if(k=='b'){c.bc=document.createElement('canvas');c.bc.width=c.w;c.bc.height=c.h}return c}
function ld(s){s.im=new Image;s.im.onload=draw;s.im.src=s.src}
function dOf(s){const w=s.w,h=s.h;
if(s.t=='pd')return s.d;
if(s.t=='rect'){const r=Math.min(s.rr||0,w/2,h/2);if(r>0)return`M${-w/2+r} ${-h/2}H${w/2-r}A${r} ${r} 0 0 1 ${w/2} ${-h/2+r}V${h/2-r}A${r} ${r} 0 0 1 ${w/2-r} ${h/2}H${-w/2+r}A${r} ${r} 0 0 1 ${-w/2} ${h/2-r}V${-h/2+r}A${r} ${r} 0 0 1 ${-w/2+r} ${-h/2}z`;return`M${-w/2} ${-h/2}h${w}v${h}h${-w}z`}
if(s.t=='ell')return`M${-w/2} 0A${w/2} ${h/2} 0 1 0 ${w/2} 0A${w/2} ${h/2} 0 1 0 ${-w/2} 0z`;
if(s.bz){const q=s.pts,seg=(a,b)=>`C${(a[0]+a[4])*w} ${(a[1]+a[5])*h} ${(b[0]+b[2])*w} ${(b[1]+b[3])*h} ${b[0]*w} ${b[1]*h}`;let d='';for(const[a,b,cl]of rng(s)){d+=`M${q[a][0]*w} ${q[a][1]*h}`;for(let i=a;i<b-1;i++)d+=seg(q[i],q[i+1]);if(cl&&b-a>1)d+=seg(q[b-1],q[a])+'z'}return d}
const p=s.pts.map(q=>[q[0]*w,q[1]*h]);let d=`M${p[0]}`;
if(s.sm===0){for(let i=1;i<p.length;i++)d+=`L${p[i]}`;return d+(s.cl?'z':'')}
for(let i=1;i<p.length-1;i++)d+=`Q${p[i]} ${(p[i][0]+p[i+1][0])/2},${(p[i][1]+p[i+1][1])/2}`;
return d+`L${p[p.length-1]}`}
const l2w=(s,x,y)=>{const c=Math.cos(s.r),n=Math.sin(s.r);return[s.x+x*c-y*n,s.y+x*n+y*c]};
const w2l=(s,x,y)=>{const c=Math.cos(s.r),n=Math.sin(s.r),dx=x-s.x,dy=y-s.y;return[dx*c+dy*n,-dx*n+dy*c]};
function rng(s){const n=s.pts.length;if(!s.cmp)return[[0,n,!!s.cl]];const r=[];s.pts.forEach((q,i)=>{if(q[7]==1){if(r.length)r[r.length-1][1]=i;r.push([i,n,true])}});return r}
function arcC(x1,y1,rx,ry,ph,fa,fs,x2,y2){if(!rx||!ry||(x1==x2&&y1==y2))return[[x2,y2,x2,y2,x2,y2]];const f=ph*Math.PI/180,c=Math.cos(f),s=Math.sin(f),dx=(x1-x2)/2,dy=(y1-y2)/2,xp=c*dx+s*dy,yp=-s*dx+c*dy;rx=Math.abs(rx);ry=Math.abs(ry);const l=xp*xp/(rx*rx)+yp*yp/(ry*ry);if(l>1){rx*=Math.sqrt(l);ry*=Math.sqrt(l)}
const sg=fa==fs?-1:1,k=sg*Math.sqrt(Math.max(0,(rx*rx*ry*ry-rx*rx*yp*yp-ry*ry*xp*xp)/(rx*rx*yp*yp+ry*ry*xp*xp))),cxp=k*rx*yp/ry,cyp=-k*ry*xp/rx,cx=c*cxp-s*cyp+(x1+x2)/2,cy=s*cxp+c*cyp+(y1+y2)/2,an=(ux,uy,vx,vy)=>Math.atan2(ux*vy-uy*vx,ux*vx+uy*vy);
const t1=an(1,0,(xp-cxp)/rx,(yp-cyp)/ry);let dt=an((xp-cxp)/rx,(yp-cyp)/ry,(-xp-cxp)/rx,(-yp-cyp)/ry);if(!fs&&dt>0)dt-=2*Math.PI;if(fs&&dt<0)dt+=2*Math.PI;
const n=Math.max(1,Math.ceil(Math.abs(dt)/(Math.PI/2)-1e-9)),d=dt/n,t=4/3*Math.tan(d/4),o=[],P=(u,v)=>[c*rx*u-s*ry*v+cx,s*rx*u+c*ry*v+cy];
for(let i=0;i<n;i++){const a=t1+i*d,b=a+d,A=[Math.cos(a),Math.sin(a)],B=[Math.cos(b),Math.sin(b)],q1=P(A[0]-t*A[1],A[1]+t*A[0]),q2=P(B[0]+t*B[1],B[1]-t*B[0]),q3=P(B[0],B[1]);o.push([q1[0],q1[1],q2[0],q2[1],q3[0],q3[1]])}
o[n-1][4]=x2;o[n-1][5]=y2;return o}
function parseD(d){const T=d.match(/[a-zA-Z]|[-+]?(?:\d*\.\d+|\d+\.?)(?:e[-+]?\d+)?/g)||[];let i=0,cmd='',x=0,y=0,sx=0,sy=0,cx_=0,cy_=0,cur=null;const subs=[],num=()=>parseFloat(T[i++]);
const start=(X,Y)=>{cur={pts:[[X,Y,0,0,0,0,0]],closed:false};subs.push(cur)};
const cub=(a,b,c,dd,X,Y)=>{const q=cur.pts[cur.pts.length-1];q[4]=a-q[0];q[5]=b-q[1];cur.pts.push([X,Y,c-X,dd-Y,0,0,0]);cx_=c;cy_=dd;x=X;y=Y};
while(i<T.length){if(/[a-zA-Z]/.test(T[i]))cmd=T[i++];const rel=cmd>='a',K=cmd.toUpperCase(),ox0=rel?x:0,oy0=rel?y:0;
if(K=='Z'){if(cur){cur.closed=true;x=sx;y=sy}continue}
if(K=='M'){const X=num()+ox0,Y=num()+oy0;start(X,Y);sx=x=X;sy=y=Y;cx_=x;cy_=y;cmd=rel?'l':'L';continue}
if(!cur||cur.closed)start(sx,sy);
if(K=='L'){const X=num()+ox0,Y=num()+oy0;cur.pts.push([X,Y,0,0,0,0,0]);x=X;y=Y;cx_=x;cy_=y}
else if(K=='H'){const X=num()+ox0;cur.pts.push([X,y,0,0,0,0,0]);x=X;cx_=x;cy_=y}
else if(K=='V'){const Y=num()+oy0;cur.pts.push([x,Y,0,0,0,0,0]);y=Y;cx_=x;cy_=y}
else if(K=='C'){const a=num()+ox0,b=num()+oy0,c=num()+ox0,dd=num()+oy0,X=num()+ox0,Y=num()+oy0;cub(a,b,c,dd,X,Y)}
else if(K=='S'){const a=2*x-cx_,b=2*y-cy_,c=num()+ox0,dd=num()+oy0,X=num()+ox0,Y=num()+oy0;cub(a,b,c,dd,X,Y)}
else if(K=='Q'){const qx=num()+ox0,qy=num()+oy0,X=num()+ox0,Y=num()+oy0;cub(x+2/3*(qx-x),y+2/3*(qy-y),X+2/3*(qx-X),Y+2/3*(qy-Y),X,Y)}
else if(K=='A'){const rx=num(),ry=num(),ph=num(),fa=num(),fs=num(),X=num()+ox0,Y=num()+oy0;const x0=x,y0=y;arcC(x0,y0,rx,ry,ph,fa,fs,X,Y).forEach(c=>{const px=x,py=y;void px;void py;cub(c[0],c[1],c[2],c[3],c[4],c[5])})}
else i++}
return subs}
function renorm(s){const P=s.pts.map(q=>[q[0]*s.w,q[1]*s.h]),xs=P.map(q=>q[0]),ys=P.map(q=>q[1]),x0=Math.min(...xs),x1=Math.max(...xs),y0=Math.min(...ys),y1=Math.max(...ys),a=(x0+x1)/2,b=(y0+y1)/2,nw=Math.max(x1-x0,1),nh=Math.max(y1-y0,1),c=Math.cos(s.r),n=Math.sin(s.r);
s.x+=a*c-b*n;s.y+=a*n+b*c;const ow=s.w,oh=s.h;s.pts=s.pts.map((q,i)=>q.length>2?[(P[i][0]-a)/nw,(P[i][1]-b)/nh,q[2]*ow/nw,q[3]*oh/nh,q[4]*ow/nw,q[5]*oh/nh,...q.slice(6)]:[(P[i][0]-a)/nw,(P[i][1]-b)/nh]);s.w=nw;s.h=nh}
function tm(s){g.font=`${s.fs}px ${s.fn||'sans-serif'}`;s.w=Math.max(4,g.measureText(s.tx).width);s.h=s.fs*1.2}
function p2d(s){const d=dOf(s);if(s.t!='pd')return new Path2D(d);const p=new Path2D();p.addPath(new Path2D(d),new DOMMatrix().scale(s.w/s.w0,s.h/s.h0));return p}
function fsty(x,s,f){if(!f||typeof f=='string')return f;const w=s.w/2,h=s.h/2;let G;if(f.g=='h')G=x.createLinearGradient(-w,0,w,0);else if(f.g=='v')G=x.createLinearGradient(0,-h,0,h);else G=x.createRadialGradient(0,0,0,0,0,Math.hypot(w,h));G.addColorStop(0,f.c1);G.addColorStop(1,f.c2);return G}
const fv=()=>gm=='s'?col('fc'):{g:gm,c1:col('fc'),c2:col('fc2')};
const jn=s=>s.sj=='miter'?'miter':'round';/* 縁の角タイプ: miter=角(シャープ) / round=丸。未設定(旧データ)は丸 */
function dsh(x,s){if(s===TEH&&x===g)return;x.save();x.translate(s.x,s.y);x.rotate(s.r);if(s.mx)x.scale(-1,1);
if(s.t=='img'){if(s.im&&s.im.complete)x.drawImage(s.im,-s.w/2,-s.h/2,s.w,s.h)}
else if(s.t=='txt'){x.font=`${s.fs}px ${s.fn||'sans-serif'}`;x.textBaseline='middle';x.textAlign='center';if(s.f){x.fillStyle=fsty(x,s,s.f);x.fillText(s.tx,0,0)}if(s.s){x.strokeStyle=s.s;x.lineWidth=s.sw;x.lineJoin=jn(s);x.miterLimit=10;x.strokeText(s.tx,0,0)}}
else{const p=p2d(s);if(s.f){x.fillStyle=fsty(x,s,s.f);x.fill(p,s.fr||'evenodd')}if(s.s){x.strokeStyle=s.s;x.lineWidth=s.sw;x.lineCap='round';x.lineJoin=jn(s);x.miterLimit=10;x.stroke(p)}}
x.restore()}
/* ===== ベクター → ビットマップ(アンチエイリアス ON/OFF 対応) =====
   ON : 通常のCanvas描画(従来どおり)
   OFF: 図形ごと・塗りと線ごとに単独で描き、カバー率50%以上のピクセルだけを「その色そのもの」で置く(縁の混色・半透明なし)。
        色のアルファ(半透明色)は指定どおり重ねる。グラデーションは中心の色を使い、画像は補間なしで二値化 */
function aoCompose(out,W,H,D,rx,ry,rw,rh,col,a0){for(let y=0;y<rh;y++){const Y=ry+y;if(Y<0||Y>=H)continue;for(let x=0;x<rw;x++){const j=(y*rw+x)*4;if(D[j+3]<128)continue;const X=rx+x;if(X<0||X>=W)continue;const i=(Y*W+X)*4,r=col?col[0]:D[j],g=col?col[1]:D[j+1],b=col?col[2]:D[j+2];
if(a0>=1){out[i]=r;out[i+1]=g;out[i+2]=b;out[i+3]=255}else{const da=out[i+3]/255,ra=a0+da*(1-a0);if(ra<=0)continue;out[i]=Math.round((r*a0+out[i]*da*(1-a0))/ra);out[i+1]=Math.round((g*a0+out[i+1]*da*(1-a0))/ra);out[i+2]=Math.round((b*a0+out[i+2]*da*(1-a0))/ra);out[i+3]=Math.round(ra*255)}}}}
function rasterVecOff(W,H,shapes,k,ox,oy){const out=new Uint8ClampedArray(W*H*4),solid=v=>typeof v=='string'?parseC(v):null;
for(const s of shapes){if(s.hid)continue;const L=[];
if(s.t=='img')L.push({sh:s,col:null,a0:1,sm:false});
else{if(s.f){const q=solid(s.f);L.push({sh:{...s,s:null,f:q?toStr({...q,a:1}):s.f},col:q?[q.r,q.g,q.b]:null,a0:q?q.a:1})}
if(s.s&&s.sw>0){const q=solid(s.s);L.push({sh:{...s,f:null,s:q?toStr({...q,a:1}):s.s},col:q?[q.r,q.g,q.b]:null,a0:q?q.a:1})}}
if(!L.length)continue;const[bx0,by0,bx1,by1]=ubox([s]),m=(s.sw||0)*6+4,rx0=Math.max(0,Math.floor((bx0-m-ox)*k)),ry0=Math.max(0,Math.floor((by0-m-oy)*k)),rx1=Math.min(W,Math.ceil((bx1+m-ox)*k)),ry1=Math.min(H,Math.ceil((by1+m-oy)*k)),rw=rx1-rx0,rh=ry1-ry0;if(rw<=0||rh<=0)continue;
for(const l of L){const T=document.createElement('canvas');T.width=rw;T.height=rh;const x=T.getContext('2d',{willReadFrequently:true});x.setTransform(k,0,0,k,-ox*k-rx0,-oy*k-ry0);if(l.sm===false)x.imageSmoothingEnabled=false;dsh(x,l.sh);aoCompose(out,W,H,x.getImageData(0,0,rw,rh).data,rx0,ry0,rw,rh,l.col,l.a0)}}
return out}
// 図形列を canvas o に描く。出力座標 = (世界座標 - (ox,oy)) * k。アンチエイリアスの設定(#aa)に従う
function rasterVec(o,shapes,k,ox,oy){const x=o.getContext('2d');if($('#aa').checked){x.save();x.setTransform(k,0,0,k,-ox*k,-oy*k);shapes.forEach(s=>s.hid||dsh(x,s));x.restore()}
else{const im=x.createImageData(o.width,o.height);im.data.set(rasterVecOff(o.width,o.height,shapes,k,ox,oy));x.putImageData(im,0,0)}}
function dcv(x,c){/* 表示専用: プレビュー(PRV)を反映して描く。書き出し・保存・サムネイルは dc() を使う */
if(c.k=='b'){x.drawImage(PRV.bm||c.bc,0,0);const b=c==C()&&sel[0]&&sel[0].t=='bs'?vs(sel[0]):0;if(b&&b.cvs)stampSel(x,b);return}
pvList(c).forEach(s=>s.hid||dsh(x,s))}
function dc(x,c){if(c.k=='b'){x.drawImage(c.bc,0,0);const f=c==C()&&sel[0]&&sel[0].t=='bs'&&sel[0].cvs?sel[0]:0;if(f)stampSel(x,f);}else c.sh.forEach(s=>s.hid||dsh(x,s))}
// ===== 描画 =====
// 表示専用の透明チェッカー: マスは作品座標で8×8、マスの角をキャンバス中心(幅/2,高さ/2)に合わせる。ズーム・移動に連動し、画像データには含めない(エクスポートはdcのみ使用)
function bgAlt(f=1){const q=parseC(BG.c)||{r:255,g:255,b:255},l=(.299*q.r+.587*q.g+.114*q.b)/255,t=l>.5?0:255,k=(l>.5?.11:.16)*f;return'#'+[q.r,q.g,q.b].map(v=>h2(v+(t-v)*k)).join('')}
function drawChecker(c,d,X0,Y0,X1,Y1){g.setTransform(1,0,0,1,0,0);g.fillStyle=BG.c;g.fillRect(X0,Y0,X1-X0,Y1-Y0);if(!BG.chk)return;const R8=4*RS(c),cw=R8*z*d;
if(cw<3){g.fillStyle=bgAlt(.5);g.fillRect(X0,Y0,X1-X0,Y1-Y0);return}
g.fillStyle=bgAlt();const W=cv.width,H=cv.height,hx=c.w/2,hy=c.h/2,Xc=X0+hx*z*d,Yc=Y0+hy*z*d,
i0=Math.max(Math.floor(-hx/R8),Math.floor(-Xc/cw)),i1=Math.min(Math.ceil(hx/R8)-1,Math.floor((W-Xc)/cw)),j0=Math.max(Math.floor(-hy/R8),Math.floor(-Yc/cw)),j1=Math.min(Math.ceil(hy/R8)-1,Math.floor((H-Yc)/cw));
for(let j=j0;j<=j1;j++){const ya=Math.max(Y0,Math.round(Yc+j*cw)),yb=Math.min(Y1,Math.round(Yc+(j+1)*cw));if(yb<=ya)continue;for(let i=i0+((i0+j)&1);i<=i1;i+=2){const xa=Math.max(X0,Math.round(Xc+i*cw)),xb=Math.min(X1,Math.round(Xc+(i+1)*cw));if(xb>xa)g.fillRect(xa,ya,xb-xa,yb-ya)}}}
let raf=0;function draw(){if(!raf)raf=requestAnimationFrame(()=>{raf=0;paint()})}
function paint(){const c=C();if(!c)return;numSync();const d=devicePixelRatio||1,W=cv.clientWidth,H=cv.clientHeight;
if(cv.width!=Math.round(W*d)||cv.height!=Math.round(H*d)){cv.width=Math.round(W*d);cv.height=Math.round(H*d)}
ox=Math.round(ox*d)/d;oy=Math.round(oy*d)/d;
g.setTransform(d,0,0,d,0,0);g.clearRect(0,0,W,H);g.fillStyle='#cfd8e3';g.fillRect(0,0,W,H);
const X0=Math.round(ox*d),Y0=Math.round(oy*d),X1=Math.round((ox+c.w*z)*d),Y1=Math.round((oy+c.h*z)*d);
drawChecker(c,d,X0,Y0,X1,Y1);g.setTransform(d,0,0,d,0,0);
g.save();g.translate(ox,oy);g.scale(z,z);g.imageSmoothingEnabled=(c.k=='b'&&!$('#aa').checked)?false:z<2;
if(ON.on){g.save();g.beginPath();g.rect(0,0,c.w,c.h);g.clip();onionDraw(c);g.restore()}
if(c.k=='v'&&c.sh.length){const u=ubox(pvList(c).filter(s=>!s.hid));if(u[0]<0||u[1]<0||u[2]>c.w||u[3]>c.h){g.save();g.globalAlpha=.3;dcv(g,c);g.restore()}}g.save();g.beginPath();g.rect(0,0,c.w,c.h);g.clip();dcv(g,c);if(tmp)dsh(g,tmp);g.restore();g.restore();
g.setTransform(1,0,0,1,0,0);g.strokeStyle='#855cd6';g.lineWidth=1;g.strokeRect(X0-.5,Y0-.5,X1-X0+1,Y1-Y0+1);g.setTransform(d,0,0,d,0,0);
const bI=sel[0]&&sel[0].t=='bs'?vs(sel[0]):null,bT=bI?`X ${Math.round(bI.x-bI.w/2)}  Y ${Math.round(bI.y-bI.h/2)}  ${Math.round(bI.w)}×${Math.round(bI.h)}`+(bI.src&&bI.src[2]?`\n移動量 ${(v=>(v>0?'+':'')+v)(Math.round(bI.x-bI.w/2-bI.src[0]))}, ${(v=>(v>0?'+':'')+v)(Math.round(bI.y-bI.h/2-bI.src[1]))}`:'')+(bI.px===undefined?'':bI.px?`\n対象 ${bI.px}px(透明を除く)`:'\n対象なし(完全透明)'):'';
if($('#bsinfo').textContent!=bT)$('#bsinfo').textContent=bT;
const S=(x,y)=>[ox+x*z,oy+y*z];
g.strokeStyle='#855cd6';g.lineWidth=1.5;const[a,b]=S(...(PRV.ctr||[c.cx,c.cy]));g.beginPath();g.moveTo(a-12,b);g.lineTo(a+12,b);g.moveTo(a,b-12);g.lineTo(a,b+12);g.stroke();g.beginPath();g.arc(a,b,6,0,7);g.stroke();
if(c.k=='v'||(sel[0]&&sel[0].t=='bs')){sel.forEach(s0=>{const s=vs(s0);g.beginPath();K.concat([K[0]]).forEach((k,i)=>{const p=l2w(s,k[0]*s.w/2,k[1]*s.h/2),q=S(p[0],p[1]);i?g.lineTo(q[0],q[1]):g.moveTo(q[0],q[1])});g.stroke()});
g.fillStyle='#fff';
if(!TE&&sel.length>=1&&(tool=='sel'||tool=='bsel')&&selFrame()){const s=(sel.length>1&&drag&&drag.gf&&drag.mv)?drag.gf:selFrame();if(sel.length>1){g.beginPath();K.concat([K[0]]).forEach((k,i)=>{const p=l2w(s,k[0]*s.w/2,k[1]*s.h/2),q=S(p[0],p[1]);i?g.lineTo(q[0],q[1]):g.moveTo(q[0],q[1])});g.stroke()}K.forEach(k=>{const p=l2w(s,k[0]*s.w/2,k[1]*s.h/2),q=S(p[0],p[1]);g.fillRect(q[0]-8,q[1]-8,16,16);g.strokeRect(q[0]-8,q[1]-8,16,16)});
if(c.k=='v'&&s.t!='txt'&&s.t!='bs')EK.forEach((k,i)=>{if((i<2?s.h:s.w)*z<44)return;const p=l2w(s,k[0]*s.w/2,k[1]*s.h/2),q=S(p[0],p[1]);g.save();g.translate(q[0],q[1]);g.rotate(s.r);const a=i<2?[-4.5,-10,9,20]:[-10,-4.5,20,9];g.fillRect(a[0],a[1],a[2],a[3]);g.strokeRect(a[0],a[1],a[2],a[3]);g.restore()});
const r=l2w(s,0,-s.h/2-30/z),q=S(r[0],r[1]);g.beginPath();g.arc(q[0],q[1],9,0,7);g.fill();g.stroke()}
if(tool=='rsh'&&sel[0]&&sel[0].pts){const s=vs(sel[0]);s.pts.forEach((q,i)=>{const w=l2w(s,q[0]*s.w,q[1]*s.h),r=S(w[0],w[1]);if(i==selPt&&s.bz){g.fillStyle='#855cd6';[[2,3],[4,5]].forEach(([a,b])=>{if(!q[a]&&!q[b])return;const h=l2w(s,(q[0]+q[a])*s.w,(q[1]+q[b])*s.h),u=S(h[0],h[1]);g.beginPath();g.moveTo(r[0],r[1]);g.lineTo(u[0],u[1]);g.stroke();g.beginPath();g.arc(u[0],u[1],5,0,7);g.fill();g.stroke()})}
const on=(i==selPt||spHas(sel[0],i)),rd=on?5.5:4.5;g.fillStyle=on?'#855cd6':'#fff';g.strokeStyle=on?'#2d1466':'#855cd6';g.lineWidth=on?1.8:1.5;g.beginPath();if(q[6]==1)g.arc(r[0],r[1],rd,0,7);else g.rect(r[0]-rd,r[1]-rd,rd*2,rd*2);g.fill();g.stroke();g.strokeStyle='#855cd6';g.lineWidth=1.5});g.fillStyle='#fff'}
drawOfs(S);
if(PRV.cur){const q=S(PRV.cur[0],PRV.cur[1]);g.save();g.strokeStyle='#855cd6';g.lineWidth=1.5;g.beginPath();g.arc(q[0],q[1],Math.max(2,PRV.cur[2]*z),0,7);g.stroke();g.restore()}
if(PRV.dot){const q=S(PRV.dot[0],PRV.dot[1]),rr=Math.max(.75,PRV.dot[2]*z);g.save();g.globalAlpha=.75;g.fillStyle=PRV.dot[3];g.beginPath();g.arc(q[0],q[1],rr,0,7);g.fill();g.globalAlpha=.9;g.strokeStyle='#855cd6';g.lineWidth=1;g.beginPath();g.arc(q[0],q[1],rr+.5,0,7);g.stroke();g.restore()}
if(TE)teLayout();
if(snapG&&drag){g.save();g.strokeStyle='#ff8c1a';g.lineWidth=1.5;g.setLineDash([6,4]);if(snapG.x){const a=S(c.w/2,0),b=S(c.w/2,c.h);g.beginPath();g.moveTo(a[0],a[1]);g.lineTo(b[0],b[1]);g.stroke()}if(snapG.y){const a=S(0,c.h/2),b=S(c.w,c.h/2);g.beginPath();g.moveTo(a[0],a[1]);g.lineTo(b[0],b[1]);g.stroke()}g.restore()}
if(band){const p=S(band[0],band[1]),q=S(band[2],band[3]);g.setLineDash([5,4]);g.strokeRect(p[0],p[1],q[0]-p[0],q[1]-p[1]);g.setLineDash([])}}}
function fit(){const c=C(),W=cv.clientWidth,H=cv.clientHeight;z=Math.min(W/c.w,H/c.h)*.92;ox=(W-c.w*z)/2;oy=(H-c.h*z)/2;draw()}
function zoomAt(x,y,n){n=Math.min(32,Math.max(.1,n));ox=x-(x-ox)*n/z;oy=y-(y-oy)*n/z;z=n;draw()}
// ===== 履歴 =====
function st(c){return{k:c.k,sh:JSON.stringify(c.sh,rep),bm:c.k=='b'?c.bc.getContext('2d').getImageData(0,0,c.w,c.h):0,w:c.w,h:c.h,cx:c.cx,cy:c.cy,res:RS(c)}}
function rs(c,t){if(t.k&&t.k!=c.k){c.k=t.k;if(t.k=='b'&&!c.bc)c.bc=document.createElement('canvas')}c.sh=JSON.parse(t.sh);c.sh.forEach(s=>s.src&&ld(s));c.w=t.w;c.h=t.h;c.cx=t.cx;c.cy=t.cy;c.res=+t.res>0?+t.res:1;if(c.k=='b'){c.bc.width=t.w;c.bc.height=t.h;c.bc.getContext('2d').putImageData(t.bm,0,0)}}
function hist(){HC++;const c=C();c.u.push(st(c));if(c.u.length>40)c.u.shift();c.r=[];trimHist()}
function trimHist(){const B=200e6,sz=a=>a.bm?a.bm.data.length:0,cu=C();let tot=0;for(const c of cs){for(const a of c.u)tot+=sz(a);for(const a of c.r)tot+=sz(a)}
while(tot>B){let best=null,bn=0;for(const c of cs){if(c===cu)continue;const n=c.u.length+c.r.length;if(n>bn){bn=n;best=c}}if(!best)break;tot-=sz(best.r.length?best.r.shift():best.u.shift())}}
function undo(){if(TE)teEnd();pvClear();SPA.a=[];bcommit();const c=C();if(!c.u.length)return;const ix=c.k=='v'?sel.map(q=>c.sh.indexOf(q)):[];c.r.push(st(c));rs(c,c.u.pop());sel=ix.filter(i=>i>=0&&i<c.sh.length).map(i=>c.sh[i]);selPt=-1;fin()}
function redo(){if(TE)teEnd();pvClear();SPA.a=[];bcommit();const c=C();if(!c.r.length)return;const ix=c.k=='v'?sel.map(q=>c.sh.indexOf(q)):[];c.u.push(st(c));rs(c,c.r.pop());sel=ix.filter(i=>i>=0&&i<c.sh.length).map(i=>c.sh[i]);selPt=-1;fin()}
function nnStamp(x,b){const src=b.cvs,sw=src.width,sh=src.height;if(!sw||!sh)return;const fx=b.fx||1,fy=b.fy||1,c=Math.cos(b.r),s=Math.sin(b.r),hw=b.w/2,hh=b.h/2,ex=Math.abs(c)*hw+Math.abs(s)*hh,ey=Math.abs(s)*hw+Math.abs(c)*hh,
X0=Math.max(0,Math.floor(b.x-ex)),Y0=Math.max(0,Math.floor(b.y-ey)),X1=Math.min(x.canvas.width,Math.ceil(b.x+ex)),Y1=Math.min(x.canvas.height,Math.ceil(b.y+ey));if(X1<=X0||Y1<=Y0)return;
const sd=src.getContext('2d').getImageData(0,0,sw,sh).data,dst=x.getImageData(X0,Y0,X1-X0,Y1-Y0),dd=dst.data,dw=X1-X0;
for(let py=Y0;py<Y1;py++)for(let px=X0;px<X1;px++){const dx=px+.5-b.x,dy=py+.5-b.y,lx=(dx*c+dy*s)/fx,ly=(-dx*s+dy*c)/fy;if(lx<-hw||lx>=hw||ly<-hh||ly>=hh)continue;
const u=Math.min(sw-1,Math.floor((lx+hw)/b.w*sw)),v=Math.min(sh-1,Math.floor((ly+hh)/b.h*sh)),si=(v*sw+u)*4,sa=sd[si+3];if(!sa)continue;
const di=((py-Y0)*dw+(px-X0))*4,a=sa/255,da=dd[di+3]/255,oa=a+da*(1-a);if(oa>0){for(let k=0;k<3;k++)dd[di+k]=Math.round((sd[si+k]*a+dd[di+k]*da*(1-a))/oa);dd[di+3]=Math.round(oa*255)}}
x.putImageData(dst,X0,Y0)}
function stampSel(x,b){const aa=$('#aa').checked;if(!aa&&x.getTransform().isIdentity)return nnStamp(x,b);
x.save();x.imageSmoothingEnabled=aa;if(aa)x.imageSmoothingQuality='high';x.translate(b.x,b.y);x.rotate(b.r||(aa&&!(b.w==b.cvs.width&&b.h==b.cvs.height)?1e-6:0));x.scale(b.fx||1,b.fy||1);x.drawImage(b.cvs,-b.w/2,-b.h/2,b.w,b.h);x.restore()}
function pre(){const b=sel[0];if(b&&b.t=='bs'){if(!b.cvs){hist();lift()}}else hist()}
// 範囲選択の対象はアルファ>0のピクセルのみ(完全透明ピクセルは選択対象外。矩形の表示は従来どおり)
function opaqueN(cv){const w=cv.width,h=cv.height;if(!w||!h)return 0;const d=cv.getContext('2d').getImageData(0,0,w,h).data;let n=0;for(let i=3;i<d.length;i+=4)if(d[i])n++;return n}
function bsPx(b){if(b.px===undefined){if(drag&&drag.m=='bnew')return 1;b.px=opaqueN(b.cvs||region(b))}return b.px}
// 範囲選択を確定したとき、選択枠を「不透明(アルファ>0)ピクセルの外接矩形」まで自動で縮める。範囲内がすべて透明なら枠はそのまま(対象なし)
function trimSel(){const b=sel[0];if(!b||b.t!='bs'||b.cvs||!b.src)return;const[X,Y,w,h]=b.src;if(w<=0||h<=0)return;const d=C().bc.getContext('2d').getImageData(X,Y,w,h).data;let x0=w,y0=h,x1=-1,y1=-1;for(let y=0;y<h;y++)for(let x=0;x<w;x++)if(d[(y*w+x)*4+3]){if(x<x0)x0=x;if(x>x1)x1=x;if(y<y0)y0=y;if(y>y1)y1=y}if(x1<0)return;const nw=x1-x0+1,nh=y1-y0+1;b.src=[X+x0,Y+y0,nw,nh];b.w=nw;b.h=nh;b.x=X+x0+nw/2;b.y=Y+y0+nh/2;b.px=undefined}
function lift(){const b=sel[0];if(!b||b.t!='bs'||b.cvs)return;const c=C(),[X,Y,w,h]=b.src,x=c.bc.getContext('2d'),im=x.getImageData(X,Y,w,h),d=im.data,o=document.createElement('canvas');o.width=w;o.height=h;const out=new ImageData(w,h),q=out.data;let n=0;
for(let i=0;i<d.length;i+=4)if(d[i+3]){q[i]=d[i];q[i+1]=d[i+1];q[i+2]=d[i+2];q[i+3]=d[i+3];d[i]=d[i+1]=d[i+2]=d[i+3]=0;n++}
o.getContext('2d').putImageData(out,0,0);x.putImageData(im,X,Y);b.cvs=o;b.px=n}
function bcommit(){const b=sel[0];if(!b||b.t!='bs')return;if(b.cvs)stampSel(C().bc.getContext('2d'),b);sel=[];fin()}
function region(b){const[X,Y,w,h]=b.src,o=document.createElement('canvas');o.width=w;o.height=h;o.getContext('2d').drawImage(C().bc,-X,-Y);return o}
function bake(b){const W=Math.max(1,Math.ceil(Math.abs(b.w*Math.cos(b.r))+Math.abs(b.h*Math.sin(b.r)))),H=Math.max(1,Math.ceil(Math.abs(b.w*Math.sin(b.r))+Math.abs(b.h*Math.cos(b.r)))),o=document.createElement('canvas');o.width=W;o.height=H;stampSel(o.getContext('2d'),{cvs:b.cvs||region(b),x:W/2,y:H/2,r:b.r,fx:b.fx,fy:b.fy,w:b.w,h:b.h});return o}
function flatURL(c){const o=document.createElement('canvas');o.width=c.w;o.height=c.h;dc(o.getContext('2d'),c);return o.toDataURL()}
function outline(P,r){const Q=[P[0]];P.forEach(p=>{const l=Q[Q.length-1];if(Math.hypot(p[0]-l[0],p[1]-l[1])>=Math.max(1.5,r*.3))Q.push(p)});const e=P[P.length-1],l0=Q[Q.length-1];
if(Q.length<2)Q.push([Q[0][0]+.01,Q[0][1]]);else if(Math.hypot(e[0]-l0[0],e[1]-l0[1])>.5)Q.push(e);
const n=Q.length,N=Q.map((p,i)=>{const a=Q[Math.max(i-1,0)],b=Q[Math.min(i+1,n-1)],dx=b[0]-a[0],dy=b[1]-a[1],l=Math.hypot(dx,dy)||1;return[-dy/l,dx/l]});
const L=Q.map((p,i)=>[p[0]+N[i][0]*r,p[1]+N[i][1]*r]),R=Q.map((p,i)=>[p[0]-N[i][0]*r,p[1]-N[i][1]*r]),cap=(c,t0)=>{const o=[];for(let k=1;k<8;k++){const a=t0-k*Math.PI/8;o.push([c[0]+r*Math.cos(a),c[1]+r*Math.sin(a)])}return o};
return[...L,...cap(Q[n-1],Math.atan2(N[n-1][1],N[n-1][0])),...R.reverse(),...cap(Q[0],Math.atan2(N[0][1],N[0][0])+Math.PI)]}
/* ベクターのブラシ/消しゴムの軌跡を、丸いパスにする:
   滑らかな軌跡 → 太らせた外形 → 自己交差を解消(重なった部分は塗りのまま、軌跡が囲んだ本当の穴だけが穴) → 三次ベジェにあてはめ */
function strokeLoops(P,r){try{const S=strokeSamples(P,Math.max(1,r*.3));
if(S.length<2){/* 1点(クリック): ぴったりの円(4アンカー) */const c=S[0],k=.5523*r;return[[{p:[c[0]+r,c[1]],i:[0,-k],o:[0,k]},{p:[c[0],c[1]+r],i:[k,0],o:[-k,0]},{p:[c[0]-r,c[1]],i:[0,k],o:[0,-k]},{p:[c[0],c[1]-r],i:[-k,0],o:[k,0]}]]}
const poly=strokePoly(S,r),N=GEO.normalize([poly],'nonzero');if(!N||!N.length)return null;const tol=Math.max(.03,Math.min(.35,r*.008));
return N.map(l=>{let A=null;try{A=GEO.fitLoop(l,tol,30,undefined,true)}catch(e){A=null}return A&&A.length>=2?A:l.map(p=>({p,i:[0,0],o:[0,0]}))})}catch(e){return null}}
function anchorsD(A){const f=p=>p[0].toFixed(3)+' '+p[1].toFixed(3);let d='';A.forEach(l=>{const n=l.length;d+='M'+f(l[0].p);for(let k=0;k<n;k++){const a=l[k],b=l[(k+1)%n],z=!(a.o[0]||a.o[1]||b.i[0]||b.i[1]);if(k==n-1&&z){d+='z';continue}d+=z?'L'+f(b.p):'C'+f([a.p[0]+a.o[0],a.p[1]+a.o[1]])+' '+f([b.p[0]+b.i[0],b.p[1]+b.i[1]])+' '+f(b.p)}if(!/z$/.test(d))d+='z'});return d}
function brushShape(P,r){{const A=strokeLoops(P,r);if(A&&A.length){const n0=pdFromLoops(A,p=>p,v=>v,fv(),{sw:0});if(n0&&isFinite(n0.w)&&isFinite(n0.h)&&n0.w>0&&n0.h>0)return n0}}
/* 以下は予備(上が失敗した場合のみ) */const poly=outline(P,r);let n=null;
if(typeof paper!='undefined'){try{paperOK();let it=new paper.Path({segments:poly,closed:true,insert:false});if(it.resolveCrossings)it=it.resolveCrossings();n=fromP(it,{f:fv(),s:null,sw:0});if(n)n.fr='nonzero'}catch(e){n=null}}
if(!n){const xs=poly.map(q=>q[0]),ys=poly.map(q=>q[1]),x0=Math.min(...xs),x1=Math.max(...xs),y0=Math.min(...ys),y1=Math.max(...ys),cx=(x0+x1)/2,cy=(y0+y1)/2,w=Math.max(x1-x0,.01),h=Math.max(y1-y0,.01);
n={t:'pd',d:'M'+poly.map(q=>`${q[0]-cx} ${q[1]-cy}`).join('L')+'z',w0:w,h0:h,w,h,x:cx,y:cy,r:0,f:fv(),s:null,sw:0,fr:'nonzero'}}return n}
function toBz(s){if(s.t=='pd'){const subs=parseD(s.d),pts=[];subs.forEach(sb=>{const q=sb.pts;if(sb.closed&&q.length>1){const a=q[0],b=q[q.length-1];if(Math.hypot(a[0]-b[0],a[1]-b[1])<1e-6){a[2]=b[2];a[3]=b[3];q.pop()}}
q.forEach((r,j)=>{const m=Math.hypot(r[2],r[3])*Math.hypot(r[4],r[5]),sm=m>0&&Math.abs(r[2]*r[5]-r[3]*r[4])<1e-3*m&&r[2]*r[4]+r[3]*r[5]<0?1:0;pts.push([r[0]/s.w0,r[1]/s.h0,r[2]/s.w0,r[3]/s.h0,r[4]/s.w0,r[5]/s.h0,sm,j==0?1:0])})});
s.pts=pts;s.t='path';s.bz=1;s.cmp=1;s.cl=1;delete s.d;delete s.w0;delete s.h0;return}
if(s.t=='ell'){const k=.2761;s.pts=[[0,-.5,-k,0,k,0,1],[.5,0,0,-k,0,k,1],[0,.5,k,0,-k,0,1],[-.5,0,0,k,0,-k,1]];s.cl=1}
else if(s.t=='rect'){s.pts=[[-.5,-.5,0,0,0,0,0],[.5,-.5,0,0,0,0,0],[.5,.5,0,0,0,0,0],[-.5,.5,0,0,0,0,0]];s.cl=1;delete s.rr}
else{const n=s.pts.length,sm=s.sm!==0;s.pts=s.pts.map((q,i)=>{if(!sm)return[q[0],q[1],0,0,0,0,0];const a=s.pts[s.cl?(i-1+n)%n:Math.max(i-1,0)],b=s.pts[s.cl?(i+1)%n:Math.min(i+1,n-1)],dx=(b[0]-a[0])/6,dy=(b[1]-a[1])/6;return!s.cl&&(i==0||i==n-1)?[q[0],q[1],0,0,0,0,1]:[q[0],q[1],-dx,-dy,dx,dy,1]})}
s.t='path';s.bz=1;delete s.sm}
function links(s,i){const q=s.pts[i],w=l2w(s,q[0]*s.w,q[1]*s.h),L=[];C().sh.forEach(o=>{if(o===s||!o.pts)return;o.pts.forEach((r,j)=>{const v=l2w(o,r[0]*o.w,r[1]*o.h);if(Math.hypot(v[0]-w[0],v[1]-w[1])<1.5/z+.5)L.push([o,j])})});return L}
function hHandle(s,p){if(selPt<0||!s.bz)return 0;const q=s.pts[selPt];if(!q)return 0;for(const[a,b,k]of[[2,3,'i'],[4,5,'o']]){if(Math.hypot(q[a]*s.w,q[b]*s.h)<3/z)continue;const w=l2w(s,(q[0]+q[a])*s.w,(q[1]+q[b])*s.h);if(Math.hypot(w[0]-p[0],w[1]-p[1])*z<20)return k}return 0}
function segHit(s,p){const l=w2l(s,p[0],p[1]),P=s.pts.map(q=>[q[0]*s.w,q[1]*s.h]);let best=null,bd=14/z;
for(const[a0,b0,cl]of rng(s))for(let i=a0;i<(cl?b0:b0-1);i++){const j=i+1<b0?i+1:a0,a=s.pts[i],b=s.pts[j],A=P[i],B=P[j],C1=[A[0]+a[4]*s.w,A[1]+a[5]*s.h],C2=[B[0]+b[2]*s.w,B[1]+b[3]*s.h];
for(let k=0;k<=20;k++){const t=k/20,u=1-t,X=u*u*u*A[0]+3*u*u*t*C1[0]+3*u*t*t*C2[0]+t*t*t*B[0],Y=u*u*u*A[1]+3*u*u*t*C1[1]+3*u*t*t*C2[1]+t*t*t*B[1],d=Math.hypot(X-l[0],Y-l[1]);if(d<bd){bd=d;best={i,j,t}}}}return best}
function insertAt(s,sg){const i=sg.i,a=s.pts[i],b=s.pts[sg.j],w=s.w,h=s.h,t=sg.t,lp=(P0,P1)=>[P0[0]+(P1[0]-P0[0])*t,P0[1]+(P1[1]-P0[1])*t],
A0=[a[0]*w,a[1]*h],C1=[A0[0]+a[4]*w,A0[1]+a[5]*h],B0=[b[0]*w,b[1]*h],C2=[B0[0]+b[2]*w,B0[1]+b[3]*h],A=lp(A0,C1),B=lp(C1,C2),Cc=lp(C2,B0),D=lp(A,B),E=lp(B,Cc),F=lp(D,E);
a[4]=(A[0]-A0[0])/w;a[5]=(A[1]-A0[1])/h;b[2]=(Cc[0]-B0[0])/w;b[3]=(Cc[1]-B0[1])/h;
s.pts.splice(i+1,0,[F[0]/w,F[1]/h,(D[0]-F[0])/w,(D[1]-F[1])/h,(E[0]-F[0])/w,(E[1]-F[1])/h,1]);return i+1}
// ===== ブール演算(Paper.js) =====
const paperOK=()=>{if(typeof paper=='undefined'){alert('Paper.jsを読み込めませんでした。結合・マスク・減算・フィルター・切り取り・ベクター消しゴムはオンライン接続が必要です。');return false}if(!paperOK.i){paper.setup(document.createElement('canvas'));paperOK.i=1}return true};
const elig=s=>s.t=='rect'||s.t=='ell'||s.t=='pd'||(s.t=='path'&&s.cl);
function toP(s){const it=paper.PathItem.create(dOf(s));if(s.t=='pd')it.scale(s.w/s.w0,s.h/s.h0,[0,0]);it.rotate(s.r*180/Math.PI,[0,0]);it.translate([s.x,s.y]);return it}
function fromP(it,t){const b=it.bounds;if(!b||(b.width<.5&&b.height<.5))return null;const cx=b.center.x,cy=b.center.y,w=Math.max(b.width,.01),h=Math.max(b.height,.01);it.translate([-cx,-cy]);return{t:'pd',d:it.pathData,w0:w,h0:h,w,h,x:cx,y:cy,r:0,f:t.f,s:t.s,sw:t.sw,...(t.sj?{sj:t.sj}:{})}}
function bool(op){if(!paperOK())return;const c=C(),L=c.sh.filter(s=>sel.includes(s));
if(L.length<2||!L.every(elig))return alert('閉じた図形(四角・楕円・多角形・図形ライブラリ・結合結果)を2つ以上選んでください。線・ペン・文字・画像は対象外です。');
hist();const P=L.map(toP),o={insert:false};let r=P[0];
for(let i=1;i<P.length;i++)r=op=='merge'?r.unite(P[i],o):op=='mask'?r.intersect(P[i],o):op=='filter'?r.exclude(P[i],o):r.subtract(P[i],o);
const n=fromP(r,op=='sub'?L[0]:L[L.length-1]);P.forEach(i=>i.remove());r.remove();
c.sh=c.sh.filter(s=>!L.includes(s));sel=[];if(n){c.sh.push(n);sel=[n]}else alert('結果が空になりました');fin()}
function cutAt(a,b){const c=C(),len=Math.hypot(b[0]-a[0],b[1]-a[1]);if(len<4||!paperOK())return;const ux=(b[0]-a[0])/len,uy=(b[1]-a[1])/len,nx=-uy,ny=ux,L=1e5,o={insert:false};
const q=k=>new paper.Path({segments:[[a[0]-ux*L,a[1]-uy*L],[a[0]+ux*L,a[1]+uy*L],[a[0]+ux*L+nx*k*L,a[1]+uy*L+ny*k*L],[a[0]-ux*L+nx*k*L,a[1]-uy*L+ny*k*L]],closed:true,insert:false});
let ch=0;const out=[];c.sh.forEach(s=>{if(!elig(s)){out.push(s);return}const it=toP(s),pc=[1,-1].map(k=>{const h=q(k),r=it.intersect(h,o);const n=fromP(r,s);r.remove();h.remove();return n}).filter(Boolean);it.remove();if(pc.length==2){ch=1;out.push(...pc)}else out.push(s)});
if(ch){hist();c.sh=out;sel=[]}}
// 消しゴムの軌跡: 点列をなめらかな曲線(ペンと同じ Catmull-Rom 接線のベジェ)にして細かく標本化する
function strokeSamples(P,step){const Q=[P[0]];P.forEach(p=>{const l=Q[Q.length-1];if(Math.hypot(p[0]-l[0],p[1]-l[1])>1e-3)Q.push(p)});const n=Q.length;if(n<2)return Q;
const T=Q.map((p,i)=>i==0||i==n-1?[0,0]:[(Q[i+1][0]-Q[i-1][0])/6,(Q[i+1][1]-Q[i-1][1])/6]),O=[Q[0]];
for(let i=0;i<n-1;i++){const A=Q[i],B=Q[i+1],C1=[A[0]+T[i][0],A[1]+T[i][1]],C2=[B[0]-T[i+1][0],B[1]-T[i+1][1]],len=Math.hypot(C1[0]-A[0],C1[1]-A[1])+Math.hypot(C2[0]-C1[0],C2[1]-C1[1])+Math.hypot(B[0]-C2[0],B[1]-C2[1]),k=Math.min(240,Math.max(1,Math.ceil(len/step)));
for(let j=1;j<=k;j++){const t=j/k,u=1-t;O.push([u*u*u*A[0]+3*u*u*t*C1[0]+3*u*t*t*C2[0]+t*t*t*B[0],u*u*u*A[1]+3*u*u*t*C1[1]+3*u*t*t*C2[1]+t*t*t*B[1]])}}return O}
// 曲線の両側へ半径rだけずらし、両端を丸めた「線の帯」の輪郭(1つの閉じた多角形)を作る
function strokePoly(S,r){const m=Math.max(8,Math.min(48,Math.ceil(Math.sqrt(r)*3))),n=S.length;
if(n<2){const c=S[0],o=[];for(let k=0;k<m*2;k++){const a=k*Math.PI/m;o.push([c[0]+r*Math.cos(a),c[1]+r*Math.sin(a)])}return o}
const N=S.map((p,i)=>{const a=S[Math.max(i-1,0)],b=S[Math.min(i+1,n-1)],dx=b[0]-a[0],dy=b[1]-a[1],l=Math.hypot(dx,dy)||1;return[-dy/l,dx/l]});
const L=S.map((p,i)=>[p[0]+N[i][0]*r,p[1]+N[i][1]*r]),R=S.map((p,i)=>[p[0]-N[i][0]*r,p[1]-N[i][1]*r]),cap=(c,t0)=>{const o=[];for(let k=1;k<m;k++){const a=t0-k*Math.PI/m;o.push([c[0]+r*Math.cos(a),c[1]+r*Math.sin(a)])}return o};
return[...L,...cap(S[n-1],Math.atan2(N[n-1][1],N[n-1][0])),...R.reverse(),...cap(S[0],Math.atan2(N[0][1],N[0][0])+Math.PI)]}
function eraseCalc(P,r,curved){/* 結果だけを計算して返す(実データは変更しない)。プレビューと確定で共用。軌跡は曲線の帯として消す(スタンプの連続ではない) */if(typeof paper=='undefined'||!P||!P.length)return null;paperOK();const c=C(),o={insert:false};let a=null;
if(curved){try{const A=strokeLoops(P,r);if(A&&A.length){const it=new paper.CompoundPath({pathData:anchorsD(A),insert:false});it.fillRule='nonzero';a=it;if(!a||!a.bounds||!isFinite(a.bounds.width)||!isFinite(a.bounds.height)){a=null}}}catch(e){a=null}}
if(!a)try{const it=new paper.Path({segments:strokePoly(strokeSamples(P,Math.max(1,r*.3)),r),closed:true,insert:false});it.fillRule='nonzero';a=it.resolveCrossings?it.resolveCrossings():it;if(!a||!a.bounds||!isFinite(a.bounds.width)||!isFinite(a.bounds.height))a=null}catch(e){a=null}
if(!a){/* 予備: 曲線を密に標本化した円の合成 */strokeSamples(P,Math.max(.5,r*.2)).forEach(p=>{const k=new paper.Path.Circle({center:p,radius:r,insert:false});a=a?a.unite(k,o):k})}if(!a)return null;
let ch=0;const out=[];c.sh.forEach(s=>{if(!elig(s)){out.push(s);return}const it=toP(s);if(!it.bounds.intersects(a.bounds)){it.remove();out.push(s);return}
const res=it.subtract(a,o);it.remove();ch=1;
if(res.children&&res.children.length>1){const ch0=res.children,hole=h=>ch0.some(o2=>o2!==h&&o2.bounds.contains(h.bounds)&&o2.contains(h.interiorPoint));const sol=ch0.filter(x=>!hole(x)),hol=ch0.filter(hole);
sol.forEach(x=>{const cp=new paper.CompoundPath({children:[x.clone({insert:false}),...hol.filter(h=>x.contains(h.interiorPoint)).map(h=>h.clone({insert:false}))],insert:false});const n=fromP(cp,s);if(n)out.push(n)})}
else{const n=fromP(res,s);if(n)out.push(n)}res.remove()});
a.remove();return{out,ch}}
function eraseAt(P,r){if(!paperOK())return;const R=eraseCalc(P,r,true);if(R&&R.ch){hist();C().sh=R.out;sel=[]}}
// ===== 入力 =====
const ps=new Map(),PENS=new Set();let pin=null;
const pt=e=>{const r=cv.getBoundingClientRect();return[(e.clientX-r.left-ox)/z,(e.clientY-r.top-oy)/z]};
const rel=a=>{const r=cv.getBoundingClientRect();return[a[0]-r.left,a[1]-r.top]};
// 操作状態: idle(なし) / pending(タッチ直後の判定待ち) / draw(描画) / move(オブジェクト・範囲・画面の移動や変形) / gesture(二本指のキャンバス移動・拡大縮小)
// gesture中は描画・編集を一切行わず、すべての指が離れるまで他の操作に切り替わらない
const DRAWT=['brush','pen','eras','line','ell','rect','poly','shp','arw','cut','brect','bell','bline'];
function startPin(){const a=[...ps.values()].slice(0,2);pin={d:Math.max(1,Math.hypot(a[0][0]-a[1][0],a[0][1]-a[1][1])),z,ox,oy,m:rel([(a[0][0]+a[1][0])/2,(a[0][1]+a[1][1])/2])}}
// 途中まで進んだ操作を取り消して元に戻す(描きかけの点・線、動かしかけの図形を残さない)
function cancelOp(){const d=drag;drag=null;tmp=null;band=null;snapG=null;pvClear();if(!d){draw();return}const c=C();let ch=0;
if(c.k=='b'){const x=c.bc.getContext('2d');if(d.snap){x.putImageData(d.snap,0,0);ch=1}if(HC>d.h0&&c.u.length){if(!d.snap){rs(c,c.u.pop());sel=[]}else c.u.pop();c.r=d.r0;ch=1}else if(d.m=='bnew'){sel=[];ch=1}}
else if(HC>d.h0&&c.u.length){const ix=sel.map(q=>c.sh.indexOf(q));rs(c,c.u.pop());sel=ix.filter(i=>i>=0&&i<c.sh.length).map(i=>c.sh[i]);c.r=d.r0;ch=1}
if(ch){ONG++;thumbs()}sync();draw()}
function beginOp(e){{const a=document.activeElement;if(a&&a!==document.body&&/^(INPUT|SELECT|TEXTAREA)$/.test(a.tagName)&&!(typeof TE!=='undefined'&&TE))a.blur()}down(e);OPPID=e.pointerId;OP=!drag?'idle':(drag.h?'move':(DRAWT.includes(tool)?'draw':'move'))}
function firePD(){if(!PD)return;const p=PD;PD=null;clearTimeout(p.t);if(OP!='pending')return;beginOp(p.e)}
cv.addEventListener('pointerdown',e=>{e.preventDefault();{const a=document.activeElement;if(a&&a.id!=='te_in'&&/^(INPUT|SELECT|TEXTAREA)$/.test(a.tagName))a.blur()}
if(e.pointerType=='touch'&&PENS.size)return;/* スタイラス使用中の手のひら(タッチ)は無視 */
if(e.pointerType=='pen')PENS.add(e.pointerId);
if(TE)teEnd();cv.setPointerCapture(e.pointerId);ps.set(e.pointerId,[e.clientX,e.clientY]);
if(OP=='gesture'){if(ps.size>=2)startPin();return}
if(ps.size>=2){if(PD){clearTimeout(PD.t);PD=null}cancelOp();OP='gesture';OPPID=null;startPin();draw();return}
if(e.pointerType=='touch'){OP='pending';OPPID=e.pointerId;PD={e,x:e.clientX,y:e.clientY,t:setTimeout(firePD,60)};return}
beginOp(e)});
cv.addEventListener('pointermove',e=>{if(!ps.has(e.pointerId)){if((e.pointerType=='mouse'||e.pointerType=='pen')&&!drag&&OP=='idle')hoverPrev(e);return}ps.set(e.pointerId,[e.clientX,e.clientY]);
if(OP=='gesture'){if(pin&&ps.size>=2){const a=[...ps.values()],d=Math.hypot(a[0][0]-a[1][0],a[0][1]-a[1][1]),m=rel([(a[0][0]+a[1][0])/2,(a[0][1]+a[1][1])/2]),nz=Math.min(32,Math.max(.1,pin.z*d/pin.d)),wx=(pin.m[0]-pin.ox)/pin.z,wy=(pin.m[1]-pin.oy)/pin.z;z=nz;ox=m[0]-wx*nz;oy=m[1]-wy*nz;draw()}return}
if(e.pointerId!==OPPID)return;
if(OP=='pending'){if(Math.hypot(e.clientX-PD.x,e.clientY-PD.y)>6){firePD();if(OP!='idle')mv(e)}return}
mv(e)});
const end=(e,cancel)=>{PENS.delete(e.pointerId);if(!ps.has(e.pointerId))return;ps.delete(e.pointerId);
if(OP=='gesture'){if(ps.size>=2)startPin();else pin=null;if(ps.size==0){OP='idle';OPPID=null}return}
if(e.pointerId!==OPPID)return;
if(OP=='pending')firePD();
if(cancel)cancelOp();else up(e);OP='idle';OPPID=null};
cv.addEventListener('pointerup',e=>end(e,false));cv.addEventListener('pointercancel',e=>end(e,true));
cv.addEventListener('pointerleave',()=>{if(PRV.hv&&!drag){pvClear();draw()}});
// ホイール: マウスは従来どおり拡大縮小 / タッチパッドのピンチ(ctrl+wheel)は拡大縮小 / 二本指スクロールは画面移動
cv.addEventListener('wheel',e=>{e.preventDefault();const r=cv.getBoundingClientRect(),x=e.clientX-r.left,y=e.clientY-r.top;
if(e.ctrlKey)zoomAt(x,y,z*Math.exp(-clamp(e.deltaY,-30,30)*.012));
else if(e.deltaMode==0&&(e.deltaX!=0||Math.abs(e.deltaY)<40)){ox-=e.deltaX;oy-=e.deltaY;draw()}
else zoomAt(x,y,z*Math.exp(-clamp(e.deltaY,-100,100)*.0006))},{passive:false});
// 選択範囲の枠: 1個ならその図形、複数なら全体を囲む外接矩形(回転0)。サイズ・角度のハンドルはこの枠に付く
function selFrame(){if(!sel.length)return null;if(sel.length==1)return vs(sel[0]);const L=sel.filter(s=>!s.lk).map(vs);if(!L.length)return null;const[a,b,e,f]=ubox(L);return{t:'grp',x:(a+e)/2,y:(b+f)/2,w:Math.max(e-a,1e-6),h:Math.max(f-b,1e-6),r:0}}
// 複数選択のまとめて変形(拡大縮小・回転)。確定までは作業コピー(PRV)だけを動かす
function gTransform(d,p,ev){if(!d.mv){const L=sel.filter(s=>!s.lk);if(!L.length)return;const[a,b,e,f]=ubox(L);d.L=L;d.F={x:(a+e)/2,y:(b+f)/2,w:Math.max(e-a,1e-6),h:Math.max(f-b,1e-6)};d.O=L.map(s=>({x:s.x,y:s.y,w:s.w,h:s.h,r:s.r,fs:s.fs}));pvBegin(L);d.mv=1}
const F=d.F,L=d.L,O=d.O;
if(d.m=='rot'){const a0=Math.atan2(d.p0[1]-F.y,d.p0[0]-F.x);let da=Math.atan2(p[1]-F.y,p[0]-F.x)-a0;if(ev.shiftKey)da=Math.round(da/.2618)*.2618;const co=Math.cos(da),si=Math.sin(da);
L.forEach((s,i)=>{const w=vs(s),o=O[i],dx=o.x-F.x,dy=o.y-F.y;w.x=F.x+dx*co-dy*si;w.y=F.y+dx*si+dy*co;w.r=o.r+da});d.gf={x:F.x,y:F.y,w:F.w,h:F.h,r:da};return}
let sx,sy,Ax,Ay,nw,nh,ke;
if(d.m=='rs'){[sx,sy]=K[d.i];Ax=F.x-sx*F.w/2;Ay=F.y-sy*F.h/2;nw=Math.max(1,(p[0]-Ax)*sx);nh=Math.max(1,(p[1]-Ay)*sy);if(ev.shiftKey){const k=Math.max(nw/F.w,nh/F.h);nw=F.w*k;nh=F.h*k}}
else{[sx,sy]=EK[d.e];if(sx){Ax=F.x-sx*F.w/2;Ay=F.y;nw=Math.max(1,(p[0]-Ax)*sx);nh=F.h}else{Ax=F.x;Ay=F.y-sy*F.h/2;nw=F.w;nh=Math.max(1,(p[1]-Ay)*sy)}}
const kx=nw/F.w,ky=nh/F.h;ke=d.m=='rs'?Math.sqrt(kx*ky):(sx?kx:ky);
L.forEach((s,i)=>{const w=vs(s),o=O[i];w.x=Ax+(o.x-Ax)*kx;w.y=Ay+(o.y-Ay)*ky;const q=o.r/(Math.PI/2),ortho=Math.abs(q-Math.round(q))<1e-6;
if(s.t=='txt'||s.t=='img'||!ortho){w.w=Math.max(1,o.w*ke);w.h=Math.max(1,o.h*ke);if(s.t=='txt'){w.fs=o.fs*ke;tm(w)}}
else{const sw=Math.abs(Math.round(q))%2==1;w.w=Math.max(1,o.w*(sw?ky:kx));w.h=Math.max(1,o.h*(sw?kx:ky))}});
d.gf={x:Ax+(sx?sx*nw/2:0),y:Ay+(sy?sy*nh/2:0),w:nw,h:nh,r:0}}
function hitH(p){const s=selFrame();if(!s)return 0;let best=0,bd=22;const D=q=>Math.hypot(q[0]-p[0],q[1]-p[1])*z;
for(let i=0;i<4;i++){const d=D(l2w(s,K[i][0]*s.w/2,K[i][1]*s.h/2));if(d<bd){bd=d;best={m:'rs',i}}}
{const d=D(l2w(s,0,-s.h/2-30/z));if(d<bd){bd=d;best={m:'rot'}}}
if(C().k=='v'&&s.t!='txt'&&s.t!='bs')EK.forEach((k,i)=>{if((i<2?s.h:s.w)*z<44)return;const d=D(l2w(s,k[0]*s.w/2,k[1]*s.h/2));if(d<bd-1){bd=d;best={m:'re',e:i}}});return best}
function hpt(s,p){let bi=-1,bd=20/z;s.pts.forEach((q,i)=>{const w=l2w(s,q[0]*s.w,q[1]*s.h),d=Math.hypot(w[0]-p[0],w[1]-p[1]);if(d<bd){bd=d;bi=i}});return bi}
function snap(p){let best=null,bd=14/z;C().sh.forEach(s=>{if((s.t=='line'||s.t=='path')&&s.pts&&!s.cl){[s.pts[0],s.pts[s.pts.length-1]].forEach(q=>{const w=l2w(s,q[0]*s.w,q[1]*s.h),d=Math.hypot(w[0]-p[0],w[1]-p[1]);if(d<bd){bd=d;best=w}})}});return best||p}
function pick(p){const c=C();for(let i=c.sh.length-1;i>=0;i--){const s=c.sh[i];if(s.hid||s.lk)continue;const l=w2l(s,p[0],p[1]),t=(8+(s.s?s.sw/2:0))/z;if(Math.abs(l[0])<=s.w/2+t&&Math.abs(l[1])<=s.h/2+t)return s}}
// 太さ(px): 空欄・不正値は直前の有効値。0以上の小数可。ペン類は0→1、図形の縁は0=縁なし(色を透明に)
let swLast=4;
function swNum(){const v=parseFloat($('#sw').value);if(!isFinite(v))return swLast;return swLast=Math.max(0,v)}
function penLike(){return C().k=='b'||['brush','pen','eras','line'].includes(tool)}
function swv(){const v=swNum();return v>0?v:1}
function swNorm(){const e=$('#sw'),v=parseFloat(e.value);if(!isFinite(v))e.value=swLast;else if(v<0)e.value=0;if(penLike()&&!(parseFloat(e.value)>0)){e.value=1;swLast=1}else swLast=Math.max(0,parseFloat(e.value))}
function sty(){const w=swNum(),pen=penLike();return{f:$('#fo').checked?fv():null,s:$('#so').checked&&(w>0||pen)?col('sc'):null,sw:pen?(w>0?w:1):w,sj:SJ}}
function box(a,b,sq){let dx=b[0]-a[0],dy=b[1]-a[1];if(sq){const m=Math.max(Math.abs(dx),Math.abs(dy));dx=Math.sign(dx||1)*m;dy=Math.sign(dy||1)*m}return[[a[0],a[1]],[a[0]+dx,a[1]+dy]]}
function mkS(t,a,b){const w=Math.max(Math.abs(b[0]-a[0]),1),h=Math.max(Math.abs(b[1]-a[1]),1),y=sty(),s={t,x:(a[0]+b[0])/2,y:(a[1]+b[1])/2,r:0,w,h,...y};
if(t=='rect')s.rr=+$('#rr').value;
if(t=='line'){s.f=null;s.s=y.s||col('fc');s.pts=[[(a[0]-s.x)/w,(a[1]-s.y)/h],[(b[0]-s.x)/w,(b[1]-s.y)/h]]}return s}
function mkC(a,b,kind){const w=Math.max(Math.abs(b[0]-a[0]),1),h=Math.max(Math.abs(b[1]-a[1]),1),s={x:(a[0]+b[0])/2,y:(a[1]+b[1])/2,r:0,w,h,...sty()};
if(kind=='poly')Object.assign(s,{t:'path',pts:ngon(Math.max(3,Math.min(24,+$('#ns').value|0)),+$('#ind').value/100),cl:1,sm:0});
else{const e=SHL[curShape];if(e.pts)Object.assign(s,{t:'path',pts:e.pts,cl:1,sm:0});else Object.assign(s,{t:'pd',d:e.d,w0:1,h0:1})}return s}
function mkA(a,b){const len=Math.max(Math.hypot(b[0]-a[0],b[1]-a[1]),1);return{t:'path',x:(a[0]+b[0])/2,y:(a[1]+b[1])/2,r:Math.atan2(b[1]-a[1],b[0]-a[0]),w:len,h:Math.max(swNum()*3,18),pts:[[-.5,-.2],[.1,-.2],[.1,-.5],[.5,0],[.1,.5],[.1,.2],[-.5,.2]],cl:1,sm:0,...sty()}}
function mkP(P,kind){const xs=P.map(q=>q[0]),ys=P.map(q=>q[1]),x0=Math.min(...xs),x1=Math.max(...xs),y0=Math.min(...ys),y1=Math.max(...ys),w=Math.max(x1-x0,1),h=Math.max(y1-y0,1),y=sty(),s={t:'path',x:(x0+x1)/2,y:(y0+y1)/2,r:0,w,h,sw:y.sw,sj:SJ,f:null,s:kind=='brush'?col('fc'):kind=='eras'?'rgba(120,120,120,.5)':col('sc'),sm:1};
s.pts=P.map(q=>[(q[0]-s.x)/w,(q[1]-s.y)/h]);if(s.pts.length<2)s.pts.push(s.pts[0]);return s}
function build(a,b,sq){if(tool=='rect'||tool=='ell'){const q=box(a,b,sq);return mkS(tool,q[0],q[1])}
if(tool=='line')return mkS('line',snap(a),snap(b));if(tool=='poly'||tool=='shp'){const q=box(a,b,sq);return mkC(q[0],q[1],tool)}
if(tool=='arw')return mkA(a,b);if(tool=='cut'){const s=mkS('line',a,b);s.s='#e33';s.sw=2/z;return s}}
function down(e){const c=C(),p=pt(e);drag={p0:p,p,mv:0,h0:HC,r0:c.r.slice()};pvClear();
if(pickMode){const t=pickMode;pickMode=null;cv.style.cursor='';$('#cp').classList.remove('hid');pickState();drag=null;if(p[0]>=0&&p[1]>=0&&p[0]<c.w&&p[1]<c.h){const o=document.createElement('canvas');o.width=c.w;o.height=c.h;const ox_=o.getContext('2d');dc(ox_,c);const d=ox_.getImageData(Math.floor(p[0]),Math.floor(p[1]),1,1).data;CP.t=t;setHSVfrom({r:d[0],g:d[1],b:d[2],a:d[3]/255},false)}return}
if(tool=='hand'){drag.h=[e.clientX,e.clientY,ox,oy];return}
if(tool=='ctr'){drag.m='ctr';PRV.ctr=p;draw();return}
if(c.k=='b')return bdown(c,p);
if(tool=='sel'&&!multi&&!e.shiftKey){const now=performance.now();if(DT&&now-DT.t<420&&Math.hypot(e.clientX-DT.x,e.clientY-DT.y)<26){const h0=pick(p);if(h0&&h0.t=='txt'&&!h0.lk)TT={p,x:e.clientX,y:e.clientY,h:h0};DT=null}else DT={t:now,x:e.clientX,y:e.clientY}}
if(tool=='sel'){const h=hitH(p);if(h){Object.assign(drag,h);return}
const hit=pick(p),add=multi||e.shiftKey;
if(hit){const grp=hit.g?c.sh.filter(s=>s.g==hit.g):[hit];if(add){grp.every(s=>sel.includes(s))?sel=sel.filter(s=>!grp.includes(s)):sel=[...new Set([...sel,...grp])]}else if(!sel.includes(hit))sel=grp;drag.m='mv'}
else{if(!add)sel=[];drag.m='band'}sync();draw()}
else if(tool=='rsh'){const s=sel[0];
if(s&&s.bz){const hh=hHandle(s,p);if(hh){Object.assign(drag,{m:'bh',i:selPt,k:hh});return}
const i=hpt(s,p);if(i>=0){if(multi||e.shiftKey){spTog(s,i);drag=null;sync();draw();return}const A=selPts();if(A.length>1&&A.includes(i)){Object.assign(drag,{m:'pts',A:A.slice(),col:i});sync();draw();return}SPA.s=s;SPA.a=[i];selPt=i;Object.assign(drag,{m:'pt',i,L:links(s,i)});sync();draw();return}
const sg=segHit(s,p);if(sg){const w=pvClone(s);PRV.map=new Map([[s,w]]);const j=insertAt(w,sg);selPt=j;Object.assign(drag,{m:'pt',i:j,mv:1,L:[]});sync();draw();return}}
const h=pick(p);drag=null;sel=[];selPt=-1;if(h){if(h.t=='img'||h.t=='txt')alert('この図形は点の編集に未対応です(文字・画像は対象外)');else{if(!h.bz){hist();toBz(h)}sel=[h]}}sync();draw()}
else if(tool=='fill'){drag.m='fill';vFillPrev(p)}
else if(tool=='txt'){drag=null;const h0=pick(p);TT={p,x:e.clientX,y:e.clientY,h:h0&&h0.t=='txt'&&!h0.lk?h0:null}}
else if(tool=='pen'||tool=='brush'||tool=='eras'){drag.P=[p]}
else if(tool=='line'){drag.m='mk';drag.p0=snap(p)}
else drag.m='mk'}
function mv(e){const c=C(),d=drag;if(!d)return;
if(d.h){ox=d.h[2]+e.clientX-d.h[0];oy=d.h[3]+e.clientY-d.h[1];return draw()}
const p=pt(e),dx=p[0]-d.p[0],dy=p[1]-d.p[1];d.p=p;
if(d.m=='ctr'){PRV.ctr=p;return draw()}if(c.k=='b'&&tool!='bsel')return bmove(c,p);
if(d.P){const l=d.P[d.P.length-1];if(Math.hypot(p[0]-l[0],p[1]-l[1])*z>2)d.P.push(p);tmp=mkP(d.P,tool);if(tool=='eras'){tmp.sw=swv();if(typeof paper!='undefined'){tmp=null;PRV.cur=[p[0],p[1],swv()/2];const P=d.P.slice();pvSoon(()=>{if(drag!==d)return;const r=eraseCalc(P,swv()/2);PRV.list=r&&r.ch?r.out:null})}}}
else if(d.m=='mk')tmp=build(d.p0,p,e.shiftKey);
else if(d.m=='fill')pvSoon(()=>vFillPrev(p));
else if(d.m=='mv'){const bs=sel[0]&&sel[0].t=='bs';if(!d.mv){pvBegin(bs?sel.slice(0,1):sel);d.mv=1;d.o=sel.map(s=>[s.x,s.y]);if(bs)d.bb=[sel[0].x,sel[0].y];else{const F=sel.filter(s=>!s.lk),u=F.length?ubox(F):[0,0,0,0];d.bb=[(u[0]+u[2])/2,(u[1]+u[3])/2]}}
let tx=p[0]-d.p0[0],ty=p[1]-d.p0[1];snapG=null;if(bs){tx=Math.round(tx);ty=Math.round(ty)}
if(SNAP&&!e.altKey){const th=8/z,cx0=c.w/2,cy0=c.h/2,nx=d.bb[0]+tx,ny=d.bb[1]+ty;let a=0,b=0;if(Math.abs(nx-cx0)<th){tx+=cx0-nx;a=1}if(Math.abs(ny-cy0)<th){ty+=cy0-ny;b=1}if(bs){tx=Math.round(tx);ty=Math.round(ty)}if(a||b)snapG={x:a,y:b}}
sel.forEach((s,i)=>{if(bs||!s.lk){const w=vs(s);w.x=d.o[i][0]+tx;w.y=d.o[i][1]+ty}})}
else if(sel.length>1&&(d.m=='rot'||d.m=='rs'||d.m=='re'))gTransform(d,p,e);
else if(d.m=='rot'){if(!d.mv){pvBegin([sel[0]]);d.mv=1}const s=vs(sel[0]);let a=Math.atan2(p[1]-s.y,p[0]-s.x)+Math.PI/2;if(e.shiftKey)a=Math.round(a/.2618)*.2618;s.r=a}
else if(d.m=='pts'){if(!d.mv){pvBegin([sel[0]]);d.mv=1}const s=vs(sel[0]);d.A.forEach(i=>{const w=W_(s,i);setW(s,i,w[0]+dx,w[1]+dy)});renorm(s)}
else if(d.m=='pt'){if(!d.mv){pvBegin([sel[0],...(d.L||[]).map(q=>q[0])]);d.mv=1}const s=vs(sel[0]),l=w2l(s,p[0],p[1]);s.pts[d.i][0]=l[0]/s.w;s.pts[d.i][1]=l[1]/s.h;(d.L||[]).forEach(([o0,j])=>{const o=vs(o0),m=w2l(o,p[0],p[1]);o.pts[j][0]=m[0]/o.w;o.pts[j][1]=m[1]/o.h;renorm(o)});renorm(s)}
else if(d.m=='bh'){if(!d.mv){pvBegin([sel[0]]);d.mv=1}const s=vs(sel[0]),q=s.pts[d.i],l=w2l(s,p[0],p[1]),hx=l[0]/s.w-q[0],hy=l[1]/s.h-q[1];const R=rng(s).find(r=>d.i>=r[0]&&d.i<r[1])||[0,s.pts.length,!!s.cl],hasP=R[2]||d.i>R[0],hasN=R[2]||d.i<R[1]-1,sym=e.shiftKey||SYM;
if(d.k=='i'){q[2]=hx;q[3]=hy;if(sym&&hasN){q[4]=-hx;q[5]=-hy}}else{q[4]=hx;q[5]=hy;if(sym&&hasP){q[2]=-hx;q[3]=-hy}}}
else if(d.m=='bnew'){const c0=C(),x0=Math.max(0,Math.min(d.p0[0],p[0])),x1=Math.min(c0.w,Math.max(d.p0[0],p[0])),y0=Math.max(0,Math.min(d.p0[1],p[1])),y1=Math.min(c0.h,Math.max(d.p0[1],p[1])),X=Math.round(x0),Y=Math.round(y0),w=Math.round(x1)-X,h=Math.round(y1)-Y;sel=w>0&&h>0?[{t:'bs',x:X+w/2,y:Y+h/2,r:0,w,h,src:[X,Y,w,h],cvs:null}]:[];sync()}
else if(d.m=='re'){if(!d.mv){pvBegin([sel[0]]);d.mv=1}const s=vs(sel[0]),[ex,ey]=EK[d.e],co=Math.cos(s.r),sn=Math.sin(s.r),A=l2w(s,-ex*s.w/2,-ey*s.h/2),vx=p[0]-A[0],vy=p[1]-A[1];
if(ex){const nw=Math.max(1,(vx*co+vy*sn)*ex);s.w=nw;s.x=A[0]+ex*nw/2*co;s.y=A[1]+ex*nw/2*sn}else{const nh=Math.max(1,(-vx*sn+vy*co)*ey);s.h=nh;s.x=A[0]-ey*nh/2*sn;s.y=A[1]+ey*nh/2*co}}
else if(d.m=='rs'){if(!d.mv){pvBegin([sel[0]]);d.mv=1}const s=vs(sel[0]),[sx,sy]=K[d.i],A=l2w(s,-sx*s.w/2,-sy*s.h/2),vx=p[0]-A[0],vy=p[1]-A[1],co=Math.cos(s.r),sn=Math.sin(s.r);
let nw=Math.max(1,(vx*co+vy*sn)*sx),nh=Math.max(1,(-vx*sn+vy*co)*sy);
if(s.t=='txt'||s.t=='img'||e.shiftKey){const k=Math.max(nw/s.w,nh/s.h);nw=s.w*k;nh=s.h*k}
if(s.t=='bs'){nw=Math.max(1,Math.round(nw));nh=Math.max(1,Math.round(nh))}s.w=nw;s.h=nh;if(s.t=='txt')s.fs=nh/1.2;const ax=sx*nw/2,ay=sy*nh/2;s.x=A[0]+ax*co-ay*sn;s.y=A[1]+ax*sn+ay*co}
else if(d.m=='band')band=[d.p0[0],d.p0[1],p[0],p[1]];
draw()}
function up(e){const c=C(),d=drag;drag=null;snapG=null;if(!d||d.h){pvClear();return}if(d.m=='pts'&&!d.mv){SPA.s=sel[0];SPA.a=[d.col];selPt=d.col}
/* 確定: ここで初めて履歴に積み、実データへ反映する(動かしていない・キャンセルした場合はプレビューを捨てるだけ) */
if(PVTF.includes(d.m)){if(d.mv&&PRV.map)pvApply();else pvClear()}
else if(d.m=='ctr'){const q=PRV.ctr;pvClear();if(q){hist();c.cx=q[0];c.cy=q[1]}return fin()}
else if(d.pv)bCommit(c,d);
else if(d.m=='bfill')bFillCommit(c,d.p);
else if(d.m=='fill'){const h=pick(d.p);pvClear();if(h){hist();fillTargets(h).forEach(fillTo);fin()}else draw();return}
else pvClear();
if(c.k=='b'){if(d.m=='bnew')trimSel();return fin()}
if(d.P){const s=tmp;tmp=null;if(tool=='eras')eraseAt(d.P,swv()/2);else if(tool=='brush'){const n=brushShape(d.P,swv()/2);if(n){hist();c.sh.push(n);sel=[n]}}else if(s){hist();c.sh.push(s);sel=[s]}}
else if(d.m=='mk'){const s=tmp;tmp=null;if(Math.hypot(d.p[0]-d.p0[0],d.p[1]-d.p0[1])*z>4){if(tool=='cut')cutAt(d.p0,d.p);else if(s){hist();c.sh.push(s);sel=[s]}}}
else if(d.m=='band'&&band){const x0=Math.min(band[0],band[2]),x1=Math.max(band[0],band[2]),y0=Math.min(band[1],band[3]),y1=Math.max(band[1],band[3]);
const hit=c.sh.filter(s=>!s.hid&&!s.lk&&s.x>=x0&&s.x<=x1&&s.y>=y0&&s.y<=y1);sel=multi||e.shiftKey?[...new Set([...sel,...hit])]:hit;band=null}
fin()}
// ===== プレビューの開始・確定(共通) =====
const PVTF=['mv','rot','pts','pt','bh','re','rs'];/* 作業コピーを動かす操作 */
// 動かす対象の作業コピーを作る。ビットマップの範囲選択は、持ち上げた画素と「元の位置を空けた下地」をプレビュー用に作る(本体はまだ変更しない)
function pvBegin(L){pvStart(L);const b=L[0]&&L[0].t=='bs'?L[0]:null;if(!b)return;const c=C(),w=PRV.map.get(b);
if(!b.cvs){w.cvs=region(b);const o=document.createElement('canvas');o.width=c.w;o.height=c.h;const x=o.getContext('2d');x.drawImage(c.bc,0,0);x.clearRect(b.src[0],b.src[1],b.src[2],b.src[3]);PRV.bm=o}}
// 作業コピーの内容を実図形へ反映(履歴は確定時に1回だけ)
function pvApply(){const M=PRV.map;if(!M||!M.size){pvClear();return}pre();
M.forEach((w,o)=>{if(o.t=='bs'){['x','y','w','h','r','fx','fy'].forEach(k=>{if(w[k]!==undefined)o[k]=w[k]})}else{Object.keys(o).forEach(k=>{if(!(k in w))delete o[k]});Object.keys(w).forEach(k=>{o[k]=w[k]})}});pvClear()}
// バケツ(ベクター): 押下中・ホバー中に塗り結果を作業コピーで表示。確定は指を離したとき
function fillTo(s){if(s.t=='line'||(s.t=='path'&&!s.cl&&!s.f))s.s=col('fc');else s.f=fv()}
// 同色一括: Ctrl(Mac: ⌘)を押しながら、または「同色一括」チェックONで有効。FAは直近のポインター操作時点の状態
let FA=false,LPE=null;
const ftolT=()=>{const e=$('#ftol'),v=e?parseFloat(e.value):4;return Math.round(Math.max(0,Math.min(100,isFinite(v)?v:4))*10)};
const fillAllOn=e=>!!($('#fall')&&$('#fall').checked)||!!(e&&(e.ctrlKey||e.metaKey));
const fillIsStroke=s=>s.t=='line'||(s.t=='path'&&!s.cl&&!s.f);
/* 色の距離(RGBAの差の合計。アルファは255倍)。文字列でない色(グラデーション)は完全一致のみ */
function colDist(a,b){if(a===b)return 0;if(typeof a!='string'||typeof b!='string')return JSON.stringify(a)===JSON.stringify(b)?0:1e9;const p=parseC(a),q=parseC(b);if(!p||!q)return 1e9;return Math.abs(p.r-q.r)+Math.abs(p.g-q.g)+Math.abs(p.b-q.b)+Math.abs(p.a-q.a)*255}
function fillTargets(h){if(!FA)return[h];const isS=fillIsStroke(h),v=isS?h.s:h.f;if(v==null||v===''||v==='none')return[h];const T=ftolT();
return C().sh.filter(s=>s===h||(s.t!='img'&&!s.hid&&!s.lk&&fillIsStroke(s)==isS&&(isS?s.s:s.f)!=null&&colDist(v,isS?s.s:s.f)<=T))}
function vFillPrev(p){const h=pick(p);PRV.hv=1;if(!h){PRV.map=null;return}const M=new Map();fillTargets(h).forEach(o=>{const w=pvClone(o);fillTo(w);M.set(o,w)});PRV.map=M}
function fillAllRefresh(){const n=fillAllOn(LPE);if(n===FA&&!arguments[0])return;FA=n;if(tool!='fill'||drag||OP!='idle'||!LPE)return;PRV.hp=null;const c=C(),p=pt(LPE);if(p[0]<0||p[1]<0||p[0]>=c.w||p[1]>=c.h)return;c.k=='b'?bFillPrev(c,p):vFillPrev(p);draw()}
addEventListener('pointerdown',e=>{LPE=e;FA=fillAllOn(e)},true);addEventListener('pointermove',e=>{LPE=e;FA=fillAllOn(e)},true);addEventListener('pointerup',e=>{FA=fillAllOn(e)},true);
addEventListener('keydown',e=>{if(e.key=='Control'||e.key=='Meta')fillAllRefresh()});addEventListener('keyup',e=>{if(e.key=='Control'||e.key=='Meta')fillAllRefresh()});
{const f=$('#fall');if(f)f.addEventListener('change',()=>fillAllRefresh(1));const r=$('#ftol'),o=$('#ftolv');if(r)r.addEventListener('input',()=>{if(o)o.textContent=r.value;fillAllRefresh(1)})}
// バケツ(ビットマップ): 塗り結果をプレビュー用キャンバスに作る
let bfc=null;
function bFillPrev(c,p){const px=Math.floor(p[0]),py=Math.floor(p[1]);PRV.hv=1;const T=ftolT();if(PRV.hp&&PRV.hp[0]==px&&PRV.hp[1]==py&&PRV.hp[2]===FA&&PRV.hp[3]===T)return;PRV.hp=[px,py,FA,T];const k=getC('sc'),im=floodCalc(c,px,py,[k.r,k.g,k.b,Math.round(k.a*255)]);if(!im){PRV.bm=null;return}
if(!bfc)bfc=document.createElement('canvas');if(bfc.width!=c.w||bfc.height!=c.h){bfc.width=c.w;bfc.height=c.h}bfc.getContext('2d').putImageData(im,0,0);PRV.bm=bfc}
function bFillCommit(c,p){pvClear();const k=getC('sc'),im=floodCalc(c,p[0],p[1],[k.r,k.g,k.b,Math.round(k.a*255)]);if(!im)return;hist();c.bc.getContext('2d').putImageData(im,0,0)}
function hoverFill(e){const c=C(),p=pt(e);if(p[0]<0||p[1]<0||p[0]>=c.w||p[1]>=c.h){if(PRV.hv){pvClear();draw()}return}pvSoon(()=>{if(drag||OP!='idle')return;c.k=='b'?bFillPrev(c,p):vFillPrev(p)})}
// ペン・ブラシ・消しゴム: 押す前(ホバー中)に「いまクリックしたときの結果」を表示する。確定は従来どおり押して描いたとき
let hvc=null;
function hoverPrev(e){const t=tool;if(t=='fill')return hoverFill(e);if(t!='pen'&&t!='brush'&&t!='eras')return;const c=C(),p=pt(e);
if(c.k=='b'&&(p[0]<0||p[1]<0||p[0]>=c.w||p[1]>=c.h)){if(PRV.hv){pvClear();draw()}return}
pvSoon(()=>{if(drag||OP!='idle'||tool!=t||C()!==c)return;const key=(c.k=='b'?Math.floor(p[0])+','+Math.floor(p[1]):Math.round(p[0]*2)+','+Math.round(p[1]*2))+'|'+swv()+'|'+t+'|'+penK;if(PRV.hp===key)return;
PRV.map=PRV.list=PRV.bm=PRV.cur=PRV.dot=null;PRV.hv=1;PRV.hp=key;
if(c.k=='b'){if(!hvc)hvc=document.createElement('canvas');if(hvc.width!=c.w||hvc.height!=c.h){hvc.width=c.w;hvc.height=c.h}
const x=hvc.getContext('2d');x.save();x.setTransform(1,0,0,1,0,0);x.globalAlpha=1;x.globalCompositeOperation='copy';x.drawImage(c.bc,0,0);x.restore();
const d={pv:hvc,P:[p],seed:((Math.floor(p[0])*73856093)^(Math.floor(p[1])*19349663))|0};bPen(c,d);PRV.bm=hvc;if(t=='eras')PRV.cur=[p[0],p[1],(!$('#aa').checked?Math.max(1,Math.round(swv())):swv()*RS(c))/2]}
else if(t=='eras'){PRV.cur=[p[0],p[1],swv()/2];if(typeof paper!='undefined'){const r=eraseCalc([p],swv()/2);PRV.list=r&&r.ch?r.out:null}}
else PRV.dot=[p[0],p[1],swv()/2,t=='brush'?col('fc'):col('sc')]})}
// ビットマップのペン・消しゴム・図形: 描画はプレビュー用キャンバス(d.pv)。確定時だけ履歴に積んで本体へ書き戻す
function bBegin(c,d){const o=document.createElement('canvas');o.width=c.w;o.height=c.h;o.getContext('2d').drawImage(c.bc,0,0);d.pv=o;PRV.bm=o}
function bCommit(c,d){const o=d.pv;pvClear();if(!o||!d.db)return;hist();const x=c.bc.getContext('2d'),[a,b,e,f]=d.db;x.save();x.setTransform(1,0,0,1,0,0);x.globalAlpha=1;x.imageSmoothingEnabled=false;x.beginPath();x.rect(a,b,e-a,f-b);x.clip();x.globalCompositeOperation='copy';x.drawImage(o,0,0);x.restore()}
addEventListener('keydown',e=>{if(e.key=='Escape'&&drag&&!TE){e.preventDefault();cancelOp()}});/* Escapeで操作を取り消し(プレビューだけ破棄) */
// ===== ビットマップ =====
const PENL=[['round','丸ペン'],['square','四角ペン(ドット)'],['marker','マーカー(半透明)'],['calli','カリグラフィ'],['spray','スプレー'],['dot','点線']];let penK='round';
function samp(P,st){const o=[P[0]];let run=0,nxt=st;for(let i=1;i<P.length;i++){const a=P[i-1],b=P[i],L=Math.hypot(b[0]-a[0],b[1]-a[1]);while(nxt<=run+L){const t=(nxt-run)/L;o.push([a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t]);nxt+=st}run+=L}return o}
// 太さ1px(実ピクセル)のペン/消しゴムは、ブレゼンハムで「ちょうど1ピクセル幅」に描く(AAオフでも欠けない)
function px1(x,P){const f=Math.floor;let a=[f(P[0][0]),f(P[0][1])];x.fillRect(a[0],a[1],1,1);for(let i=1;i<P.length;i++){const b=[f(P[i][0]),f(P[i][1])],dx=Math.abs(b[0]-a[0]),dy=-Math.abs(b[1]-a[1]),sx=a[0]<b[0]?1:-1,sy=a[1]<b[1]?1:-1;let e=dx+dy,X=a[0],Y=a[1];for(;;){x.fillRect(X,Y,1,1);if(X==b[0]&&Y==b[1])break;const e2=2*e;if(e2>=dy){e+=dy;X+=sx}if(e2<=dx){e+=dx;Y+=sy}}a=b}}
const PEN={round:(x,P,sz,c)=>{if(sz<=1.001){x.fillStyle=c;return px1(x,P)}x.fillStyle=x.strokeStyle=c;x.lineWidth=sz;x.lineCap=x.lineJoin='round';x.beginPath();x.arc(P[0][0],P[0][1],sz/2,0,7);x.fill();x.beginPath();x.moveTo(P[0][0],P[0][1]);P.forEach(p=>x.lineTo(p[0],p[1]));x.stroke()},
square:(x,P,sz,c)=>{x.fillStyle=c;if(sz<=1.001)return px1(x,P);samp(P,.5).forEach(p=>x.fillRect(p[0]-sz/2,p[1]-sz/2,sz,sz))},
calli:(x,P,sz,c,sd,R=1)=>{x.strokeStyle=c;x.lineWidth=1.5*R;x.lineCap='round';const n=sz/2*.7071;samp(P,.5).forEach(p=>{x.beginPath();x.moveTo(p[0]-n,p[1]+n);x.lineTo(p[0]+n,p[1]-n);x.stroke()})},
spray:(x,P,sz,c,sd,R=1)=>{x.fillStyle=c;let r=sd|0;const rnd=()=>{r=(r+0x6D2B79F5)|0;let t=Math.imul(r^r>>>15,1|r);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296};samp(P,Math.max(R,sz/6)).forEach(p=>{for(let k=0;k<Math.ceil(sz/2/R);k++){const a=rnd()*6.2832,d=sz/2*Math.sqrt(rnd());x.fillRect(Math.round(p[0]+Math.cos(a)*d),Math.round(p[1]+Math.sin(a)*d),R,R)}})},
dot:(x,P,sz,c,sd,R=1)=>{x.fillStyle=c;samp(P,Math.max(2*R,sz*1.8)).forEach(p=>{x.beginPath();x.arc(p[0],p[1],sz/2,0,7);x.fill()})}};PEN.marker=PEN.round;
function bRender(c,d,bb,paint,o){
const x0=Math.max(0,Math.floor(bb[0])),y0=Math.max(0,Math.floor(bb[1])),x1=Math.min(c.w,Math.ceil(bb[2])),y1=Math.min(c.h,Math.ceil(bb[3])),w=x1-x0,h=y1-y0,x=d.pv.getContext('2d');
/* 描画先は本体(c.bc)ではなくプレビュー用キャンバス。
   前回の描画範囲だけを本体から復元し、同じ線を重ね続けない。 */
if(d.db){
 const[a,b,e,f]=d.db;
 x.save();
 x.beginPath();x.rect(a,b,e-a,f-b);x.clip();
 /* copy合成は透明画素まで置換するため、クリップ端や透明度の扱いが
    ブラウザ差で不安定にならないよう、範囲を消してから元画像を戻す。 */
 x.globalAlpha=1;x.globalCompositeOperation='source-over';
 x.clearRect(a,b,e-a,f-b);
 x.imageSmoothingEnabled=false;
 x.drawImage(c.bc,0,0);
 x.restore();
}
if(w<=0||h<=0)return;
const L=document.createElement('canvas');L.width=w;L.height=h;
const lx=L.getContext('2d');lx.imageSmoothingEnabled=false;
/* AA OFF専用: o.pix があれば、Canvasで描いて二値化する代わりに、ピクセルを直接置く(ブラシ・四角ペン・消しゴム・線ツール) */
const direct=!$('#aa').checked&&!!o.pix;
if(direct){const im0=lx.createImageData(w,h);o.pix(im0.data,x0,y0,w,h);lx.putImageData(im0,0,0)}
else{lx.translate(-x0,-y0);paint(lx)}
if(!$('#aa').checked&&!direct){
 lx.setTransform(1,0,0,1,0,0);
 const im=lx.getImageData(0,0,w,h),q=im.data;
 /* AA OFF: 半透明の縁は「完全不透明か完全透明」の2値にし、不透明にしたピクセルの色は指定色そのものに固定する
   (縁の半透明ピクセルは色が劣化しているため、そのままだと線の一部だけ微妙に違う色になる) */
 const rg=o.rgb;for(let i=3;i<q.length;i+=4){if(q[i]>=128){q[i]=255;if(rg&&!o.erase){q[i-3]=rg[0];q[i-2]=rg[1];q[i-1]=rg[2]}}else{q[i]=0;q[i-1]=q[i-2]=q[i-3]=0}}
 lx.putImageData(im,0,0);
}
x.save();x.globalAlpha=o.alpha;x.globalCompositeOperation=o.erase?'destination-out':'source-over';
x.imageSmoothingEnabled=false;x.drawImage(L,x0,y0);x.restore();
d.db=d.db?[Math.min(d.db[0],x0),Math.min(d.db[1],y0),Math.max(d.db[2],x1),Math.max(d.db[3],y1)]:[x0,y0,x1,y1];
}
/* ===== AA OFF 専用: ピクセル直接描画 =====
   ・サイズ n は「実ピクセルの直径」(解像度倍率は掛けない)。n=max(1,round(太さ))
   ・丸ブラシ: 直径nの円に対し、各ピクセルの面積の50%以上が円に入るものを塗る(従来の二値化=アルファ128と同じ基準)
   ・四角ブラシ: n×n
   ・中心は整数座標に丸め(奇数サイズ=切り捨て、偶数サイズ=四捨五入=ピクセルの角)、連続する2点はブレゼンハム法で結んで全点にスタンプ
   ※Scratch公式ソース未確認のため、ブラシ形状・丸め方は暫定仕様 */
const BM_CACHE=new Map();
function bmMask(n,kind){const key=kind+n,h=BM_CACHE.get(key);if(h)return h;if(BM_CACHE.size>64)BM_CACHE.clear();const rows=[];
if(kind=='square'){for(let j=0;j<n;j++)rows.push([0,n])}
else{const S=n<=64?8:4,r=n/2,r2=r*r;for(let j=0;j<n;j++){let l=-1,rt=-1;for(let i=0;i<n;i++){let cnt=0;for(let sy=0;sy<S;sy++){const yy=j+(sy+.5)/S-r;for(let sx=0;sx<S;sx++){const xx=i+(sx+.5)/S-r;if(xx*xx+yy*yy<=r2)cnt++}}if(cnt*2>=S*S){if(l<0)l=i;rt=i+1}}rows.push(l<0?null:[l,rt])}}
BM_CACHE.set(key,rows);return rows}
function bPix(P,n,kind,rgb){const rows=bmMask(n,kind),hf=Math.floor(n/2),odd=n%2==1,cen=P.map(p=>odd?[Math.floor(p[0]),Math.floor(p[1])]:[Math.round(p[0]),Math.round(p[1])]);
return(D,x0,y0,w,h)=>{const st=(cx,cy)=>{const ox=cx-hf,oy=cy-hf;for(let j=0;j<n;j++){const y=oy+j;if(y<y0||y>=y0+h)continue;const r=rows[j];if(!r)continue;const xa=Math.max(ox+r[0],x0),xb=Math.min(ox+r[1],x0+w);for(let x=xa;x<xb;x++){const i=((y-y0)*w+(x-x0))*4;D[i]=rgb[0];D[i+1]=rgb[1];D[i+2]=rgb[2];D[i+3]=255}}};
let a=cen[0];st(a[0],a[1]);for(let k=1;k<cen.length;k++){const b=cen[k];if(b[0]==a[0]&&b[1]==a[1])continue;let X=a[0],Y=a[1];const dx=Math.abs(b[0]-X),dy=-Math.abs(b[1]-Y),sx=X<b[0]?1:-1,sy=Y<b[1]?1:-1;let e=dx+dy;for(;;){if(X==b[0]&&Y==b[1])break;const e2=2*e;if(e2>=dy){e+=dy;X+=sx}if(e2<=dx){e+=dx;Y+=sy}st(X,Y)}a=b}}}
const rgbOf=c=>`rgb(${c.r},${c.g},${c.b})`;
function swSync(){}
function bPen(c,d){const R=RS(c),k=tool=='eras'?(penK=='square'?'square':'round'):penK,dir=!$('#aa').checked&&(k=='round'||k=='square'),bn=Math.max(1,Math.round(swv())),sz=dir?bn:Math.max(1,swv()*R),cc=getC('sc'),xs=d.P.map(p=>p[0]),ys=d.P.map(p=>p[1]),m=dir?bn/2+2:sz/2+2*R;
bRender(c,d,[Math.min(...xs)-m,Math.min(...ys)-m,Math.max(...xs)+m,Math.max(...ys)+m],x=>PEN[k](x,d.P,sz,rgbOf(cc),d.seed,R),{alpha:tool=='eras'?1:cc.a*(k=='marker'?.45:1),erase:tool=='eras',rgb:[cc.r,cc.g,cc.b],pix:dir?bPix(d.P,bn,k,[cc.r,cc.g,cc.b]):null})}
function bShape(c,d,p){const R=RS(c),dir=!$('#aa').checked&&tool=='bline',bn=Math.max(1,Math.round(swv())),lw=Math.max(1,swv()*R),cc=getC('sc'),a=d.p0,m=dir?bn/2+2:lw/2+2*R;
bRender(c,d,[Math.min(a[0],p[0])-m,Math.min(a[1],p[1])-m,Math.max(a[0],p[0])+m,Math.max(a[1],p[1])+m],x=>{x.fillStyle=x.strokeStyle=rgbOf(cc);x.lineWidth=lw;x.lineCap=x.lineJoin='round';x.beginPath();
if(tool=='bline'){x.moveTo(a[0],a[1]);x.lineTo(p[0],p[1])}else if(tool=='brect')x.rect(a[0],a[1],p[0]-a[0],p[1]-a[1]);else x.ellipse((a[0]+p[0])/2,(a[1]+p[1])/2,Math.abs(p[0]-a[0])/2,Math.abs(p[1]-a[1])/2,0,0,7);
$('#bf').checked&&tool!='bline'?x.fill():x.stroke()},{alpha:cc.a,rgb:[cc.r,cc.g,cc.b],pix:dir?bPix([a,p],bn,'round',[cc.r,cc.g,cc.b]):null})}
function bdown(c,p){if(tool=='bsel'){const b=sel[0]&&sel[0].t=='bs'?sel[0]:null;if(b){if(bsPx(b)>0){const h=hitH(p);if(h){Object.assign(drag,h);return}const l=w2l(b,p[0],p[1]);if(Math.abs(l[0])<=b.w/2&&Math.abs(l[1])<=b.h/2){drag.m='mv';return}}bcommit()}drag.m='bnew';return}
if(tool=='brush'||tool=='eras'){bBegin(c,drag);drag.P=[p];drag.seed=(Math.random()*4e9)|0;bPen(c,drag);draw()}
else if(tool=='brect'||tool=='bell'||tool=='bline'){bBegin(c,drag)}
else if(tool=='fill'){drag.m='bfill';bFillPrev(c,p)}
else if(tool=='pick'){const x=Math.floor(p[0]),y=Math.floor(p[1]);if(x>=0&&y>=0&&x<c.w&&y<c.h){const d=c.bc.getContext('2d').getImageData(x,y,1,1).data;if(d[3])setCol('sc',`rgba(${d[0]},${d[1]},${d[2]},${+(d[3]/255).toFixed(3)})`)}drag=null}}
function bmove(c,p){const d=drag;if(tool=='brush'||tool=='eras'){const l=d.P[d.P.length-1],off=!$('#aa').checked&&(tool=='eras'||penK=='round'||penK=='square');if(off?(p[0]!=l[0]||p[1]!=l[1]):Math.hypot(p[0]-l[0],p[1]-l[1])>=.35){d.P.push(p);bPen(c,d);draw()}}else if(d.pv){bShape(c,d,p);draw()}else if(d.m=='bfill'){pvSoon(()=>bFillPrev(c,p))}}
function floodCalc(c,px,py,col,all=FA,T=ftolT()){px|=0;py|=0;if(px<0||py<0||px>=c.w||py>=c.h)return null;const x=c.bc.getContext('2d'),im=x.getImageData(0,0,c.w,c.h),D=im.data,W=c.w,H=c.h,o=(py*W+px)*4,t=[D[o],D[o+1],D[o+2],D[o+3]],n=col;
if(t[0]==n[0]&&t[1]==n[1]&&t[2]==n[2]&&t[3]==n[3])return null;
if(all){for(let i=0;i<D.length;i+=4)if(Math.abs(D[i]-t[0])+Math.abs(D[i+1]-t[1])+Math.abs(D[i+2]-t[2])+Math.abs(D[i+3]-t[3])<=T){D[i]=n[0];D[i+1]=n[1];D[i+2]=n[2];D[i+3]=n[3]}return im}
const seen=new Uint8Array(W*H),S=[py*W+px];
while(S.length){const q=S.pop();if(seen[q])continue;const i=q*4;if(Math.abs(D[i]-t[0])+Math.abs(D[i+1]-t[1])+Math.abs(D[i+2]-t[2])+Math.abs(D[i+3]-t[3])>T)continue;seen[q]=1;D[i]=n[0];D[i+1]=n[1];D[i+2]=n[2];D[i+3]=n[3];const X=q%W;if(X>0)S.push(q-1);if(X<W-1)S.push(q+1);if(q>=W)S.push(q-W);if(q+W<W*H)S.push(q+W)}
return im}
function cleanAlpha(){const c=C();if(!c||c.k!='b')return;bcommit();const x=c.bc.getContext('2d'),im=x.getImageData(0,0,c.w,c.h),d=im.data;let n=0;
for(let i=3;i<d.length;i+=4){const a=d[i];if(a>0&&a<255){n++;if(a>=128)d[i]=255;else{d[i]=0;d[i-1]=d[i-2]=d[i-3]=0}}}
if(!n){alert('半透明のピクセルはありません');return}hist();x.putImageData(im,0,0);fin();alert(n+'個の半透明ピクセルを整理しました')}
$('#bclean').onclick=cleanAlpha;
function flood(c,px,py,col){const im=floodCalc(c,px,py,col);if(im)c.bc.getContext('2d').putImageData(im,0,0)}
// ===== UI =====
function fin(){ONG++;if(fin.k!=C().k){fin.k=C().k;const v=C().k=='v';if(!(v?TV:TB).includes(tool))tool=v?'sel':'brush';if(!v)sel=sel.filter(s=>s.t=='bs');tools()}thumbs();sync();draw();clearTimeout(fin.t);fin.t=setTimeout(bkRun,1200)}
function bkRun(){const t0=performance.now();for(const c of AC()){if(c.k=='b'&&c!==C()&&!c._fu){c._fu=flatURL(c);if(performance.now()-t0>14){fin.t=setTimeout(bkRun,40);return}}}let n=0;for(const c of AC())if(c._fu)n+=c._fu.length;if(n>4.2e6)return;try{localStorage.setItem('ced_bk',ser(1))}catch(e){}}
const TS={sel:'選択',rsh:'点編集',brush:'ブラシ',pen:'ペン',eras:'消しゴム',fill:'塗り',txt:'文字',line:'線',ell:'楕円',rect:'四角',poly:'多角形',shp:'図形',arw:'矢印',cut:'分割',hand:'移動',ctr:'中心',pick:'抽出',brect:'四角',bell:'楕円',bline:'線',bsel:'範囲'},TK={sel:'V',rsh:'A',brush:'B',pen:'P',eras:'E',txt:'T'},TG={rsh:1,txt:1,arw:1,bsel:1,pick:1,bline:1};
function tools(){const c=C();pvClear();$('#tools').innerHTML='';(c.k=='v'?TV:TB).forEach(k=>{const b=document.createElement('button');setB(b,k,TN[k]+(TK[k]?' ['+TK[k]+']':''),TS[k]);b.setAttribute('aria-pressed',k==tool);b.className=k==tool?'on':'';b.onclick=()=>{if(C().k=='b')bcommit();tool=k;swNorm();selPt=-1;if(k!='sel'&&k!='rsh'&&k!='bsel')sel=[];tools();sync();draw()};$('#tools').append(b);if(TG[k])$('#tools').insertAdjacentHTML('beforeend','<i class="tsep"></i>')})}
const dis=(i,v)=>{$('#'+i).disabled=!!v};
function sync(){cnameSync();const c=C(),v=c.k=='v',s0=sel[0];
['dp','dl','mu','fr','bkb','gp','ug','arr'].forEach(i=>$('#'+i).hidden=!v);$('#bdel').hidden=v;$('#snapb').className=SNAP?'on':'';$('#snapb').setAttribute('aria-pressed',!!SNAP);$('#l_fc').hidden=$('#fo').parentNode.hidden=$('#l_so').hidden=$('#g_sj').hidden=!v;
$('#g_rr').hidden=!(v&&(tool=='rect'||(s0&&s0.t=='rect')));$('#g_pg').hidden=!(v&&tool=='poly');
$('#g_ft').hidden=!(v&&(tool=='txt'||(s0&&(s0.t=='txt'||s0.ot||s0.g&&C().sh.some(q=>q.g==s0.g&&q.ot)))));$('#g_bf').hidden=!(!v&&(tool=='brect'||tool=='bell'));$('#g_fall').hidden=tool!='fill';
$('#shpp').hidden=!(v&&tool=='shp');if(!$('#shpp').hidden&&!$('#shpp').firstChild)buildShp();
setB($('#cs'),v?'strokeon':'brush',v?'線の色(タップでカラーピッカー)':'ブラシの色(タップでカラーピッカー)');refChips();
$('#g_bpen').hidden=v||!['brush','eras','brect','bell','bline','bsel'].includes(tool);$('#g_pk').hidden=!(tool=='brush'||tool=='eras');$('#g_nd').hidden=v||tool!='bsel';$('#g_gr').hidden=!v;$('#l_fc2').hidden=gm=='s';$('#g_rsh').hidden=!(v&&tool=='rsh');$('#g_bo').hidden=v;
['gs:s','gh:h','gv:v','gr:r'].forEach(x=>{const[i,m]=x.split(':');$('#'+i).className=gm==m?'on':''});$('#mu').className=multi?'on':'';
if(v&&s0){if(s0.t!='img')SJ=jn(s0);if(s0.t!='txt'){$('#fo').checked=!!s0.f;$('#so').checked=!!s0.s||s0.sw===0}if(s0.f){if(typeof s0.f=='string'){gm='s';setCol('fc',s0.f)}else{gm=s0.f.g;setCol('fc',s0.f.c1);setCol('fc2',s0.f.c2)}}if(s0.s)setCol('sc',s0.s);$('#sw').value=s0.sw!=null?s0.sw:4;if(s0.t=='rect')$('#rr').value=s0.rr||0;
if(s0.t=='txt'){const i=FL.findIndex(f=>f.css==s0.fn);if(i>=0)$('#fn').value=i}}
$('#sjm').className=SJ=='miter'?'on':'';$('#sjr').className=SJ=='miter'?'':'on';$('#sjm').setAttribute('aria-pressed',SJ=='miter');$('#sjr').setAttribute('aria-pressed',SJ!='miter');dis('undo',!c.u.length);dis('redo',!c.r.length);
['fr','bkb','dp','dl','ug','al'].forEach(i=>dis(i,!sel.length));dis('gp',sel.length<2);['bmg','bmk','bsb','bft'].forEach(i=>dis(i,sel.length<2));dis('te',!(s0&&s0.t=='txt'));dis('t2p',!(s0&&s0.t=='txt'));dis('p2t',!(s0&&(s0.ot||s0.g&&C().sh.some(q=>q.g==s0.g&&q.ot))));dis('delpt',!(s0&&s0.bz&&selPt>=0));dis('ptm',!(s0&&s0.bz&&selPt>=0));const hb=s0&&s0.t=='bs'&&bsPx(s0)>0;['bcp','bct','bdel','bfh','bfv','nl','nu','nd','nr'].forEach(i=>dis(i,!hb));dis('bps',!(clip||vclip));if(v){dis('bcp',!sel.length);dis('bct',!sel.length);dis('bps',!vclip);dis('bfh',!sel.some(s=>!s.lk));dis('bfv',!sel.some(s=>!s.lk))}swSync();lySync();onSync();$('#symb').className=SYM?'on':'';$('#symb').setAttribute('aria-pressed',!!SYM);if(document.activeElement!==$('#sw'))swNorm();{const go=$('#g_ofs');if(go){go.hidden=!v;$('#ofb').disabled=!sel.length}if(OFS.open){if(!v)ofsClose();else ofsSoon()}const gb=$('#g_bool');if(gb)gb.hidden=!v;const f1=$('#g_ftt');if(f1)f1.hidden=$('#g_ft').hidden;const f2=$('#g_ndt');if(f2)f2.hidden=$('#g_nd').hidden}}
function ap(){const c=C();if(c.k!='v'||!sel.length)return;if(!dirty){hist();dirty=1;dis('undo',0);dis('redo',1)}sel.forEach(s=>{const y=sty();if(s.t=='txt'){s.f=fv();s.s=y.s;s.sw=Math.max(1,y.sw/2)}else if(s.t=='img'){}else{s.f=s.t=='line'?null:y.f;s.s=y.s||(s.t=='line'?col('fc'):null);s.sw=s.t=='line'&&!(y.sw>0)?1:y.sw}});draw();thumbs()}
['fc','fc2','sc','fo','so'].forEach(i=>{$('#'+i).addEventListener('input',ap);$('#'+i).addEventListener('change',()=>{ap();dirty=0})});
{const e=$('#sw');e.addEventListener('input',ap);e.addEventListener('change',()=>{swNorm();ap();dirty=0})}
$('#rr').addEventListener('input',()=>{const l=sel.filter(s=>s.t=='rect');if(!l.length)return;if(!dirty){hist();dirty=1;dis('undo',0);dis('redo',1)}l.forEach(s=>s.rr=+$('#rr').value);draw()});$('#rr').addEventListener('change',()=>{dirty=0;fin()});
/* 縁の角タイプ: 選択中の図形(文字含む)に適用。選択がなければ以後の新規図形に使う */
const sjSet=v=>{SJ=v;const l=C().k=='v'?sel.filter(s=>s.t!='img'&&s.t!='bs'&&jn(s)!=v):[];if(l.length){hist();l.forEach(s=>s.sj=v);fin()}else sync()};
$('#sjm').onclick=()=>sjSet('miter');$('#sjr').onclick=()=>sjSet('round');
$('#fn').onchange=()=>{const l=sel.filter(s=>s.t=='txt');if(!l.length)return;hist();l.forEach(s=>{s.fn=curFont();tm(s)});fin()};
$('#addf').onclick=()=>$('#ff').click();
$('#ff').onchange=e=>{const f=e.target.files[0];if(!f)return;const r=new FileReader();r.onload=async()=>{const n=prompt('フォント名',f.name.replace(/\.[^.]+$/,''));if(!n)return;const fb=prompt('バックアップフォント(読み込み失敗時に使用)','sans-serif')||'sans-serif';const o={n,data:r.result,fb};fonts.push(o);await regFont(o);$('#fn').value=FL.findIndex(x=>x.n==n)};r.readAsDataURL(f);e.target.value=''};
$('#sysf').onclick=async()=>{const n=prompt('システムにあるフォント名');if(!n)return;const fb=prompt('バックアップフォント','sans-serif')||'sans-serif',o={n,data:null,fb};fonts.push(o);await regFont(o);$('#fn').value=FL.findIndex(x=>x.n==n)};
function relabel(d,i){const c=cs[i],g=d.querySelector('i'),l=d.querySelector('.cl');g.textContent=i+1;d.querySelector('canvas')._ix=i;l.textContent=spShort(c.n);l.title=c.n;if(c.k=='b')d.title=`${c.w}×${c.h}px / 解像度${RS(c)} → 論理${+(c.w/RS(c)).toFixed(2)}×${+(c.h/RS(c)).toFixed(2)}`}
function nameLabel(c){const d=CIS()[cs.indexOf(c)];if(!d)return;const l=d.querySelector('.cl');if(l){l.textContent=spShort(c.n);l.title=c.n}if(c===C())cfOpenCur();markDup()}
function list(){const L=$('#list');if(TIO)TIO.disconnect();VIS.clear();list.n=cs.length;L.innerHTML='';cs.forEach((c,i)=>{const d=document.createElement('div');d.className='ci'+(i==ci?' on':'');d.innerHTML=`<i class="grip" title="ドラッグで並べ替え"></i><canvas width=72 height=54></canvas><span class="cl"></span>`;
const ix=()=>cs.indexOf(c);
d.onclick=e=>{if(RD.sup){RD.sup=0;return}const i=ix();if(i==ci)return;go(i)};
L.append(d);relabel(d,i);const tc=d.querySelector('canvas');tc._st=1;if(TIO)TIO.observe(tc);else drawThumb(tc)});lvnApply();L._sig=null;cfOpenCur();cfLayout(1)}
function listSel(){const L=$('#list'),p=L.querySelector('.ci.on'),n=CIS()[ci];if(p)p.classList.remove('on');if(n)n.classList.add('on');cfOpenCur();lvnApply();thumbs()}
/* ===== 独自ダイアログ(alert/confirm の代わり) ===== */
function uiDlg(msg,btns,opt){opt=opt||{};return new Promise(res=>{const prev=document.activeElement,ov=document.createElement('div'),box=document.createElement('div'),p=document.createElement('div'),row=document.createElement('div');
ov.id='uidlg';ov.setAttribute('role','alertdialog');ov.setAttribute('aria-modal','true');box.className='uibox';p.className='uimsg';p.textContent=msg;row.className='uibtns';let done=false;
const close=v=>{if(done)return;done=true;removeEventListener('keydown',kd,true);removeEventListener('keyup',ku,true);ov.remove();try{prev&&prev.focus&&prev.focus()}catch(e){}res(v)};
btns.forEach(b=>{const e=document.createElement('button');e.type='button';e.textContent=b.t;if(b.danger)e.className='danger';e.onclick=()=>close(b.v);row.append(e)});
const kd=e=>{e.stopImmediatePropagation();if(e.key=='Escape'){e.preventDefault();close(opt.esc!==undefined?opt.esc:false)}else if(e.key=='Tab'){const bs=[...row.children],i=bs.indexOf(document.activeElement);e.preventDefault();bs[(i+(e.shiftKey?-1:1)+bs.length)%bs.length].focus()}};
const ku=e=>e.stopImmediatePropagation();addEventListener('keydown',kd,true);addEventListener('keyup',ku,true);
ov.addEventListener('pointerdown',e=>{if(e.target===ov)close(opt.esc!==undefined?opt.esc:false)});box.append(p,row);ov.append(box);document.body.append(ov);(row.children[opt.focus||0]||row.lastChild).focus()})}
const uiAlert=msg=>uiDlg(msg,[{t:'OK',v:true}],{esc:true});
const uiConfirm=(msg,ok,no)=>uiDlg(msg,[{t:no||'キャンセル',v:false},{t:ok||'削除する',v:true,danger:1}],{esc:false,focus:0});
/* ===== コスチューム一覧: 右クリック/長押しメニュー ===== */
let CM=null;const RD={d:null,go:0,sup:0,lp:0};
function cmClose(){if(!CM)return;CM.remove();CM=null;removeEventListener('pointerdown',cmOut,true);removeEventListener('keydown',cmKey,true);removeEventListener('resize',cmClose);$('#list').removeEventListener('scroll',cmClose)}
function cmOut(e){if(CM&&!CM.contains(e.target))cmClose()}
function cmKey(e){if(!CM)return;const bs=[...CM.querySelectorAll('button:not(:disabled)')],i=bs.indexOf(document.activeElement);if(e.key=='Escape'){e.preventDefault();e.stopImmediatePropagation();cmClose()}else if(e.key=='ArrowDown'||e.key=='ArrowUp'){e.preventDefault();e.stopImmediatePropagation();bs[(i+(e.key=='ArrowDown'?1:-1)+bs.length)%bs.length].focus()}else if(e.key=='Tab'){e.preventDefault();e.stopImmediatePropagation();bs[(i+(e.shiftKey?-1:1)+bs.length)%bs.length].focus()}else if(e.key=='Enter'||e.key==' ')e.stopImmediatePropagation()}
function cmOpen(c,x,y){cmClose();const m=document.createElement('div');m.id='cmenu';m.setAttribute('role','menu');
const add=(t,fn,dis,cls)=>{const b=document.createElement('button');b.type='button';b.setAttribute('role','menuitem');b.textContent=t;b.disabled=!!dis;if(cls)b.className=cls;b.onclick=()=>{cmClose();fn()};m.append(b)};
add('コピー(複製)',()=>{const i=cs.indexOf(c);if(i>=0)dupAt(i)});add(c.k=='b'?'書き出し(PNG)':'書き出し(SVG)',()=>{if(cs.indexOf(c)>=0)exportCostume(c)});add('削除',()=>{const i=cs.indexOf(c);if(i>=0)delAt(i)},cs.length<2,'danger');
document.body.append(m);const r=m.getBoundingClientRect();m.style.left=Math.max(4,Math.min(x,innerWidth-r.width-4))+'px';m.style.top=Math.max(4,Math.min(y,innerHeight-r.height-4))+'px';CM=m;
setTimeout(()=>{if(CM!==m)return;addEventListener('pointerdown',cmOut,true);addEventListener('keydown',cmKey,true);addEventListener('resize',cmClose);$('#list').addEventListener('scroll',cmClose)},0);const f=m.querySelector('button:not(:disabled)');if(f)f.focus()}
/* ===== コスチューム一覧: ドラッグで並べ替え =====
   マウス/ペン: 項目のどこでもドラッグ。タッチ: 左上の「⠿ 番号」のつまみをドラッグ(それ以外は一覧のスクロール、長押しでメニュー) */
{const L=$('#list'),ixOf=d=>CIS().indexOf(d);
const target=(x,y)=>{const horiz=getComputedStyle(L).flexDirection.startsWith('row'),kids=[...L.children].filter(c=>c!==RD.d),others=kids.filter(c=>c.classList.contains('ci')),pos=horiz?x:y;let k=0,passed=false;for(const c of kids){const isF=c.classList.contains('cf');if(c.offsetParent===null){if(!isF&&passed)k++;continue}const r=c.getBoundingClientRect(),mid=horiz?(r.left+r.right)/2:(r.top+r.bottom)/2;if(isF){passed=pos>mid;continue}if(pos>mid){k++;passed=true}else break}return{k,others,horiz}};
const showDrop=(x,y)=>{const {k,others,horiz}=target(x,y);RD.k=k;let el=$('#cdrop');if(!el){el=document.createElement('div');el.id='cdrop';document.body.append(el)}if(!others.length){el.style.display='none';return}
let rf=null,after=false;for(let q=k;q<others.length;q++)if(others[q].offsetParent!==null){rf=others[q];break}if(!rf){for(let q=others.length-1;q>=0;q--)if(others[q].offsetParent!==null){rf=others[q];after=true;break}}if(!rf){el.style.display='none';return}const ref=rf.getBoundingClientRect();el.style.display='block';
if(horiz){el.style.left=(after?ref.right+1:ref.left-4)+'px';el.style.top=ref.top+'px';el.style.width='4px';el.style.height=ref.height+'px'}else{el.style.top=(after?ref.bottom+1:ref.top-4)+'px';el.style.left=ref.left+'px';el.style.height='4px';el.style.width=ref.width+'px'}};
const edge=()=>{if(!RD.go)return;const r=L.getBoundingClientRect(),horiz=getComputedStyle(L).flexDirection.startsWith('row'),M=34,s=14;if(horiz){if(RD.px<r.left+M)L.scrollLeft-=s;else if(RD.px>r.right-M)L.scrollLeft+=s}else{if(RD.py<r.top+M)L.scrollTop-=s;else if(RD.py>r.bottom-M)L.scrollTop+=s}showDrop(RD.px,RD.py)};
const end=ok=>{clearTimeout(RD.lp);if(RD.go){clearInterval(RD.iv);const d=RD.d,el=$('#cdrop');if(el)el.remove();d.classList.remove('dragging');document.body.classList.remove('cdragging');try{d.releasePointerCapture(RD.id)}catch(e){}
 if(ok){const from=ixOf(d),{k,others}=target(RD.px,RD.py);if(from>=0&&k!=from){const cur=cs[ci],[m]=cs.splice(from,1);cs.splice(k,0,m);ci=cs.indexOf(cur);L.insertBefore(d,others[k]||null);CIS().forEach((e,j)=>relabel(e,j));fin()}}
 RD.sup=1;setTimeout(()=>{RD.sup=0},60)}RD.d=null;RD.go=0};
L.addEventListener('pointerdown',e=>{if(e.pointerType=='mouse'&&e.button>0)return;const d=e.target.closest('.ci');if(!d||e.target.closest('input,button'))return;cmClose();RD.d=d;RD.id=e.pointerId;RD.x=RD.px=e.clientX;RD.y=RD.py=e.clientY;RD.grip=!!e.target.closest('.grip');RD.touch=e.pointerType=='touch';RD.go=0;clearTimeout(RD.lp);
 if(RD.touch&&!RD.grip)RD.lp=setTimeout(()=>{const c=cs[ixOf(d)];RD.d=null;RD.sup=1;setTimeout(()=>{RD.sup=0},700);if(c)cmOpen(c,RD.x,RD.y)},520)});
addEventListener('pointermove',e=>{if(!RD.d||e.pointerId!=RD.id)return;RD.px=e.clientX;RD.py=e.clientY;const dist=Math.hypot(e.clientX-RD.x,e.clientY-RD.y);
 if(!RD.go){if(RD.touch&&!RD.grip){if(dist>8){clearTimeout(RD.lp);RD.d=null}return}if(dist<(RD.touch?3:6))return;clearTimeout(RD.lp);RD.go=1;RD.d.classList.add('dragging');document.body.classList.add('cdragging');try{RD.d.setPointerCapture(RD.id)}catch(x){}RD.iv=setInterval(edge,40)}
 e.preventDefault();showDrop(e.clientX,e.clientY)},{passive:false});
addEventListener('pointerup',e=>{if(RD.d&&e.pointerId==RD.id){RD.px=e.clientX;RD.py=e.clientY;end(true)}});
addEventListener('pointercancel',e=>{if(RD.d&&e.pointerId==RD.id)end(false)});
addEventListener('keydown',e=>{if(RD.go&&e.key=='Escape'){e.preventDefault();e.stopImmediatePropagation();end(false)}},true);
L.addEventListener('contextmenu',e=>{const d=e.target.closest('.ci');if(!d||e.target.closest('input'))return;e.preventDefault();clearTimeout(RD.lp);if(RD.go)return;RD.d=null;const c=cs[ixOf(d)];if(c)cmOpen(c,e.clientX,e.clientY)})}
/* 上ツール左端のコスチューム名: 現在のコスチュームの名前を表示・変更(幅は固定で、長い名前は欄内で省略/スクロール) */
function cnameSync(){const n=$('#cname');if(n&&document.activeElement!==n)n.value=C().n}
{const nm=$('#cname');nm.onfocus=()=>{nm._c=C()};
nm.onchange=()=>{const c=nm._c||C(),i=cs.indexOf(c);if(i<0)return;renAt(i,nm);nameLabel(c);if(c!==C())nm.value=C().n};
nm.onkeydown=e=>{e.stopPropagation();if(e.key=='Enter'){e.preventDefault();nm.blur()}else if(e.key=='Escape'){e.preventDefault();nm.value=(nm._c||C()).n;nm.blur()}};nm.onkeyup=e=>e.stopPropagation()}
function renAt(i,inp){const v=inp.value.trim();if(!v){inp.value=cs[i].n;inp.classList.add('err');setTimeout(()=>inp.classList.remove('err'),600);return}cs[i].n=v;inp.value=v}
function dupAt(i){bcommit();const c=cs[i],n=mk(c.k,cpName(c.n));rs(n,st(c));cs.splice(i+1,0,n);go(i+1)}
async function delAt(i){const c0=cs[i];if(!c0)return;if(cs.length<2){await uiAlert('最後のコスチュームは削除できません');return}if(!await uiConfirm('コスチューム「'+c0.n+'」を削除しますか?\n(削除後に「戻す」で復元することはできません)'))return;i=cs.indexOf(c0);if(i<0||cs.length<2)return;if(i!=ci)bcommit();cs.splice(i,1);if(i<ci)ci--;else if(i==ci)ci=Math.min(ci,cs.length-1);sel=[];go(ci)}
const VIS=new Set(),TIO='IntersectionObserver' in window?new IntersectionObserver(es=>es.forEach(e=>{const t=e.target;if(e.isIntersecting){VIS.add(t);if(t._st)drawThumb(t)}else VIS.delete(t)}),{rootMargin:'300px'}):null;
/* 画像のうち「透明度1以上(アルファ>0)」のピクセルがある範囲 [x0,y0,x1,y1](x1,y1は含まない)。何も描かれていなければ null */
function bmBBox(src){const w=src.width,h=src.height;if(!w||!h)return null;const D=src.getContext('2d').getImageData(0,0,w,h).data;let x0=w,y0=h,x1=-1,y1=-1;
for(let y=0;y<h;y++){const o=y*w*4+3;let l=-1,r=-1;for(let x=0;x<w;x++)if(D[o+x*4]>0){if(l<0)l=x;r=x}if(l>=0){if(l<x0)x0=l;if(r>x1)x1=r;if(y<y0)y0=y;y1=y}}
return x1<0?null:[x0,y0,x1+1,y1+1]}
// 一覧のサムネイル用(ビットマップのみ)。編集中のコスチュームは選択中の持ち上げも含めて毎回計算、それ以外は結果を使い回す
/* ベクターの「実際に描かれる範囲」(縁・文字・画像を含む。キャンバスからはみ出した分も含む)。世界座標の整数矩形 [x0,y0,x1,y1](x1,y1は含まない)。何も描かれていなければ null。
   1) 図形ごとの外接矩形+縁の余白で広めの範囲を出す 2) その範囲だけ実際に描き、alpha>0のピクセルがある範囲に絞る(縁の角・丸め・回転・反転も正確) */
let VBS=null;
function vgeo(s){/* 図形ローカル座標での外接矩形(縁なし) */
if(s.t=='img'||s.t=='txt')return[-s.w/2,-s.h/2,s.w/2,s.h/2];
try{if(!VBS){VBS=document.createElementNS('http://www.w3.org/2000/svg','svg');VBS.setAttribute('style','position:absolute;width:0;height:0;overflow:hidden;visibility:hidden;pointer-events:none');VBS.setAttribute('aria-hidden','true');VBS.appendChild(document.createElementNS('http://www.w3.org/2000/svg','path'));document.body.appendChild(VBS)}
const p=VBS.firstChild;p.setAttribute('d',dOf(s));const q=p.getBBox();
if(q.width||q.height){const kx=s.t=='pd'&&s.w0?s.w/s.w0:1,ky=s.t=='pd'&&s.h0?s.h/s.h0:1,a=q.x*kx,b=q.y*ky,e=(q.x+q.width)*kx,f=(q.y+q.height)*ky;return[Math.min(a,e),Math.min(b,f),Math.max(a,e),Math.max(b,f)]}}catch(e){}
return[-s.w/2,-s.h/2,s.w/2,s.h/2]}
function vecShown(s){return !s.hid&&(s.t!='img'||(s.im&&s.im.complete))}
function vecBBox(c){const L=c.sh.filter(vecShown);if(!L.length)return null;
let X0=1e9,Y0=1e9,X1=-1e9,Y1=-1e9;
for(const s of L){const q=vgeo(s),sw=s.t=='img'||!s.s?0:(+s.sw||0),m=sw*(s.sj=='miter'?5:.5)+(s.t=='txt'?(+s.fs||0)*.5:0)+2,co=Math.cos(s.r||0),si=Math.sin(s.r||0);
for(const[px0,py] of[[q[0]-m,q[1]-m],[q[2]+m,q[1]-m],[q[0]-m,q[3]+m],[q[2]+m,q[3]+m]]){const px=s.mx?-px0:px0,wx=s.x+px*co-py*si,wy=s.y+px*si+py*co;X0=Math.min(X0,wx);X1=Math.max(X1,wx);Y0=Math.min(Y0,wy);Y1=Math.max(Y1,wy)}}
const W0=X1-X0,H0=Y1-Y0;if(!isFinite(W0+H0)||!(W0>0&&H0>0))return null;
const k=Math.min(1,2048/Math.max(W0,H0)),ox=Math.floor(X0),oy=Math.floor(Y0),o=document.createElement('canvas');o.width=Math.max(1,Math.ceil((X1-ox)*k));o.height=Math.max(1,Math.ceil((Y1-oy)*k));
const x=o.getContext('2d',{willReadFrequently:true});x.setTransform(k,0,0,k,-ox*k,-oy*k);L.forEach(s=>dsh(x,s));
const bb=bmBBox(o);if(!bb)return null;return[Math.floor(ox+bb[0]/k),Math.floor(oy+bb[1]/k),Math.ceil(ox+bb[2]/k),Math.ceil(oy+bb[3]/k)]}
// 一覧のサムネイル用。編集中のコスチュームは毎回計算(選択中の持ち上げも含む)、それ以外は結果を使い回す(画像が未読込の間は使い回さない)
function thumbBox(c){if(c.k=='v'){if(c===C())return vecBBox(c);if(c._bb===undefined){const r=vecBBox(c);if(c.sh.some(s=>s.t=='img'&&!s.hid&&!(s.im&&s.im.complete)))return r;c._bb=r}return c._bb}
if(c.k!='b')return null;if(c===C()){const o=document.createElement('canvas');o.width=c.w;o.height=c.h;dc(o.getContext('2d'),c);return bmBBox(o)}if(c._bb===undefined)c._bb=bmBBox(c.bc);return c._bb}
function drawThumb(t){const c=cs[t._ix];if(!c)return;t._st=0;const x=t.getContext('2d');x.clearRect(0,0,72,54);const bb=thumbBox(c),bx=bb?bb[0]:0,by=bb?bb[1]:0,bw=bb?bb[2]-bb[0]:c.w,bh=bb?bb[3]-bb[1]:c.h,k=Math.min(72/bw,54/bh);x.save();x.imageSmoothingEnabled=!(bb&&k>=1&&c.k=='b');x.translate((72-bw*k)/2,(54-bh*k)/2);x.scale(k,k);x.translate(-bx,-by);dc(x,c);x.restore()}
// thumbs(): 既定は編集中の1枚だけ更新。thumbs(true)は全コスチューム(見えているものだけ即時、残りはスクロールで表示された時に描画)
function markDup(){const L=document.getElementById('list');if(!L)return;cfLayout();const cnt={};cs.forEach(c=>cnt[c.n]=(cnt[c.n]||0)+1);CIS().forEach((d,i)=>{const c=cs[i],f=!!c&&cnt[c.n]>1;d.classList.toggle('dupn',f);if(f)d.setAttribute('data-dup','同じ名前のコスチュームがあります');else d.removeAttribute('data-dup')})}
function thumbs(all){markDup();spThumbCur();document.querySelectorAll('#list canvas').forEach((t,i)=>{t._ix=i;if(all||i==ci){t._st=1;if(!TIO||VIS.has(t))drawThumb(t)}})}
function thumbAt(c){const i=cs.indexOf(c),t=i<0?null:CIS()[i]&&CIS()[i].querySelector('canvas');if(!t)return;t._ix=i;t._st=1;if(!TIO||VIS.has(t))drawThumb(t)}
function go(i){if(TE)teEnd();pvClear();ONG++;if(cs[ci]&&cs[ci].k=='b')bcommit();ci=i;sel=[];selPt=-1;tmp=null;const T=C().k=='v'?TV:TB;if(!T.includes(tool))tool=C().k=='v'?'sel':'brush';tools();if(list.n===cs.length&&!list.force&&CIS().length==cs.length)listSel();else{list.force=0;list()}sync();const c=C();cs[ci]._fu=null;cs[ci]._bb=undefined;{const nr=RS(c),pr=go.rs||nr;if(go.v&&pr!=nr)z=Math.min(32,Math.max(.1,z*pr/nr));go.rs=nr}if(!go.v||ox+c.w*z<20||oy+c.h*z<20||ox>cv.clientWidth-20||oy>cv.clientHeight-20){go.v=1;fit()}else draw()}
function add(k){const c=mk(k,'コスチューム'+(cs.length+1));cs.splice(ci+1,0,c);go(ci+1)}
function grow(c,W,H){if(c.k=='v'||W<=c.w&&H<=c.h)return;W=Math.max(W,c.w);H=Math.max(H,c.h);if(c.k=='b'){const o=document.createElement('canvas');o.width=c.w;o.height=c.h;o.getContext('2d').drawImage(c.bc,0,0);c.bc.width=W;c.bc.height=H;c.bc.getContext('2d').drawImage(o,0,0)}c.w=W;c.h=H}
$('#addv').onclick=()=>add('v');$('#addb').onclick=()=>add('b');
$('#undo').onclick=undo;$('#redo').onclick=redo;
$('#zi').onclick=()=>zoomAt(cv.clientWidth/2,cv.clientHeight/2,z*1.1);$('#zo').onclick=()=>zoomAt(cv.clientWidth/2,cv.clientHeight/2,z/1.1);$('#zf').onclick=fit;$('#z1').onclick=()=>zoomAt(cv.clientWidth/2,cv.clientHeight/2,1/RS(C()));
$('#mu').onclick=()=>{multi=!multi;sync()};
const ord=f=>{const c=C();if(!sel.length)return;hist();const a=c.sh.filter(s=>!sel.includes(s)),b=c.sh.filter(s=>sel.includes(s));c.sh=f?a.concat(b):b.concat(a);fin()};
$('#fr').onclick=()=>ord(1);$('#bkb').onclick=()=>ord(0);
$('#dp').onclick=()=>{const c=C();if(!sel.length)return;hist();const n=sel.map(s=>{const q=JSON.parse(JSON.stringify(s,rep));q.x+=12;q.y+=12;if(q.g)q.g+=100;if(q.t=='img')ld(q);return q});c.sh.push(...n);sel=n;fin()};
$('#dl').onclick=()=>{const c=C();if(!sel.length)return;hist();c.sh=c.sh.filter(s=>!sel.includes(s)||s.lk);sel=[];fin()};
$('#gp').onclick=()=>{if(sel.length<2)return;hist();const i=++gid+Date.now();sel.forEach(s=>s.g=i);fin()};
$('#ug').onclick=()=>{if(!sel.length)return;hist();sel.forEach(s=>delete s.g);fin()};
$('#te').onclick=()=>{const s=sel[0];if(!s||s.t!='txt')return;teStart(s)};
['merge:bmg','mask:bmk','sub:bsb','filter:bft'].forEach(x=>{const[o,i]=x.split(':');$('#'+i).onclick=()=>bool(o)});
$('#al').onchange=e=>{const m=e.target.value;e.target.value='';const c=C();if(!m||!sel.length)return;hist();
const X=s=>[(Math.abs(s.w*Math.cos(s.r))+Math.abs(s.h*Math.sin(s.r)))/2,(Math.abs(s.w*Math.sin(s.r))+Math.abs(s.h*Math.cos(s.r)))/2];
let L,R,T,B;if(sel.length==1){L=0;T=0;R=c.w;B=c.h}else{L=Math.min(...sel.map(s=>s.x-X(s)[0]));R=Math.max(...sel.map(s=>s.x+X(s)[0]));T=Math.min(...sel.map(s=>s.y-X(s)[1]));B=Math.max(...sel.map(s=>s.y+X(s)[1]))}
sel.forEach(s=>{const[a,b]=X(s);if(m=='l')s.x=L+a;if(m=='c')s.x=(L+R)/2;if(m=='r')s.x=R-a;if(m=='t')s.y=T+b;if(m=='m')s.y=(T+B)/2;if(m=='b')s.y=B-b});fin()};
$('#impb').onclick=()=>$('#imp').click();
$('#imp').onchange=e=>{const f=e.target.files[0];if(!f)return;if(f.type=='image/png'&&C().k=='v'&&!e.__s){pngDlg(f);e.target.value='';return}const r=new FileReader();r.onload=()=>{const im=new Image;im.onload=()=>{const c=C();hist();grow(c,im.naturalWidth,im.naturalHeight);
if(c.k=='b')c.bc.getContext('2d').drawImage(im,Math.round((c.w-im.naturalWidth)/2),Math.round((c.h-im.naturalHeight)/2));
else{const s={t:'img',x:c.w/2,y:c.h/2,r:0,w:im.naturalWidth,h:im.naturalHeight,src:r.result};ld(s);c.sh.push(s);sel=[s]}fin()};im.src=r.result};r.readAsDataURL(f);e.target.value=''};
// ===== 保存・出力 =====
const serC=c=>({n:c.n,k:c.k,w:c.w,h:c.h,cx:c.cx,cy:c.cy,res:RS(c),sh:c.sh,bm:c.k=='b'?(c===C()?flatURL(c):(c._fu||(c._fu=flatURL(c)))):0});
/* v4: 複数スプライト(sp)。noSnd=1 のときはサウンドファイルを含めない(自動バックアップ用。読み込み時にファイルが無いサウンドは外す) */
function ser(noSnd){spSave();return JSON.stringify({v:4,ci,fonts,pal,cur:curState(),spi:SPI,prj:PRJ,sp:SPS.map(s=>({n:s.n,st:s.stage?1:0,ci:s.ci,ex:s.ex,snd:noSnd?{}:Object.fromEntries(Object.entries(s.snd||{}).map(([k,v])=>[k,u2b(v)])),cs:s.cs.map(serC)}))},rep)}
/* ===== 読み込み進捗オーバーレイ / 時間分割 ===== */
const PG={el:null};
function progBegin(msg){if(PG.el)return progSet(0,msg);const e=document.createElement('div');e.id='pgov';e.setAttribute('role','alertdialog');e.setAttribute('aria-live','polite');
e.style.cssText='position:fixed;inset:0;z-index:99999;background:rgba(20,24,40,.45);display:flex;align-items:center;justify-content:center;touch-action:none';
e.innerHTML='<div style="background:#fff;color:#222;border-radius:14px;padding:18px 22px;width:min(340px,86vw);box-shadow:0 8px 30px rgba(0,0,0,.35);font-size:14px"><div id="pgt" style="font-weight:600;margin-bottom:10px;word-break:break-all"></div><div style="height:12px;background:#e4e8f0;border-radius:6px;overflow:hidden"><div id="pgb" style="height:100%;width:0;background:#855cd6;transition:width .12s"></div></div><div id="pgp" style="margin-top:8px;text-align:right;font-variant-numeric:tabular-nums"></div></div>';
document.body.append(e);PG.el=e;progSet(0,msg)}
function progSet(v,msg){if(!PG.el)return;v=Math.max(0,Math.min(1,v));PG.el.querySelector('#pgt').textContent=msg||'';PG.el.querySelector('#pgb').style.width=(v*100).toFixed(1)+'%';PG.el.querySelector('#pgp').textContent=Math.round(v*100)+'%'}
function progEnd(){if(PG.el){PG.el.remove();PG.el=null}}
const yieldUI=()=>new Promise(r=>setTimeout(r,0));let SL_T0=0;
async function slice(){if(performance.now()-SL_T0>14){await yieldUI();SL_T0=performance.now()}}
let LOADING=0;
async function loadAsync(t){if(LOADING)return;LOADING=1;progBegin('ファイルを解析中…');
try{await yieldUI();const o=JSON.parse(t);const src=Array.isArray(o.sp)&&o.sp.length?o.sp:(Array.isArray(o.cs)&&o.cs.length?[{n:'スプライト1',ci:o.ci,cs:o.cs}]:null);if(!src||src.some(s=>!Array.isArray(s.cs)||!s.cs.length))throw Error('コスチュームがありません');
FL=baseFL();fonts=o.fonts||[];fillFonts();if(o.pal){pal=o.pal;savePal()}
const N=src.reduce((a,s)=>a+s.cs.length,0),outS=[];let K=0;
for(const sq of src){const out=[];for(const q of sq.cs){progSet(K/N,'コスチュームを読み込み中 '+(K+1)+' / '+N);K++;await slice();
const c=mk(q.k,q.n);Object.assign(c,{w:q.w,h:q.h,cx:q.cx,cy:q.cy,sh:q.sh||[],res:+q.res>0?+q.res:1});c.sh.forEach(s=>s.src&&ld(s));
if(q.k=='b'){c.bc.width=q.w;c.bc.height=q.h;if(q.bm){await new Promise(r=>{const im=new Image;im.onload=()=>{try{c.bc.getContext('2d').drawImage(im,0,0)}catch(e){}r()};im.onerror=()=>r();im.src=q.bm});c._fu=q.bm}}
out.push(c)}
const snd={};if(sq.snd)for(const k in sq.snd){try{snd[k]=b2u(sq.snd[k])}catch(e){}}
const ex=sq.ex&&typeof sq.ex=='object'?sq.ex:(sq.st?STD():SPD());if(Array.isArray(ex.sounds))ex.sounds=ex.sounds.filter(x=>snd[x.md5ext]);
outS.push({n:sq.st?'Stage':String(sq.n||'スプライト'),cs:out,ci:Math.min(Math.max(0,sq.ci|0),out.length-1),ex,snd,stage:!!sq.st})}
progSet(1,'仕上げ中…');await yieldUI();
if(TE)teEnd();bcommit();sel=[];selPt=-1;
PRJ=o.prj&&typeof o.prj=='object'?{monitors:o.prj.monitors||[],extensions:o.prj.extensions||[]}:{monitors:[],extensions:[]};
SPS=outS;SPI=Math.min(Math.max(0,o.spi|0),SPS.length-1);cs=SPS[SPI].cs;list.force=1;go(Math.min(SPS[SPI].ci,cs.length-1));fit();fonts.forEach(regFont);if(o.cur)applyCur(o.cur);sync();spUI()}
finally{LOADING=0;progEnd()}}
function load(t){return loadAsync(t).catch(x=>{alert('読み込みに失敗しました')})}
function dl(b,n){const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=n;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),5000)}
$('#sv').onclick=()=>dl(new Blob([ser()],{type:'application/json'}),'costumes.costume');
$('#ld').onclick=()=>$('#lf').click();$('#lf').onchange=e=>{const f=e.target.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{try{load(r.result)}catch(x){alert('読み込みに失敗しました')}};r.readAsText(f);e.target.value=''};
$('#bk').onclick=()=>{const t=localStorage.getItem('ced_bk');if(!t)return alert('バックアップがありません');if(confirm('自動バックアップを復元しますか?(現在の内容は置き換わります)'))load(t)};
/* 書き出し: ビットマップはPNG、ベクターはSVG */
/* 書き出し(1枚ずつ)。サイズを選べる: 今のキャンバスサイズ / 画像サイズ(描かれている範囲ぴったり。ベクターは縁を含み、キャンバスからはみ出した分も含む) */
async function exportCostume(c){c=c||C();const m=await uiDlg('書き出すサイズを選んでください',[{t:'キャンセル',v:null},{t:'今のキャンバスサイズ',v:'canvas'},{t:'画像サイズ(図形ぴったり)',v:'fit'}],{esc:null,focus:1});if(!m||cs.indexOf(c)<0)return;
if(c.k=='b'){let o=document.createElement('canvas');o.width=c.w;o.height=c.h;dc(o.getContext('2d'),c);
if(m=='fit'){const bb=bmBBox(o);if(bb){const q=document.createElement('canvas');q.width=bb[2]-bb[0];q.height=bb[3]-bb[1];q.getContext('2d').drawImage(o,-bb[0],-bb[1]);o=q}}
o.toBlob(b=>{if(b)dl(b,c.n+'.png')})}
else dl(new Blob([svg(c,m=='fit'?vecBBox(c):null)],{type:'image/svg+xml'}),c.n+'.svg')}
$('#expb').onclick=()=>exportCostume();
const ca=(a,c)=>{if(!c)return`${a}="none"`;const q=typeof c=='string'&&parseC(c);return q&&q.a<.999?`${a}="#${h2(q.r)}${h2(q.g)}${h2(q.b)}" ${a}-opacity="${+q.a.toFixed(3)}"`:`${a}="${c}"`};
const stp=(c,o)=>{const q=parseC(c)||{r:0,g:0,b:0,a:1};return`<stop offset="${o}" stop-color="#${h2(q.r)}${h2(q.g)}${h2(q.b)}" stop-opacity="${+q.a.toFixed(3)}"/>`};
function svg(c,bb){const df=[],ox=bb?bb[0]:0,oy=bb?bb[1]:0,SW=bb?bb[2]-bb[0]:c.w,SH=bb?bb[3]-bb[1]:c.h,nx=v=>bb?+(v-ox).toFixed(4):v,ny=v=>bb?+(v-oy).toFixed(4):v;const fl=(s,f)=>{if(!f)return'none';if(typeof f=='string')return f;const id='g'+df.length,w=(s.t=='pd'?s.w0:s.w)/2,h=(s.t=='pd'?s.h0:s.h)/2,st=stp(f.c1,0)+stp(f.c2,1);
df.push(f.g=='r'?`<radialGradient id="${id}" gradientUnits="userSpaceOnUse" cx="0" cy="0" r="${Math.hypot(w,h)}">${st}</radialGradient>`:`<linearGradient id="${id}" gradientUnits="userSpaceOnUse" x1="${f.g=='h'?-w:0}" y1="${f.g=='v'?-h:0}" x2="${f.g=='h'?w:0}" y2="${f.g=='v'?h:0}">${st}</linearGradient>`);return`url(#${id})`};
let b='';if(c.k=='b')b=`<image href="${flatURL(c)}" width="${c.w}" height="${c.h}"/>`;else c.sh.forEach(s=>{if(s.hid)return;const t=`transform="translate(${nx(s.x)} ${ny(s.y)}) rotate(${s.r*180/Math.PI})${s.mx?' scale(-1 1)':''}"`;
if(s.t=='img')b+=`<image ${t} href="${s.src}" x="${-s.w/2}" y="${-s.h/2}" width="${s.w}" height="${s.h}"/>`;
else if(s.t=='txt')b+=`<text ${t} font-family="${esc(s.fn||'sans-serif')}" font-size="${s.fs}" text-anchor="middle" dominant-baseline="central" ${ca('fill',fl(s,s.f))} ${ca('stroke',s.s)} stroke-width="${s.sw}" stroke-linejoin="${jn(s)}" stroke-miterlimit="10">${esc(s.tx)}</text>`;
else{const pd=s.t=='pd';b+=`<path transform="translate(${nx(s.x)} ${ny(s.y)}) rotate(${s.r*180/Math.PI})${pd?` scale(${s.w/s.w0} ${s.h/s.h0})`:''}"${pd?' vector-effect="non-scaling-stroke"':''} d="${dOf(s)}" ${ca('fill',fl(s,s.f))} fill-rule="${s.fr||'evenodd'}" ${ca('stroke',s.s)} stroke-width="${s.sw}" stroke-linecap="round" stroke-linejoin="${jn(s)}" stroke-miterlimit="10"/>`}});
const ff=fonts.filter(f=>f.data).map(f=>`@font-face{font-family:"${f.n}";src:url(${f.data})}`).join(''),dd=df.join('')+(ff?`<style>${ff}</style>`:'');
return`<svg xmlns="http://www.w3.org/2000/svg" width="${SW}" height="${SH}" viewBox="0 0 ${SW} ${SH}">${dd?`<defs>${dd}</defs>`:''}${b}</svg>`}

/* キー処理は拡張ブロックの共通ショートカット管理(SC)に統合 */
addEventListener('resize',draw);new ResizeObserver(draw).observe(cv);
['gs:s','gh:h','gv:v','gr:r'].forEach(x=>{const[i,m]=x.split(':');$('#'+i).onclick=()=>{gm=m;ap();dirty=0;sync()}});
/* 点編集ツールで選択中の点(複数可)を削除。サブパスごとに最小点数(閉じ=3 / 開き=2)を割る場合は何も消さずに知らせる */
function delPts(){const s=sel[0];if(!s||!s.bz||s.lk)return false;const I=selPts().slice().sort((a,b)=>b-a);if(!I.length)return false;
for(const r of rng(s)){const n=I.filter(i=>i>=r[0]&&i<r[1]).length;if(n&&(r[1]-r[0])-n<(r[2]?3:2)){uiAlert('これ以上点を減らせません');return true}}
hist();for(const i of I){const q=s.pts[i];if(q[7]==1){const r=rng(s).find(r=>i>=r[0]&&i<r[1]);if(r&&i+1<r[1])s.pts[i+1][7]=1}s.pts.splice(i,1)}
selPt=-1;SPA.s=null;SPA.a=[];renorm(s);fin();return true}
$('#delpt').onclick=()=>{delPts()};
$('#ptm').onclick=()=>{const s=sel[0];if(!s||!s.bz||selPt<0)return;hist();const q=s.pts[selPt];
if(q[6]){q[2]=q[3]=q[4]=q[5]=0;q[6]=0}else{const R=rng(s).find(r=>selPt>=r[0]&&selPt<r[1]),pv=selPt>R[0]?selPt-1:R[2]?R[1]-1:selPt,nx=selPt<R[1]-1?selPt+1:R[2]?R[0]:selPt,a=s.pts[pv],b=s.pts[nx],dx=(b[0]-a[0])/6,dy=(b[1]-a[1])/6;q[2]=-dx;q[3]=-dy;q[4]=dx;q[5]=dy;q[6]=1}fin()};
/* ===== ベクター図形の左右/上下反転(選択中の図形全体の中心を軸にする) =====
   反転 = 位置を軸に対して折り返し + 回転を符号反転 + 図形内部を左右反転(rect/ellは左右対称なのでそのまま)。
   上下反転は「回転πを足した左右反転」と等価。文字・画像は内部反転フラグ mx、パスは座標を直接反転する */
function mirrorD(d){const T=d.match(/[a-zA-Z]|[-+]?(?:\d*\.\d+|\d+\.?)(?:e[-+]?\d+)?/g)||[],cnt={M:2,L:2,T:2,H:1,V:1,C:6,S:4,Q:4,A:7},o=[];let i=0,cmd='';
while(i<T.length){if(/[a-zA-Z]/.test(T[i])){cmd=T[i++];o.push(cmd);continue}const K=cmd.toUpperCase(),n=cnt[K];if(!n){i++;continue}const v=[];for(let k=0;k<n&&i<T.length;k++)v.push(parseFloat(T[i++]));
if(K=='H')v[0]=-v[0];else if(K=='A'){v[2]=-v[2];v[4]=1-v[4];v[5]=-v[5]}else if(K!='V')for(let k=0;k<v.length;k+=2)v[k]=-v[k];o.push(v.join(' '))}
return o.join(' ')}
function flipLocalX(s){if(s.t=='txt'||s.t=='img'){s.mx=!s.mx;return}
if(s.t=='pd'&&s.d)s.d=mirrorD(s.d);else if(s.pts)s.pts=s.pts.map(q=>{const r=q.slice();r[0]=-r[0];if(r.length>2){r[2]=-r[2];r[4]=-r[4]}return r});
if(s.f&&typeof s.f=='object'&&s.f.g=='h')s.f={...s.f,c1:s.f.c2,c2:s.f.c1}}
function flipSel(dir){const L=sel.filter(s=>s&&s.t!='bs'&&!s.lk);if(!L.length)return;const[a,b,e,f]=ubox(L),cx=(a+e)/2,cy=(b+f)/2,wr=r=>((r+Math.PI)%(2*Math.PI)+2*Math.PI)%(2*Math.PI)-Math.PI;hist();
L.forEach(s=>{if(dir=='h'){s.x=2*cx-s.x;s.r=-s.r}else{s.y=2*cy-s.y;s.r=Math.PI-s.r}flipLocalX(s);s.r=wr(s.r)});fin()}
const bsl=()=>sel[0]&&sel[0].t=='bs'?sel[0]:null;
$('#bcp').onclick=()=>{const b=bsl();if(b&&bsPx(b)>0){clip=bake(b);clip.pi=[b.x,b.y,RS(C())];sync()}};
$('#bdel').onclick=()=>{const b=bsl();if(!b)return;if(!b.cvs){hist();const[X,Y,w,h]=b.src;C().bc.getContext('2d').clearRect(X,Y,w,h)}sel=[];fin()};
$('#bct').onclick=()=>{if(bsl()){$('#bcp').click();$('#bdel').click()}};
$('#bps').onclick=()=>{if(!clip)return;const c=C();bcommit();hist();const o=document.createElement('canvas');o.width=clip.width;o.height=clip.height;o.getContext('2d').drawImage(clip,0,0);const pi=clip.pi||[c.w/2,c.h/2,RS(c)],k=RS(c)/pi[2];let bw=o.width,bh=o.height,bx=pi[0],by=pi[1];if(k!=1){bw=Math.max(1,Math.round(bw*k));bh=Math.max(1,Math.round(bh*k));bx=Math.round(pi[0]*k-bw/2)+bw/2;by=Math.round(pi[1]*k-bh/2)+bh/2}sel=[{t:'bs',x:bx,y:by,r:0,w:bw,h:bh,src:[0,0,0,0],cvs:o,px:opaqueN(o)}];tool='bsel';tools();fin()};
$('#bfh').onclick=()=>{if(C().k=='v'){flipSel('h');return}const b=bsl();if(!b||bsPx(b)==0)return;pre();b.fx=-(b.fx||1);draw();thumbs()};
$('#bfv').onclick=()=>{if(C().k=='v'){flipSel('v');return}const b=bsl();if(!b||bsPx(b)==0)return;pre();b.fy=-(b.fy||1);draw();thumbs()};

// ===== 独自カラーピッカー =====
const CA={fc:1,fc2:1,sc:1},h2=n=>Math.round(n).toString(16).padStart(2,'0'),clamp=(v,a,b)=>Math.min(b,Math.max(a,v));let pickMode=null;
function parseC(str){str=String(str||'').trim();let m;if(m=str.match(/^#([0-9a-f]{3,8})$/i)){let h=m[1];if(h.length==3||h.length==4)h=[...h].map(c=>c+c).join('');if(h.length==6)h+='ff';if(h.length!=8)return null;return{r:parseInt(h.slice(0,2),16),g:parseInt(h.slice(2,4),16),b:parseInt(h.slice(4,6),16),a:parseInt(h.slice(6,8),16)/255}}
if(m=str.match(/^rgba?\(\s*([\d.]+)[\s,]+([\d.]+)[\s,]+([\d.]+)(?:[\s,/]+([\d.]+%?))?\s*\)$/i)){const a=m[4]==null?1:m[4].endsWith('%')?parseFloat(m[4])/100:parseFloat(m[4]);return{r:clamp(Math.round(+m[1]),0,255),g:clamp(Math.round(+m[2]),0,255),b:clamp(Math.round(+m[3]),0,255),a:clamp(a,0,1)}}return null}
const toStr=c=>c.a>=.999?'#'+h2(c.r)+h2(c.g)+h2(c.b):`rgba(${Math.round(c.r)},${Math.round(c.g)},${Math.round(c.b)},${+(+c.a).toFixed(3)})`;
function getC(id){const c=parseC($('#'+id).value)||{r:0,g:0,b:0,a:1};c.a=CA[id];return c}
const col=id=>toStr(getC(id));
function setCol(id,str,quiet){const c=parseC(str);if(!c)return;$('#'+id).value='#'+h2(c.r)+h2(c.g)+h2(c.b);CA[id]=+c.a.toFixed(3);refChips();if(CP.open&&CP.t==id&&!quiet){cpLoad(id,true);cpPaint()}}
function refChips(){const cc=C();[['cf','fc'],['cs','sc'],['c2','fc2']].forEach(([b,id])=>{const e=$('#'+b);let ch=e.querySelector('.chip');if(!ch){e.insertAdjacentHTML('beforeend','<i class="chip ck"></i>');ch=e.querySelector('.chip')}ch.style.setProperty('--c',col(id));e.classList.toggle('cur',CP.t==id);ch.classList.toggle('none',(id=='fc'&&!$('#fo').checked)||(id=='sc'&&!$('#so').checked&&!!cc&&cc.k=='v'))});if(CP.open)cpTargets()}
const savePal=()=>{try{localStorage.setItem('ced_pal',JSON.stringify(pal))}catch(e){}};
const curState=()=>({fc:col('fc'),fc2:col('fc2'),sc:col('sc'),fo:$('#fo').checked,so:$('#so').checked,gm,aa:$('#aa').checked,penK,sw:swNum(),sj:SJ});
function applyCur(c){setCol('fc',c.fc);setCol('fc2',c.fc2);SJ=c.sj=='miter'?'miter':'round';setCol('sc',c.sc);$('#fo').checked=c.fo;$('#so').checked=c.so;gm=c.gm||'s';$('#aa').checked=c.aa!==false;penK=c.penK||'round';$('#sw').value=c.sw!=null?c.sw:4;swLast=+$('#sw').value;buildPK();refChips()}
const CP={open:0,t:'fc',h:0,s:0,v:1,a:1,old:'#000',del:0,anchor:null};
function rgb2hsv(r,g,b){r/=255;g/=255;b/=255;const M=Math.max(r,g,b),m=Math.min(r,g,b),d=M-m;let h=0;if(d){h=M==r?((g-b)/d)%6:M==g?(b-r)/d+2:(r-g)/d+4;h*=60;if(h<0)h+=360}return{h,s:M?d/M:0,v:M}}
function hsv2rgb(h,s,v){const c=v*s,x=c*(1-Math.abs((h/60)%2-1)),m=v-c;const[r,g,b]=h<60?[c,x,0]:h<120?[x,c,0]:h<180?[0,c,x]:h<240?[0,x,c]:h<300?[x,0,c]:[c,0,x];return{r:Math.round((r+m)*255),g:Math.round((g+m)*255),b:Math.round((b+m)*255)}}
const cpCur=()=>{const c=hsv2rgb(CP.h,CP.s,CP.v);c.a=CP.a;return c};
function cpLoad(t,keepOld){CP.t=t;const c=getC(t),o=rgb2hsv(c.r,c.g,c.b);if(o.s>0)CP.h=o.h;CP.s=o.s;CP.v=o.v;CP.a=c.a;if(!keepOld)CP.old=toStr(c)}
function cpField(){const e=$('#cp_sv'),x=e.getContext('2d'),W=e.width,H=e.height;x.fillStyle=`hsl(${CP.h},100%,50%)`;x.fillRect(0,0,W,H);let g1=x.createLinearGradient(0,0,W,0);g1.addColorStop(0,'#fff');g1.addColorStop(1,'rgba(255,255,255,0)');x.fillStyle=g1;x.fillRect(0,0,W,H);g1=x.createLinearGradient(0,0,0,H);g1.addColorStop(0,'rgba(0,0,0,0)');g1.addColorStop(1,'#000');x.fillStyle=g1;x.fillRect(0,0,W,H)}
function cpPaint(skip){if(!CP.open)return;const c=cpCur(),st=toStr(c),hx='#'+h2(c.r)+h2(c.g)+h2(c.b);cpField();
$('#cp_svt').style.cssText=`left:${CP.s*100}%;top:${(1-CP.v)*100}%;background:${hx}`;
$('#cp_h i').style.cssText=`left:${CP.h/360*100}%;background:hsl(${CP.h},100%,50%)`;
$('#cp_a b').style.background=`linear-gradient(to right,rgba(${c.r},${c.g},${c.b},0),${hx})`;$('#cp_a i').style.cssText=`left:${CP.a*100}%;background:${st}`;
$('#cp_new').style.setProperty('--c',st);$('#cp_old').style.setProperty('--c',CP.old);
const sk=Array.isArray(skip)?skip:[],put=(i,v)=>{if(!sk.includes(i))$('#'+i).value=v};put('cp_hex',hx);put('cp_r',c.r);put('cp_g',c.g);put('cp_b',c.b);put('cp_al',+c.a.toFixed(3));put('cp_rgba',`rgba(${c.r},${c.g},${c.b},${+c.a.toFixed(3)})`);
const nn=CP.t=='fc'?!$('#fo').checked:CP.t=='sc'?!$('#so').checked:0;$('#cp_none').className=nn?'on':'';$('#cp_none').hidden=!(C().k=='v'&&(CP.t=='fc'||CP.t=='sc'));const tt=CP.t=='fc'?'塗りなし':'線なし';$('#cp_none').title=tt+(nn?'を解除':'にする');$('#cp_none').setAttribute('aria-label',$('#cp_none').title);
cpSel()}
function cpApply(skip){const c=cpCur();setCol(CP.t,toStr(c),true);ap();cpPaint(skip)}
function cpCommit(){const st=toStr(cpCur());pal.recent=[st,...pal.recent.filter(x=>x!=st)].slice(0,14);savePal();cpLists()}
function setHSVfrom(c,keepA){const o=rgb2hsv(c.r,c.g,c.b);if(o.s>0)CP.h=o.h;CP.s=o.s;CP.v=o.v;if(!keepA)CP.a=+c.a.toFixed(3);cpApply();dirty=0;cpCommit()}
function cpSel(){const st=toStr(cpCur());document.querySelectorAll('#cp_rec button,#cp_cus button').forEach(b=>b.classList.toggle('sel',b.title==st))}
function cpLists(){for(const[id,arr]of[['cp_rec',pal.recent],['cp_cus',pal.custom]]){const e=$('#'+id);if(!e)continue;e.innerHTML='';arr.forEach((c,i)=>{const b=document.createElement('button');b.className='ck';b.style.setProperty('--c',c);b.title=c;b.setAttribute('aria-label',(id=='cp_cus'?'マイカラー ':'履歴 ')+c);b.onclick=()=>{if(id=='cp_cus'&&CP.del){pal.custom.splice(i,1);savePal();cpLists();return}setHSVfrom(parseC(c),false)};e.append(b)})}cpSel()}
function cpTargets(){const v=C().k=='v',T=v?[['fc','塗り','fillon'],['sc','線','strokeon']].concat(gm!='s'?[['fc2','2色目','grad2']]:[]):[['sc','ブラシ','brush']];const e=$('#cp_tg');e.innerHTML='';
T.forEach(([id,n,ico])=>{const b=document.createElement('button');setB(b,ico,n+'の色を編集');b.insertAdjacentHTML('beforeend',`<i class="chip ck" style="--c:${col(id)}"></i>`);b.style.flexDirection='row';b.style.gap='4px';b.className=CP.t==id?'on':'';b.onclick=()=>{cpCommit();cpLoad(id);cpTargets();cpPaint()};e.append(b)})}
function cpPos(){const e=$('#cp');if(innerWidth<=700){e.style.left=e.style.top='';return}const r=(CP.anchor||$('#cf')).getBoundingClientRect(),w=e.offsetWidth,h=e.offsetHeight;e.style.left=clamp(r.left,4,innerWidth-w-4)+'px';e.style.top=Math.max(4,r.top-h-6)+'px'}
function openCP(t,btn){CP.open=1;CP.anchor=btn||CP.anchor;$('#cp').hidden=false;cpLoad(t);cpTargets();cpLists();cpPaint();cpPos()}
function closeCP(){if(!CP.open)return;cpCommit();CP.open=0;$('#cp').hidden=true;dirty=0;pickMode=null;$('#cp').classList.remove('hid');pickState()}
[['cf','fc'],['cs','sc'],['c2','fc2']].forEach(([b,id])=>{$('#'+b).onclick=e=>CP.open&&CP.t==id?closeCP():openCP(id,e.currentTarget)});
$('#cp_x').onclick=closeCP;
document.addEventListener('pointerdown',e=>{if(!CP.open||pickMode)return;if(e.target.closest('#cp')||e.target.closest('#cf,#cs,#c2,#undo,#redo'))return;closeCP()},true);
function bindDrag(el,fn){let on=0;const m=e=>{const r=el.getBoundingClientRect();fn(clamp((e.clientX-r.left)/r.width,0,1),clamp((e.clientY-r.top)/r.height,0,1))};
el.addEventListener('pointerdown',e=>{e.preventDefault();el.setPointerCapture(e.pointerId);on=1;m(e)});el.addEventListener('pointermove',e=>{if(on)m(e)});
const end=()=>{if(on){on=0;dirty=0;cpCommit()}};el.addEventListener('pointerup',end);el.addEventListener('pointercancel',end)}
bindDrag($('#cp_svw'),(x,y)=>{CP.s=x;CP.v=1-y;cpApply()});bindDrag($('#cp_h'),x=>{CP.h=x*360;cpApply()});bindDrag($('#cp_a'),x=>{CP.a=Math.round(x*100)/100;cpApply()});
const rgbIn=()=>{const c={r:clamp(Math.round(+$('#cp_r').value||0),0,255),g:clamp(Math.round(+$('#cp_g').value||0),0,255),b:clamp(Math.round(+$('#cp_b').value||0),0,255)},o=rgb2hsv(c.r,c.g,c.b);if(o.s>0)CP.h=o.h;CP.s=o.s;CP.v=o.v;cpApply(['cp_r','cp_g','cp_b'])};
['r','g','b'].forEach(k=>{$('#cp_'+k).addEventListener('input',rgbIn);$('#cp_'+k).addEventListener('change',()=>{dirty=0;cpCommit();cpPaint()})});
$('#cp_al').addEventListener('input',()=>{CP.a=clamp(+$('#cp_al').value||0,0,1);cpApply(['cp_al'])});$('#cp_al').addEventListener('change',()=>{dirty=0;cpCommit();cpPaint()});
$('#cp_hex').addEventListener('change',e=>{let v=e.target.value.trim();if(!v.startsWith('#'))v='#'+v;const c=parseC(v);if(c)setHSVfrom(c,v.length<=7);else cpPaint()});
$('#cp_rgba').addEventListener('change',e=>{const c=parseC(e.target.value);if(c)setHSVfrom(c,false);else cpPaint()});
$('#cp_old').onclick=()=>{const c=parseC(CP.old);if(c)setHSVfrom(c,false)};
$('#cp_tr').onclick=()=>{CP.a=0;cpApply();dirty=0;cpCommit()};
$('#cp_none').onclick=()=>{if(CP.t!='fc'&&CP.t!='sc')return;const el=$(CP.t=='fc'?'#fo':'#so');el.checked=!el.checked;ap();dirty=0;refChips();cpPaint()};
$('#cp_add').onclick=()=>{const c=toStr(cpCur());if(!pal.custom.includes(c)){pal.custom.push(c);if(pal.custom.length>30)pal.custom.shift();savePal()}cpLists()};
$('#cp_del').onclick=()=>{CP.del=!CP.del;$('#cp_del').classList.toggle('on',!!CP.del)};
function pickState(){$('#cp_eye').classList.toggle('on',!!pickMode)}
function startPick(){let t=C().k=='v'?CP.t:'sc';if(t=='fc2'&&gm=='s')t='fc';if(pickMode){pickMode=null;cv.style.cursor='';$('#cp').classList.remove('hid');pickState();return}pickMode=t;CP.t=t;if(CP.open)cpTargets();refChips();$('#cp').classList.add('hid');cv.style.cursor='crosshair';pickState()}
$('#cp_eye').onclick=startPick;
['fo','so'].forEach(i=>$('#'+i).addEventListener('change',()=>{refChips();cpPaint()}));
addEventListener('keydown',e=>{if(e.key=='Escape'){if(pickMode){pickMode=null;cv.style.cursor='';$('#cp').classList.remove('hid');pickState()}else closeCP()}});
addEventListener('resize',cpPos);
function buildPK(){const e=$('#g_pk');e.innerHTML='';PENL.forEach(([k,n])=>{const b=document.createElement('button');setB(b,'pen'+k,n);b.className=k==penK?'on':'';b.onclick=()=>{penK=k;buildPK()};e.append(b)})}
Object.assign(IC,{arrL:'<path d="M19 12H5M11 6l-6 6 6 6"/>',arrR:'<path d="M5 12h14M13 6l6 6-6 6"/>',arrU:'<path d="M12 19V5M6 11l6-6 6 6"/>',arrD:'<path d="M12 5v14M6 13l6 6 6-6"/>'});
$('#aa').addEventListener('change',()=>{draw();thumbs()});
function nudge(dx,dy){const b=bsl();if(!b||bsPx(b)==0)return;pre();b.x=Math.round(b.x-b.w/2)+b.w/2+dx;b.y=Math.round(b.y-b.h/2)+b.h/2+dy;draw();thumbs()}
[['nl',-1,0],['nu',0,-1],['nd',0,1],['nr',1,0]].forEach(([id,dx,dy])=>{const e=$('#'+id);let tm=0,iv=0;const stop=()=>{clearTimeout(tm);clearInterval(iv)};
e.addEventListener('pointerdown',ev=>{ev.preventDefault();stop();nudge(dx,dy);tm=setTimeout(()=>{iv=setInterval(()=>nudge(dx,dy),50)},350)});['pointerup','pointerleave','pointercancel'].forEach(t=>e.addEventListener(t,stop))});
addEventListener('keydown',e=>{if(/INPUT|SELECT|TEXTAREA/.test(e.target.tagName)||!C()||C().k!='b'||!bsl())return;const m={ArrowLeft:[-1,0],ArrowRight:[1,0],ArrowUp:[0,-1],ArrowDown:[0,1]}[e.key];if(!m)return;e.preventDefault();const k=e.shiftKey?10:1;nudge(m[0]*k,m[1]*k)});

// ===== 拡張: 数値指定 / レイヤー / ショートカット / フィルター / SVG / 変換 =====
Object.assign(IC,{layers:'<path d="M12 3l9 5-9 5-9-5z"/><path d="M3 12l9 5 9-5M3 16l9 5 9-5"/>',adj:'<circle cx="12" cy="12" r="8"/><path d="M12 4a8 8 0 010 16z" fill="currentColor"/>',help:'<circle cx="12" cy="12" r="9"/><path d="M9.5 9.5a2.5 2.5 0 114 2c-1 .7-1.5 1.2-1.5 2.5M12 17v.5"/>',eye:'<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',eyeoff:'<path d="M3 3l18 18M6 8c-2 1.5-3 3-4 4 2 4 6 7 10 7 1.3 0 2.5-.3 3.5-.8M10 6a9 9 0 0112 6"/>',lock:'<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 018 0v3"/>',unlock:'<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 017.5-2"/>'});
const MK=/Mac|iPhone|iPad/.test(navigator.platform)?'⌘':'Ctrl',isV=()=>C().k=='v';
// --- C. 数値指定: X/Y=図形の中心(キャンバス左上原点)、幅/高=回転前サイズ、角度=度(内部ラジアン)。複数選択はX/Yのみ(選択範囲の中心)
function ubox(L){let a=1e9,b=1e9,e=-1e9,f=-1e9;L.forEach(s=>{const hx=(Math.abs(s.w*Math.cos(s.r))+Math.abs(s.h*Math.sin(s.r)))/2,hy=(Math.abs(s.w*Math.sin(s.r))+Math.abs(s.h*Math.cos(s.r)))/2;a=Math.min(a,s.x-hx);e=Math.max(e,s.x+hx);b=Math.min(b,s.y-hy);f=Math.max(f,s.y+hy)});return[a,b,e,f]}
const nv=(i,v)=>{const e=$('#'+i);if(e.value!=v)e.value=v};
function numSync(){const c=C(),v=c.k=='v'&&sel.length&&sel[0].t!='bs',one=sel.length==1;['qx','qy','qw','qh','qa'].forEach(i=>$('#'+i).disabled=!v);if(!v){['qx','qy','qw','qh','qa'].forEach(i=>nv(i,''));return}
if(document.activeElement&&document.activeElement.closest&&document.activeElement.closest('#nm'))return;const r=n=>+(+n).toFixed(2);
if(one){$('#qa').placeholder='';const s=vs(sel[0]),d=((s.r*180/Math.PI+180)%360+360)%360-180;nv('qx',r(s.x));nv('qy',r(s.y));nv('qw',r(s.w));nv('qh',r(s.h));nv('qa',r(d))}else{const F=sel.filter(s=>!s.lk),[a,b,e,f]=ubox((F.length?F:sel).map(vs));nv('qx',r((a+e)/2));nv('qy',r((b+f)/2));nv('qw',r(e-a));nv('qh',r(f-b));nv('qa','');$('#qa').placeholder='相対'}}
['qx','qy','qw','qh','qa'].forEach(i=>$('#'+i).addEventListener('change',()=>{const L=sel.filter(s=>!s.lk),v=parseFloat($('#'+i).value);if(!L.length||!isFinite(v))return numSync();hist();
if(i=='qx'||i=='qy'){const[a,b,e,f]=ubox(L),d=v-(i=='qx'?(a+e)/2:(b+f)/2);L.forEach(s=>s[i=='qx'?'x':'y']+=d)}
else if(L.length==1&&L[0]===sel[0]){const s=L[0];if(i=='qa')s.r=v*Math.PI/180;else{const lock=$('#qk').checked||s.t=='txt'||s.t=='img',ar=s.w/s.h;if(i=='qw'){s.w=Math.max(1,v);if(lock)s.h=s.w/ar}else{s.h=Math.max(1,v);if(lock)s.w=s.h*ar}if(s.t=='txt'){s.fs=s.h/1.2;tm(s)}}}
else if(L.length>1)grpNum(i,v,L);
fin();numSync()}));
// 複数選択の数値指定: 幅・高さ=選択範囲全体(回転後の外接矩形)の大きさに合わせて中心を基準に拡大縮小 / 角度=選択範囲の中心まわりの相対回転(度)
// 比率固定ON、または文字・画像・斜めに回転した図形は縦横比を保って拡縮(非固定のとき、それらは編集した軸の倍率で等倍)
function grpNum(i,v,L){const[a,b,e,f]=ubox(L),cx=(a+e)/2,cy=(b+f)/2;
if(i=='qa'){const t=v*Math.PI/180,co=Math.cos(t),si=Math.sin(t);L.forEach(s=>{const dx=s.x-cx,dy=s.y-cy;s.x=cx+dx*co-dy*si;s.y=cy+dx*si+dy*co;s.r+=t});$('#qa').value='';return}
const W=e-a,H=f-b;if(i=='qw'?W<1e-9:H<1e-9)return;let kx=1,ky=1;if(i=='qw')kx=Math.max(1,v)/W;else ky=Math.max(1,v)/H;const ke=i=='qw'?kx:ky;if($('#qk').checked)kx=ky=ke;
L.forEach(s=>{s.x=cx+(s.x-cx)*kx;s.y=cy+(s.y-cy)*ky;const q=s.r/(Math.PI/2),ortho=Math.abs(q-Math.round(q))<1e-6;
if(s.t=='txt'||s.t=='img'||!ortho){s.w=Math.max(1,s.w*ke);s.h=Math.max(1,s.h*ke);if(s.t=='txt'){s.fs=s.fs*ke;tm(s)}}
else{const sw=Math.abs(Math.round(q))%2==1;s.w=Math.max(1,s.w*(sw?ky:kx));s.h=Math.max(1,s.h*(sw?kx:ky))}})}
// --- B. レイヤーパネル
const LN={rect:'長方形',ell:'楕円',line:'線',path:'パス',pd:'図形',txt:'文字',img:'画像'},lname=(s,i)=>s.nm||(LN[s.t]||'図形')+' '+(i+1);let LD=-1;
function lySync(){const c=C();$('#nm_wrap').hidden=$('#ly_wrap').hidden=c.k!='v';if($('#side').hidden||c.k!='v')return;
['dp','dl','gp','ug','fr','bkb'].forEach(i=>$('#ly_'+i).disabled=$('#'+i).disabled);$('#lyn').disabled=!sel.length;$('#lyu').disabled=$('#lyd').disabled=sel.length!=1;
const key=ci+'|'+c.sh.map(s=>[s.nm,s.t,s.hid,s.lk,s.g,sel.includes(s)?1:0]).join('|');if(key==lySync.k)return;lySync.k=key;
const e=$('#ly'),GN=new Map();c.sh.forEach(s=>s.g&&!GN.has(s.g)&&GN.set(s.g,GN.size+1));e.innerHTML='';
for(let i=c.sh.length-1;i>=0;i--){const s=c.sh[i],r=document.createElement('div');r.className='lr'+(sel.includes(s)?' on':'')+(s.hid?' hd':'');r.draggable=true;
r.innerHTML=`<button title="表示/非表示" aria-label="表示/非表示">${ic(s.hid?'eyeoff':'eye',16)}</button><button title="ロック/解除" aria-label="ロック/解除">${ic(s.lk?'lock':'unlock',16)}</button><span>${esc(lname(s,i))}${s.g?' [G'+GN.get(s.g)+']':''}</span>`;
const[b1,b2]=r.querySelectorAll('button');
b1.onclick=ev=>{ev.stopPropagation();hist();s.hid=!s.hid;if(!s.hid)delete s.hid;else sel=sel.filter(q=>q!=s);fin()};
b2.onclick=ev=>{ev.stopPropagation();hist();s.lk=!s.lk;if(!s.lk)delete s.lk;else sel=sel.filter(q=>q!=s);fin()};
r.onclick=ev=>{if(s.hid||s.lk)return;const add=multi||ev.shiftKey||ev.ctrlKey||ev.metaKey,grp=s.g?c.sh.filter(q=>q.g==s.g&&!q.hid&&!q.lk):[s];if(add)grp.every(q=>sel.includes(q))?sel=sel.filter(q=>!grp.includes(q)):sel=[...new Set([...sel,...grp])];else sel=grp;if(tool!='sel'&&tool!='rsh'){tool='sel';tools()}selPt=-1;sync();draw()};
r.ondblclick=()=>{sel=[s];$('#lyn').click()};
r.ondragstart=ev=>{LD=i;ev.dataTransfer.setData('text/plain',String(i))};r.ondragover=ev=>{ev.preventDefault();r.classList.add('dr')};r.ondragleave=()=>r.classList.remove('dr');
r.ondrop=ev=>{ev.preventDefault();r.classList.remove('dr');if(LD<0||LD==i)return;hist();const[m]=c.sh.splice(LD,1);c.sh.splice(i,0,m);LD=-1;fin()};e.append(r)}}
['dp','dl','gp','ug','fr','bkb'].forEach(i=>$('#ly_'+i).onclick=()=>$('#'+i).click());
$('#lyn').onclick=()=>{const s=sel[0];if(!s)return;const n=prompt('レイヤー名',lname(s,C().sh.indexOf(s)));if(n==null)return;hist();sel.length==1?(s.nm=n.trim()||undefined,!s.nm&&delete s.nm):sel.forEach(q=>q.nm=n.trim()||undefined);fin()};
const mvL=d=>{const c=C(),s=sel[0],i=c.sh.indexOf(s),j=i+d;if(sel.length!=1||j<0||j>=c.sh.length)return;hist();c.sh[i]=c.sh[j];c.sh[j]=s;fin()};
$('#lyu').onclick=()=>mvL(1);$('#lyd').onclick=()=>mvL(-1);
$('#tp').onclick=()=>{$('#side').hidden=!$('#side').hidden;lySync.k=0;sync()};
// --- E. 共通ショートカット管理 [キー,Ctrl/Cmd,Shift,説明,処理]。一覧(?)はこの表から自動生成
const tl=(v,b)=>()=>{const t=isV()?v:b;if(!t)return;if(!isV())bcommit();tool=t;selPt=-1;if(!['sel','rsh','bsel'].includes(t))sel=[];tools();sync();draw()};
let vclip=null,VCI=null,LASTCLIP='';const AR={t:0};
function vcopy(){if(sel.length){vclip=JSON.stringify(sel,rep);const c=C();VCI={res:RS(c),w:c.w,h:c.h};LASTCLIP='v'}}
function vpaste(){if(!vclip)return;const c=C(),G={};hist();const n=JSON.parse(vclip).map(q=>{if(q.g)q.g=G[q.g]||(G[q.g]=++gid+Date.now());if(q.src)ld(q);return q});c.sh.push(...n);sel=n;tool='sel';tools();fin()}
function selAll(){const c=C();if(isV()){sel=c.sh.filter(s=>!s.hid&&!s.lk);if(tool!='sel'&&tool!='rsh'){tool='sel';tools()}}else{bcommit();tool='bsel';sel=[{t:'bs',x:c.w/2,y:c.h/2,r:0,w:c.w,h:c.h,src:[0,0,c.w,c.h],cvs:null}];trimSel();tools()}sync();draw()}
const del_=()=>{if(isV()){if(tool=='rsh'&&selPts().length){delPts();return}if(sel.length)$('#dl').onclick()}else $('#bdel').click()};
const SC=[['v',0,0,'選択ツール',tl('sel','bsel')],['a',0,0,'リシェイプ(ベクターのみ)',tl('rsh',0)],['p',0,0,'ペン(ビットマップではブラシ)',tl('pen','brush')],['b',0,0,'ブラシ',tl('brush','brush')],['e',0,0,'消しゴム',tl('eras','eras')],['t',0,0,'文字(ベクターのみ)',tl('txt',0)],
['z',1,0,'元に戻す',undo],['z',1,1,'やり直し',redo],['y',1,0,'やり直し',redo],['Delete',0,0,'削除',del_],['Backspace',0,0,'',del_],
['d',1,0,'複製(ベクター)',()=>isV()&&$('#dp').click()],['a',1,0,'全選択',selAll],['s',1,0,'保存(JSON)',()=>$('#sv').click()],['o',1,0,'読み込み(JSON)',()=>$('#ld').click()],
['c',1,0,'コピー',()=>isV()?vcopy():$('#bcp').click()],['x',1,0,'切り取り',()=>{if(isV()){if(sel.length){vcopy();$('#dl').onclick()}}else $('#bct').click()}],['v',1,0,'貼り付け',()=>isV()?vpaste():$('#bps').click()],
['g',1,0,'グループ化(ベクター)',()=>$('#gp').click()],['g',1,1,'グループ解除(ベクター)',()=>$('#ug').click()],[']',1,0,'前面へ(ベクター)',()=>$('#fr').click()],['[',1,0,'背面へ(ベクター)',()=>$('#bkb').click()],['?',0,1,'ショートカット一覧',()=>help()]];
addEventListener('keydown',e=>{const T=e.target,del=e.key=='Delete'||e.key=='Backspace',typ=(T.type||'').toLowerCase(),txt=T.tagName=='TEXTAREA'||T.tagName=='SELECT'||(T.tagName=='INPUT'&&!['range','checkbox','radio','button','color'].includes(typ));
if(txt||(T.tagName=='INPUT'&&!del)||T.isContentEditable||document.querySelector('.dlg:not(#arrd)')||(CP.open&&(!del||$('#cp').contains(T)))||pickMode||e.altKey||!C())return;
const m=e.ctrlKey||e.metaKey,k=e.key.length==1?e.key.toLowerCase():e.key,h=SC.find(x=>x[0]==k&&!!x[1]==m&&!!x[2]==e.shiftKey);if(h){e.preventDefault();h[4]();return}
if(!m&&k.startsWith('Arrow')&&isV()){const n=e.shiftKey?10:.1,dx={ArrowLeft:-n,ArrowRight:n}[k]||0,dy={ArrowUp:-n,ArrowDown:n}[k]||0,rd=v=>Math.round(v*1e6)/1e6,s0=sel[0],I=tool=='rsh'&&s0&&s0.bz&&!s0.lk?selPts():[];
if(I.length){/* 点編集: 選択中の点(複数可)を移動。1点のときは重なっている他パスの点も一緒に動かす(ドラッグと同じ) */e.preventDefault();const LK=I.length==1?links(s0,I[0]):[],P=I.map(i=>W_(s0,i)),Q=LK.map(([o,j])=>W_(o,j));if(!AR.t)hist();clearTimeout(AR.t);AR.t=setTimeout(()=>AR.t=0,700);
I.forEach((i,j)=>setW(s0,i,rd(P[j][0]+dx),rd(P[j][1]+dy)));LK.forEach(([o,j],q)=>{setW(o,j,rd(Q[q][0]+dx),rd(Q[q][1]+dy));renorm(o)});renorm(s0);fin();return}
const L=sel.filter(s=>!s.lk);if(!L.length)return;e.preventDefault();if(!AR.t)hist();clearTimeout(AR.t);AR.t=setTimeout(()=>AR.t=0,700);L.forEach(s=>{s.x=rd(s.x+dx);s.y=rd(s.y+dy)});fin()}});
addEventListener('keydown',e=>{if(e.key=='Escape'){const d=document.querySelector('.dlg'),b=d&&d.querySelector('[data-x]');b&&b.click()}});
function help(){const D=document.createElement('div');D.className='dlg';D.innerHTML='<div role="dialog" aria-label="ショートカット一覧"><b>ショートカット一覧</b>'+SC.filter(x=>x[3]).map(x=>`<div style="display:flex;justify-content:space-between;gap:16px"><span>${x[3]}</span><kbd>${(x[1]?MK+'+':'')+(x[2]?'Shift+':'')+(x[0].length>1?x[0]:x[0].toUpperCase())}</kbd></div>`).join('')+'<small>矢印キー: 選択図形を0.1px(Shiftで10px)移動。点編集ツールで点を選択中は、その点(複数選択も)を同じ量だけ移動 / ビットマップ選択範囲は従来どおり1px。入力欄・ダイアログ表示中は無効です。</small><button data-x>閉じる</button></div>';D.onclick=e=>{if(e.target==D||e.target.closest('[data-x]'))D.remove()};document.body.append(D)}
$('#hlp').onclick=help;
// --- D. 画像フィルター(ビットマップ全体。プレビューは常に元画像から再計算。適用で1回のUndo履歴)
const FP=[['br','明るさ',-100,100,0],['ct','コントラスト',-100,100,0],['sa','彩度',-100,100,0],['hu','色相',-180,180,0],['bl','ぼかし',0,20,0],['sh','シャープ化',0,100,0]],FC=[['gy','グレースケール'],['sp','セピア'],['iv','ネガポジ反転']];
function bl1(a,t,w,h,r,hz){const L=hz?w:h,M=hz?h:w,sa=hz?4:w*4,sl=hz?w*4:4;for(let m=0;m<M;m++){const b=m*sl;for(let k=0;k<4;k++){let s=0,lo=0,hi=-1;for(let i=0;i<L;i++){const nh=Math.min(L-1,i+r),nl=Math.max(0,i-r);while(hi<nh){hi++;s+=a[b+hi*sa+k]}while(lo<nl){s-=a[b+lo*sa+k];lo++}t[b+i*sa+k]=s/(hi-lo+1)}}}}
function blurData(d,w,h,r){const N=w*h*4,a=new Float32Array(N),t=new Float32Array(N);for(let i=0;i<N;i+=4){const q=d[i+3]/255;a[i]=d[i]*q;a[i+1]=d[i+1]*q;a[i+2]=d[i+2]*q;a[i+3]=d[i+3]}
for(let k=0;k<2;k++){bl1(a,t,w,h,r,1);bl1(t,a,w,h,r,0)}for(let i=0;i<N;i+=4){const q=a[i+3]/255;if(q>0){d[i]=a[i]/q;d[i+1]=a[i+1]/q;d[i+2]=a[i+2]/q}d[i+3]=a[i+3]}}
function filt(src,P){const w=src.width,h=src.height,o=new ImageData(new Uint8ClampedArray(src.data),w,h),d=o.data,L=d.length,a=P.hu*Math.PI/180,co=Math.cos(a),si=Math.sin(a),H=[.213+co*.787-si*.213,.715-co*.715-si*.715,.072-co*.072+si*.928,.213-co*.213+si*.143,.715+co*.285+si*.14,.072-co*.072-si*.283,.213-co*.213-si*.787,.715-co*.715+si*.715,.072+co*.928+si*.072],
sv=1+P.sa/100,br=P.br*2.55,C_=P.ct*2.55,cf=(259*(C_+255))/(255*(259-C_));
for(let i=0;i<L;i+=4){if(!d[i+3])continue;let r=d[i],g=d[i+1],b=d[i+2],y;
if(P.hu){const R=H[0]*r+H[1]*g+H[2]*b,G=H[3]*r+H[4]*g+H[5]*b;b=H[6]*r+H[7]*g+H[8]*b;r=R;g=G}
if(P.sa){y=.299*r+.587*g+.114*b;r=y+(r-y)*sv;g=y+(g-y)*sv;b=y+(b-y)*sv}
if(P.gy){y=.299*r+.587*g+.114*b;r=g=b=y}
if(P.sp){const R=.393*r+.769*g+.189*b,G=.349*r+.686*g+.168*b;b=.272*r+.534*g+.131*b;r=R;g=G}
if(P.br||P.ct){r=(r+br-128)*cf+128;g=(g+br-128)*cf+128;b=(b+br-128)*cf+128}
if(P.iv){r=255-r;g=255-g;b=255-b}d[i]=r;d[i+1]=g;d[i+2]=b}
if(P.bl>0)blurData(d,w,h,Math.max(1,Math.round(P.bl*(P.R||1))));
if(P.sh>0){const c2=new Uint8ClampedArray(d),k=P.sh/50;blurData(c2,w,h,P.R||1);for(let i=0;i<L;i+=4){if(!d[i+3])continue;for(let j=0;j<3;j++)d[i+j]=d[i+j]+k*(d[i+j]-c2[i+j])}}return o}
function openFlt(){const c=C();if(c.k!='b')return alert('画像フィルターはビットマップのコスチューム専用です。ベクター図形には適用できません。');bcommit();if(c.w*c.h>12e6)return alert('画像が大きすぎます(1200万画素まで)');
const x=c.bc.getContext('2d'),org=x.getImageData(0,0,c.w,c.h),P={R:RS(c)},D=document.createElement('div');let tm_=0;D.className='dlg';
D.innerHTML='<div role="dialog" aria-label="画像フィルター"><b>画像フィルター</b>'+FP.map(f=>`<label>${f[1]}<input type="number" data-p="${f[0]}" min="${f[2]}" max="${f[3]}" step="1" value="${f[4]}" inputmode="numeric" data-clamp="1"><output hidden></output></label>`).join('')+FC.map(f=>`<label>${f[1]}<input type="checkbox" data-p="${f[0]}"></label>`).join('')+'<small>プレビューは常に元画像から計算します。「適用」まで確定せず、キャンセルで元に戻ります。透明部分は維持されます。</small><span class="grp"><button data-r>リセット</button><button data-x>キャンセル</button><button data-ok class="on">適用</button></span></div>';
const get=()=>{D.querySelectorAll('[data-p]').forEach(e=>P[e.dataset.p]=e.type=='checkbox'?e.checked:+e.value);D.querySelectorAll('output').forEach(o=>o.textContent=o.previousSibling.value)},
run=()=>{get();clearTimeout(tm_);tm_=setTimeout(()=>{x.putImageData(filt(org,P),0,0);draw()},60)};
D.oninput=run;D.querySelector('[data-x]').onclick=()=>{clearTimeout(tm_);D.remove();x.putImageData(org,0,0);draw();thumbs()};
D.querySelector('[data-r]').onclick=()=>{D.querySelectorAll('[data-p]').forEach(e=>e.type=='checkbox'?e.checked=false:e.value=FP.find(f=>f[0]==e.dataset.p)[4]);run()};
D.querySelector('[data-ok]').onclick=()=>{clearTimeout(tm_);get();const r=filt(org,P);x.putImageData(org,0,0);hist();x.putImageData(r,0,0);D.remove();fin()};document.body.append(D);get()}
$('#flt').onclick=openFlt;
// --- F. ベクター→ビットマップ(等倍。サイズ・中心点・透明度を維持。Undoで形式ごと復元)
$('#v2b').onclick=()=>{const c=C();if(c.k!='v')return alert('このコスチュームはすでにビットマップです。\nビットマップ→ベクターのトレース変換は未実装です。');
if(!confirm('ベクターをビットマップに変換します。\n・変換後は図形単位の編集(移動・変形・点の編集・レイヤー)ができなくなります\n・解像度は現在のコスチュームサイズ(等倍)で、サイズと中心点は維持されます\n・「元に戻す」で変換前に戻せます'))return;
hist();const o=document.createElement('canvas');o.width=c.w;o.height=c.h;rasterVec(o,c.sh,1,0,0);c.bc=o;c.k='b';c.res=1;c.sh=[];sel=[];tmp=null;fin()};
// --- A. SVGをベクター図形へ変換(画像として置くだけの既存「画像を読み込む」とは別機能)
function svgImport(t){const c=C();if(c.k!='v')return alert('ベクターのコスチュームを選択してください');
const doc=new DOMParser().parseFromString(t,'image/svg+xml'),R=doc.documentElement,W=new Set(),out=[];if(R.nodeName!='svg'||doc.querySelector('parsererror'))return alert('SVGとして解析できませんでした');
const num=v=>parseFloat(v)||0,fo=v=>{const q=parseFloat(v);return isFinite(q)?q:1},vb=(R.getAttribute('viewBox')||'').trim().split(/[\s,]+/).map(Number),ok=vb.length==4&&vb.every(isFinite)&&vb[2]>0&&vb[3]>0,
[vx,vy,vw,vh]=ok?vb:[0,0,num(R.getAttribute('width'))||c.w,num(R.getAttribute('height'))||c.h],k=Math.min(c.w/vw,c.h/vh),M0=[k,0,0,k,(c.w-vw*k)/2-vx*k,(c.h-vh*k)/2-vy*k],X=document.createElement('canvas').getContext('2d'),
mul=(a,b)=>[a[0]*b[0]+a[2]*b[1],a[1]*b[0]+a[3]*b[1],a[0]*b[2]+a[2]*b[3],a[1]*b[2]+a[3]*b[3],a[0]*b[4]+a[2]*b[5]+a[4],a[1]*b[4]+a[3]*b[5]+a[5]];
const tf=s=>{let M=[1,0,0,1,0,0];(s||'').replace(/(\w+)\(([^)]*)\)/g,(_,n,a)=>{const v=a.split(/[\s,]+/).filter(Boolean).map(Number);let T=null;
if(n=='translate')T=[1,0,0,1,v[0]||0,v[1]||0];else if(n=='scale')T=[v[0],0,0,v.length>1?v[1]:v[0],0,0];else if(n=='rotate'){const r=(v[0]||0)*Math.PI/180,co=Math.cos(r),si=Math.sin(r);T=[co,si,-si,co,0,0];if(v.length>2)T=mul(mul([1,0,0,1,v[1],v[2]],T),[1,0,0,1,-v[1],-v[2]])}
else if(n=='matrix'&&v.length==6)T=v;else if(n=='skewX')T=[1,0,Math.tan(v[0]*Math.PI/180),1,0,0];else if(n=='skewY')T=[1,Math.tan(v[0]*Math.PI/180),0,1,0,0];else W.add('未対応のtransform: '+n);if(T)M=mul(M,T)});return M};
const cc=v=>{v=(v||'').trim();if(!v||v=='none')return null;const u=v.match(/^url\(\s*['"]?#([^'")]+)/);if(u){const e=doc.getElementById(u[1]),st=e&&e.querySelector('stop');W.add('グラデーション/パターン塗りは単色(最初の色)に置換');return st?cc(st.getAttribute('stop-color')||(st.getAttribute('style')||'').replace(/.*stop-color:\s*([^;]+).*/,'$1')):'#808080'}
if(/^url/.test(v)){W.add('外部参照の塗りは無視');return null}X.fillStyle='#000';X.fillStyle=v==='currentColor'?'#000':v;return X.fillStyle},al=(c,a)=>{if(!c||a>=1)return c;const q=parseC(c);return q?toStr({...q,a:q.a*a}):c};
const sty_=(e,p)=>{const o={...p},g=n=>{const m=(e.getAttribute('style')||'').match(new RegExp('(?:^|;)\\s*'+n+'\\s*:\\s*([^;]+)'));return m?m[1].trim():e.getAttribute(n)};
['fill','stroke','stroke-width','fill-opacity','stroke-opacity','fill-rule','stroke-linejoin'].forEach(n=>{const v=g(n);if(v!=null&&v!=='')o[n]=v});const op=g('opacity');o.op=p.op*(op!=null&&op!==''?fo(op):1);o.disp=g('display')=='none'||g('visibility')=='hidden';return o};
const prim=e=>{const n=e.nodeName,a=x=>num(e.getAttribute(x));
if(n=='rect'){const x=a('x'),y=a('y'),w=a('width'),h=a('height');let rx=a('rx')||a('ry'),ry=a('ry')||rx;rx=Math.min(rx,w/2);ry=Math.min(ry,h/2);if(!(w>0&&h>0))return'';return rx>0?`M${x+rx} ${y}H${x+w-rx}A${rx} ${ry} 0 0 1 ${x+w} ${y+ry}V${y+h-ry}A${rx} ${ry} 0 0 1 ${x+w-rx} ${y+h}H${x+rx}A${rx} ${ry} 0 0 1 ${x} ${y+h-ry}V${y+ry}A${rx} ${ry} 0 0 1 ${x+rx} ${y}z`:`M${x} ${y}h${w}v${h}h${-w}z`}
if(n=='circle'||n=='ellipse'){const cx=a('cx'),cy=a('cy'),rx=n=='circle'?a('r'):a('rx'),ry=n=='circle'?a('r'):a('ry');return rx>0&&ry>0?`M${cx-rx} ${cy}A${rx} ${ry} 0 1 0 ${cx+rx} ${cy}A${rx} ${ry} 0 1 0 ${cx-rx} ${cy}z`:''}
if(n=='line')return`M${a('x1')} ${a('y1')}L${a('x2')} ${a('y2')}`;
if(n=='polygon'||n=='polyline'){const v=(e.getAttribute('points')||'').trim().split(/[\s,]+/).map(Number);if(v.length<4)return'';let d='M'+v[0]+' '+v[1];for(let i=2;i+1<v.length;i+=2)d+='L'+v[i]+' '+v[i+1];return d+(n=='polygon'?'z':'')}
return n=='path'?e.getAttribute('d')||'':''};
const tD=(subs,M,o)=>{const T=(x,y)=>[M[0]*x+M[2]*y+M[4]-o[0],M[1]*x+M[3]*y+M[5]-o[1]];let d='';const P=[];subs.forEach(sb=>{const q=sb.pts,n=q.length,seg=(a,b)=>{const A=q[a],B=q[b],c1=T(A[0]+A[4],A[1]+A[5]),c2=T(B[0]+B[2],B[1]+B[3]),e=T(B[0],B[1]);P.push(c1,c2,e);return`C${c1} ${c2} ${e}`},s0=T(q[0][0],q[0][1]);P.push(s0);d+=`M${s0}`;for(let i=0;i<n-1;i++)d+=seg(i,i+1);if(sb.closed&&n>1)d+=seg(n-1,0)+'z'});return[d,P]};
const UN={text:'テキスト要素',image:'画像要素',use:'use参照',clipPath:'クリップパス',mask:'マスク',filter:'フィルター',foreignObject:'foreignObject',symbol:'symbol',marker:'マーカー'},SK=/^(defs|title|desc|metadata|linearGradient|radialGradient|pattern|sodipodi|inkscape)/;
const walk=(e,M,p,gi)=>{for(const ch of e.children){const n=ch.nodeName;if(n=='script'){W.add('script要素は実行せず無視');continue}if(n=='style'){W.add('<style>のCSSは適用されません(属性指定のみ反映)');continue}if(SK.test(n))continue;if(UN[n]){W.add(UN[n]+'は未対応のため読み込まず');continue}
const s0=sty_(ch,p);if(s0.disp)continue;const T=mul(M,tf(ch.getAttribute('transform')));if(ch.getAttribute('filter')||ch.getAttribute('clip-path')||ch.getAttribute('mask'))W.add('filter/clip-path/mask属性は無視');
if(n=='g'||n=='a'){walk(ch,T,s0,gi||(n=='g'?++gid+Date.now():0));continue}
const d=prim(ch);if(!d){if(!/^(rect|circle|ellipse|line|polygon|polyline|path)$/.test(n))W.add('<'+n+'>は未対応');continue}
const subs=parseD(d);if(!subs.length||!subs[0].pts.length)continue;const[,P0]=tD(subs,T,[0,0]),xs=P0.map(q=>q[0]),ys=P0.map(q=>q[1]),x0=Math.min(...xs),x1=Math.max(...xs),y0=Math.min(...ys),y1=Math.max(...ys),cx=(x0+x1)/2,cy=(y0+y1)/2,[dd]=tD(subs,T,[cx,cy]);
const f=n=='line'?null:cc(s0.fill),st=cc(s0.stroke),sc=Math.sqrt(Math.abs(T[0]*T[3]-T[1]*T[2]));
out.push({t:'pd',d:dd,w0:Math.max(x1-x0,.01),h0:Math.max(y1-y0,.01),w:Math.max(x1-x0,.01),h:Math.max(y1-y0,.01),x:cx,y:cy,r:0,f:al(f,s0.op*fo(s0['fill-opacity'])),s:al(st,s0.op*fo(s0['stroke-opacity'])),sw:Math.max(.1,fo(s0['stroke-width'])*sc),fr:s0['fill-rule']=='evenodd'?'evenodd':'nonzero',...(s0['stroke-linejoin']?{sj:/^(round|bevel)$/.test(s0['stroke-linejoin'])?'round':'miter'}:{}),...(gi?{g:gi}:{}),...(ch.id?{nm:ch.id}:{})})}};
walk(R,M0,{fill:'#000',stroke:'none','stroke-width':'1',op:1,'fill-opacity':'1','stroke-opacity':'1','fill-rule':'nonzero'},0);
const cnt={};out.forEach(s=>s.g&&(cnt[s.g]=(cnt[s.g]||0)+1));out.forEach(s=>{if(s.g&&cnt[s.g]<2)delete s.g});
if(!out.length)return svgImport.q||alert('読み込める図形がありませんでした'+(W.size?'\n\n・'+[...W].join('\n・'):''));
hist();c.sh.push(...out);sel=out;tool='sel';tools();fin();if(W.size&&svgImport.q)svgImport.w.push(...W);else if(W.size)alert('SVGを読み込みました(図形'+out.length+'個)。\n次の項目は未対応・簡略化されました:\n・'+[...W].join('\n・'))}
$('#svi').onclick=()=>$('#svf').click();$('#svf').onchange=e=>{const f=e.target.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{try{svgImport(r.result)}catch(x){alert('SVGの変換に失敗しました: '+x.message)}};r.readAsText(f);e.target.value=''};
$('#side').hidden=innerWidth<900;


Object.assign(IC,{prev:'<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M10 9l5 3-5 3z" fill="currentColor"/>',outline:'<path d="M5 19V6l7 13V6M15 6h5M17.5 6v13" fill="none"/><circle cx="5" cy="6" r="1.6"/><circle cx="12" cy="19" r="1.6"/>',totext:'<path d="M5 5h14M12 5v14M9 19h6"/>',pkgout:'<path d="M4 9l8-5 8 5v10H4z"/><path d="M12 17v-6M9 13l3-3 3 3"/>',pkgin:'<path d="M4 9l8-5 8 5v10H4z"/><path d="M12 10v6M9 14l3 3 3-3"/>',conv:'<rect x="3" y="4" width="8" height="8" rx="1"/><path d="M13 16h8v4h-8zM11 8h4v4M15 8l-4 4"/>',svgin:'<path d="M12 3v11M7 10l5 5 5-5"/><path d="M5 20h14" stroke-dasharray="3 2"/>'});
// ===== .sprite3 入出力(外部ライブラリ不要: MD5・ZIPを内蔵) =====
const te=s=>new TextEncoder().encode(s),td=b=>new TextDecoder().decode(b);
function md5(d){const K=[],S=[7,12,17,22,5,9,14,20,4,11,16,23,6,10,15,21];for(let i=0;i<64;i++)K[i]=Math.floor(Math.abs(Math.sin(i+1))*4294967296)>>>0;
const n=d.length,L=((n+8>>6)+1)<<6,b=new Uint8Array(L);b.set(d);b[n]=128;const v=new DataView(b.buffer);v.setUint32(L-8,n<<3>>>0,true);v.setUint32(L-4,Math.floor(n/536870912),true);
let a0=1732584193,b0=4023233417,c0=2562383102,d0=271733878;
for(let o=0;o<L;o+=64){const M=[];for(let i=0;i<16;i++)M[i]=v.getUint32(o+i*4,true);let A=a0,B=b0,C=c0,D=d0;
for(let i=0;i<64;i++){let F,g;if(i<16){F=(B&C)|(~B&D);g=i}else if(i<32){F=(D&B)|(~D&C);g=(5*i+1)%16}else if(i<48){F=B^C^D;g=(3*i+5)%16}else{F=C^(B|~D);g=7*i%16}
F=(F+A+K[i]+M[g])>>>0;A=D;D=C;C=B;const s=S[(i>>4)*4+(i&3)];B=(B+((F<<s)|(F>>>(32-s))))>>>0}
a0=(a0+A)>>>0;b0=(b0+B)>>>0;c0=(c0+C)>>>0;d0=(d0+D)>>>0}
const o=new DataView(new ArrayBuffer(16));[a0,b0,c0,d0].forEach((x,i)=>o.setUint32(i*4,x,true));return[...new Uint8Array(o.buffer)].map(x=>x.toString(16).padStart(2,'0')).join('')}
const CT=(()=>{const t=[];for(let n=0;n<256;n++){let c=n;for(let k=0;k<8;k++)c=c&1?0xEDB88320^(c>>>1):c>>>1;t[n]=c>>>0}return t})(),crc32=d=>{let c=-1;for(let i=0;i<d.length;i++)c=CT[(c^d[i])&255]^(c>>>8);return(c^-1)>>>0};
function zipMake(F){const ch=[],cd=[];let off=0;F.forEach(([nm,d])=>{const n=te(nm),c=crc32(d),h=new DataView(new ArrayBuffer(30));h.setUint32(0,0x04034b50,true);h.setUint16(4,20,true);h.setUint16(6,0x800,true);h.setUint16(12,0x21,true);h.setUint32(14,c,true);h.setUint32(18,d.length,true);h.setUint32(22,d.length,true);h.setUint16(26,n.length,true);
ch.push(new Uint8Array(h.buffer),n,d);const e=new DataView(new ArrayBuffer(46));e.setUint32(0,0x02014b50,true);e.setUint16(4,20,true);e.setUint16(6,20,true);e.setUint16(8,0x800,true);e.setUint16(14,0x21,true);e.setUint32(16,c,true);e.setUint32(20,d.length,true);e.setUint32(24,d.length,true);e.setUint16(28,n.length,true);e.setUint32(42,off,true);cd.push(new Uint8Array(e.buffer),n);off+=30+n.length+d.length});
const sz=cd.reduce((a,x)=>a+x.length,0),z=new DataView(new ArrayBuffer(22));z.setUint32(0,0x06054b50,true);z.setUint16(8,F.length,true);z.setUint16(10,F.length,true);z.setUint32(12,sz,true);z.setUint32(16,off,true);return new Blob([...ch,...cd,new Uint8Array(z.buffer)],{type:'application/zip'})}
async function unzip(buf,onp){const u=new Uint8Array(buf),v=new DataView(buf);let e=u.length-22;while(e>=0&&v.getUint32(e,true)!=0x06054b50)e--;if(e<0)throw Error('ZIPファイルではありません');const n=v.getUint16(e+10,true);let p=v.getUint32(e+16,true);const R={};
for(let i=0;i<n;i++){if(onp){onp(i,n);await slice()}if(v.getUint32(p,true)!=0x02014b50)throw Error('ZIPの構造が不正です');const m=v.getUint16(p+10,true),cz=v.getUint32(p+20,true),nl=v.getUint16(p+28,true),xl=v.getUint16(p+30,true),kl=v.getUint16(p+32,true),lo=v.getUint32(p+42,true),nm=td(u.subarray(p+46,p+46+nl));p+=46+nl+xl+kl;
const ds=lo+30+v.getUint16(lo+26,true)+v.getUint16(lo+28,true),raw=u.subarray(ds,ds+cz);if(nm.endsWith('/'))continue;const key=nm.split('/').pop();
if(m==0)R[key]=raw;else if(m==8){if(typeof DecompressionStream=='undefined')throw Error('このブラウザは圧縮ZIPの展開に未対応です');R[key]=new Uint8Array(await new Response(new Blob([raw]).stream().pipeThrough(new DecompressionStream('deflate-raw'))).arrayBuffer())}else throw Error('未対応のZIP圧縮方式('+m+')')}return R}

// ===== 書き出し(.sprite3 = 現在のスプライト / .sb3 = プロジェクト全体) =====
// 1コスチューム分の画像データ(ベクター=図形ぴったりのSVG、ビットマップ=描かれた範囲ぴったりのPNG)と、Scratch用の定義を作る
async function costAsset(c){let d,ext,res=1,rcx=c.cx,rcy=c.cy;
if(c.k=='v'){/* 縁を含む図形の範囲ぴったり(キャンバス外にはみ出した分も含む)に切り出し、回転中心は同じ位置を指すようずらす */const bb=vecBBox(c);if(bb){rcx=c.cx-bb[0];rcy=c.cy-bb[1]}d=te(svg(c,bb)+`<!--rotationCenter:${rcx}:${rcy}-->`);ext='svg'}
else{const o=document.createElement('canvas');o.width=c.w;o.height=c.h;dc(o.getContext('2d'),c);
/* 透明度1以上のピクセルがある範囲ぴったりに切り出す(何も描かれていない場合は元のサイズのまま)。回転中心は同じ位置を指すよう切り出し分だけずらす */
const bb=bmBBox(o);let oo=o,ew=c.w,eh=c.h;if(bb){ew=bb[2]-bb[0];eh=bb[3]-bb[1];oo=document.createElement('canvas');oo.width=ew;oo.height=eh;oo.getContext('2d').drawImage(o,-bb[0],-bb[1]);rcx=c.cx-bb[0];rcy=c.cy-bb[1]}
const b=await new Promise(r=>oo.toBlob(r,'image/png'));if(!b)throw Error('PNG変換に失敗しました');d=new Uint8Array(await b.arrayBuffer());ext='png';res=RS(c);if(oo.width!=ew||oo.height!=eh)throw Error(c.n+': 画像サイズの不整合')}
const id=md5(d),fn=id+'.'+ext;return{fn,d,meta:{name:c.n,bitmapResolution:res,dataFormat:ext,assetId:id,md5ext:fn,rotationCenterX:rcx,rotationCenterY:rcy}}}
// スプライト(またはステージ)1つ分のScratchターゲットJSONを作り、必要なファイルを files / seen に追加する
async function spTarget(sp,lo,files,seen,onp){const costumes=[];
if(sp.blank){const d=te(BLANK_BD),id=md5(d),fn=id+'.svg';costumes.push({name:'背景1',dataFormat:'svg',assetId:id,md5ext:fn,rotationCenterX:240,rotationCenterY:180});if(!seen.has(fn)){seen.add(fn);files.push([fn,d])}}
else{let k=0;for(const c of sp.cs){if(onp)onp(k++,sp.cs.length);await slice();const a=await costAsset(c);costumes.push(a.meta);if(!seen.has(a.fn)){seen.add(a.fn);files.push([a.fn,a.d])}}}
const ex=JSON.parse(JSON.stringify(sp.ex||(sp.stage?STD():SPD()))),snds=(Array.isArray(ex.sounds)?ex.sounds:[]).filter(x=>sp.snd&&sp.snd[x.md5ext]);
snds.forEach(x=>{if(!seen.has(x.md5ext)){seen.add(x.md5ext);files.push([x.md5ext,sp.snd[x.md5ext]])}});
return Object.assign({isStage:!!sp.stage,name:sp.stage?'Stage':sp.n},sp.stage?STD():SPD(),ex,{isStage:!!sp.stage,name:sp.stage?'Stage':sp.n,currentCostume:Math.min(Math.max(0,sp.ci|0),costumes.length-1),costumes,sounds:snds,layerOrder:lo})}
const safeName=n=>String(n).replace(/[\\\/:*?"<>|]/g,'_')||'sprite';
async function s3out(){try{spSave();const sp=SPS[SPI];if(sp.stage){await uiAlert('ステージは.sprite3では書き出せません。\n全体を.sb3で書き出してください。');return}
bcommit();spSave();progBegin('.sprite3を書き出し中…');const files=[],seen=new Set(),t=await spTarget(sp,1,files,seen,(i,n)=>progSet(i/n,'コスチュームを書き出し中 '+(i+1)+' / '+n));
progSet(1,'ZIPを作成中…');await yieldUI();const z=zipMake([['sprite.json',te(JSON.stringify(t))],...files]);progEnd();dl(z,safeName(sp.n)+'.sprite3')}catch(x){progEnd();await uiAlert('.sprite3の書き出しに失敗しました: '+x.message)}}
async function sb3out(){try{spSave();bcommit();spSave();const all=SPS.slice(),stage=all.find(s=>s.stage)||{stage:true,n:'Stage',blank:1,ci:0,cs:[],ex:STD(),snd:{}},ord=[stage,...all.filter(s=>!s.stage)],tot=ord.reduce((a,s)=>a+(s.blank?1:s.cs.length),0);
progBegin('.sb3を書き出し中…');const files=[],seen=new Set(),targets=[];let K=0;
for(let i=0;i<ord.length;i++){targets.push(await spTarget(ord[i],i,files,seen,(k)=>progSet((K+k)/tot,'コスチュームを書き出し中 '+(K+k+1)+' / '+tot)));K+=ord[i].blank?1:ord[i].cs.length}
progSet(1,'ZIPを作成中…');await yieldUI();
const j={targets,monitors:PRJ.monitors||[],extensions:PRJ.extensions||[],meta:{semver:'3.0.0',vm:'15.2.0',agent:navigator.userAgent}};
const z=zipMake([['project.json',te(JSON.stringify(j))],...files]);progEnd();dl(z,'project.sb3')}catch(x){progEnd();await uiAlert('.sb3の書き出しに失敗しました: '+x.message)}}
// ===== 読み込み(.sprite3 / .sb3 を中身で自動判別) =====
// コスチューム定義の一覧を、現在のデータには触れず新しい配列として作る(SVG変換が現在のコスチュームを使うため、処理中だけ cs/ci を差し替える)
async function decodeCostumes(Z,list,W,I,onp){const k0=cs,k1=ci,out=[];cs=out;
try{let kk=0;for(const q of list){if(onp)onp(kk,list.length);kk++;await slice();const d=Z[q.md5ext||q.assetId+'.'+q.dataFormat];if(!d){W.push(q.name+': 画像ファイルが見つかりません');continue}const rx=+q.rotationCenterX||0,ry=+q.rotationCenterY||0;
if(q.dataFormat=='svg'){const t=td(d),R=new DOMParser().parseFromString(t,'image/svg+xml').documentElement;if(R.nodeName!='svg'){W.push(q.name+': SVGを解析できません');continue}
const vb=(R.getAttribute('viewBox')||'').trim().split(/[\s,]+/).map(Number),ok=vb.length==4&&vb.every(isFinite)&&vb[2]>0&&vb[3]>0,vw=ok?vb[2]:parseFloat(R.getAttribute('width'))||480,vh=ok?vb[3]:parseFloat(R.getAttribute('height'))||360,k=Math.min(1,4096/Math.max(vw,vh)),c=mk('v',q.name);
c.w=Math.max(1,Math.round(vw*k));c.h=Math.max(1,Math.round(vh*k));c.cx=rx*k;c.cy=ry*k;cs.push(c);ci=cs.length-1;sel=[];svgImport(t);c.u=[];c.r=[];
if(!c.sh.length&&R.querySelector('path,rect,circle,ellipse,line,polygon,polyline,image,text')){const s={t:'img',x:c.w/2,y:c.h/2,r:0,w:c.w,h:c.h,src:'data:image/svg+xml;base64,'+btoa(unescape(encodeURIComponent(t)))};ld(s);c.sh.push(s);W.push(q.name+': 図形に変換できず画像として配置(個別編集不可)')}{const dx=240-c.cx,dy=180-c.cy;c.sh.forEach(s=>{s.x+=dx;s.y+=dy});c.w=480;c.h=360;c.cx=240;c.cy=180}}
else if(q.dataFormat=='png'||q.dataFormat=='jpg'||q.dataFormat=='jpeg'){const im=await new Promise((ok,ng)=>{const i=new Image;i.onload=()=>ok(i);i.onerror=()=>ng(Error(q.name+': 画像を読み込めません'));i.src=URL.createObjectURL(new Blob([d],{type:'image/'+(q.dataFormat=='png'?'png':'jpeg')}))}),c=mk('b',q.name);
const R=+q.bitmapResolution>0?+q.bitmapResolution:1;c.res=R;{const iw=im.naturalWidth,ih=im.naturalHeight,cX=isFinite(parseFloat(q.rotationCenterX))?+q.rotationCenterX:iw/2,cY=isFinite(parseFloat(q.rotationCenterY))?+q.rotationCenterY:ih/2,hx=Math.max(240*R,cX,iw-cX),hy=Math.max(180*R,cY,ih-cY),offX=Math.round(hx-cX),offY=Math.round(hy-cY);c.w=c.bc.width=Math.max(Math.ceil(hx*2),offX+iw);c.h=c.bc.height=Math.max(Math.ceil(hy*2),offY+ih);c.bc.getContext('2d').drawImage(im,offX,offY);c.cx=cX+offX;c.cy=cY+offY;I.push(`${q.name}: ${iw}×${ih}px / 解像度${R} → 論理${+(iw/R).toFixed(2)}×${+(ih/R).toFixed(2)}`)}cs.push(c);URL.revokeObjectURL(im.src)}
else W.push(q.name+': 未対応の形式('+q.dataFormat+')')}return out}finally{cs=k0;ci=k1}}
const exOf=(t,Z)=>{const e={},snd={};for(const k in t)if(!['name','isStage','costumes','currentCostume'].includes(k))e[k]=t[k];
const L=[];(Array.isArray(t.sounds)?t.sounds:[]).forEach(x=>{const fn=x.md5ext||(x.assetId+'.'+x.dataFormat),f=Z[fn];if(f){snd[fn]=f;L.push(Object.assign({},x,{md5ext:fn}))}});e.sounds=L;return{ex:e,snd}};
async function s3in(file){const W=[],I=[];svgImport.q=1;svgImport.w=W;spSave();
try{progBegin('ファイルを読み込み中…');const Z=await unzip(await file.arrayBuffer(),(i,n)=>progSet(.3*i/n,'ファイルを展開中 '+(i+1)+' / '+n));
const isP=!!Z['project.json'];if(!isP&&!Z['sprite.json'])throw Error('project.json / sprite.json がありません(.sb3 / .sprite3 ではない可能性)');
const j=JSON.parse(td(Z[isP?'project.json':'sprite.json'])),TG=isP?j.targets:[j];if(!Array.isArray(TG)||!TG.length)throw Error('スプライトがありません');
let mode='replace';progEnd();
if(!isP){mode=await uiDlg('.sprite3の読み込み方法を選んでください',[{t:'キャンセル',v:null},{t:'現在のスプライトにコスチュームを追加',v:'add'},{t:'新しいスプライトとして追加',v:'new'}],{esc:null,focus:2});if(!mode)return}
else if(!await uiConfirm('プロジェクト全体(.sb3)を読み込みます。\n現在の内容はすべて置き換わります。\n(必要なら先に「プロジェクトを保存」してください)','置き換えて読み込む','キャンセル'))return;
progBegin('ファイルを読み込み中…');
const tot=TG.reduce((a,t)=>a+(Array.isArray(t.costumes)?t.costumes.length:0),0)||1,built=[];let K=0;
for(const t of TG){if(!Array.isArray(t.costumes)||!t.costumes.length){W.push((t.name||'?')+': コスチュームがありません(スキップ)');continue}
const k0=K,out=await decodeCostumes(Z,t.costumes,W,I,i=>progSet(.3+.7*(k0+i)/tot,'コスチュームを読み込み中 '+(k0+i+1)+' / '+tot));K+=t.costumes.length;
if(!out.length){W.push((t.name||'?')+': 読み込めるコスチュームがありませんでした');continue}
const e=exOf(t,Z);if((t.sounds||[]).length>e.ex.sounds.length)W.push((t.name||'?')+': 一部のサウンドファイルが見つからないため外しました');
built.push({n:t.isStage?'Stage':String(t.name||'スプライト'),scratchName:String(t.name||'スプライト'),cs:out,ci:Math.min(Math.max(0,t.currentCostume|0),out.length-1),ex:e.ex,snd:e.snd,stage:!!t.isStage})}
if(!built.length)throw Error('読み込めるコスチュームがありませんでした');
progSet(1,'仕上げ中…');await yieldUI();spLeave();spSave();let msg;
if(mode=='replace'){built.sort((a,b)=>(b.stage?1:0)-(a.stage?1:0));const seenN=new Set();built.forEach(s=>{if(s.stage)return;let n=s.n,b=n.replace(/\d+$/,'')||n,k=2;while(seenN.has(n)||n=='Stage')n=b+k++;seenN.add(n);s.n=n});
SPS=built;PRJ={monitors:Array.isArray(j.monitors)?j.monitors:[],extensions:Array.isArray(j.extensions)?j.extensions:[]};SPI=Math.max(0,SPS.findIndex(s=>!s.stage));cs=SPS[SPI].cs;list.force=1;go(Math.min(SPS[SPI].ci,cs.length-1));fit();spUI();
msg='.sb3から'+SPS.filter(s=>!s.stage).length+'個のスプライト'+(SPS.some(s=>s.stage)?'とステージ':'')+'(コスチューム計'+SPS.reduce((a,s)=>a+s.cs.length,0)+'個)を読み込みました。'}
else if(mode=='new'){const b=built[0];b.stage=false;b.n=spUnique(b.n);SPS.push(b);spSwitch(SPS.length-1);msg='.sprite3から新しいスプライト「'+b.n+'」(コスチューム'+b.cs.length+'個)を追加しました。'}
else{const n0=cs.length,add=built[0].cs;cs.push(...add);ci=Math.min(ci,cs.length-1);list.force=1;go(n0);spUI();msg='.sprite3から'+add.length+'個のコスチュームを現在のスプライトに追加しました。'}
if(mode!='add'&&window.SCN&&window.SCN.H.importScratch){const result=window.SCN.H.importScratch(built,{replace:mode=='replace',name:file.name});msg+='\nアニメーションに'+result.objects+'個の対象と'+result.scripts+'本のスクリプトを反映しました。「アニメーション」の緑の旗で実行できます。';W.push(...result.warnings)}
progEnd();await uiAlert(msg+'\nSVGは図形ごとに編集できます(未対応要素は除く)。PNGはビットマップです。'+(mode!='add'?'\n対応ブロックはアニメーション画面で編集・実行できます。元のScratchブロック・変数・サウンド定義も書き出し用に保持します。':'\n「コスチュームを追加」は画像のみです。プログラムも取り込む場合は「新しいスプライトとして追加」を選んでください。')+(I.length?'\n\n画像サイズ(実ピクセル → 論理サイズ):\n・'+I.join('\n・'):'')+(W.length?'\n\n注意:\n・'+[...new Set(W)].join('\n・'):''))}
catch(x){progEnd();list.force=1;try{go(Math.min(ci,cs.length-1))}catch(e){}spUI();await uiAlert('.sprite3 / .sb3の読み込みに失敗しました。現在のデータは変更されていません。\n'+x.message)}
finally{progEnd();svgImport.q=0}}
$('#s3o').onclick=s3out;$('#sb3o').onclick=sb3out;$('#s3i').onclick=()=>$('#s3f').click();$('#s3f').onchange=e=>{const f=e.target.files[0];e.target.value='';if(f)s3in(f)};

// ===== 輪郭トレース(文字の図形化 / PNGベクター化 共通エンジン) =====
const tick=()=>new Promise(r=>setTimeout(r,0));
function traceLoops(m,w,h,eps,minA){const W1=w+1,E=new Map(),add=(a,b)=>{let l=E.get(a);if(!l)E.set(a,l=[]);l.push(b)};
for(let y=0;y<h;y++)for(let x=0;x<w;x++)if(m[y*w+x]){const a=y*W1+x,b=a+W1;if(!y||!m[(y-1)*w+x])add(a,a+1);if(x==w-1||!m[y*w+x+1])add(a+1,b+1);if(y==h-1||!m[(y+1)*w+x])add(b+1,b);if(!x||!m[y*w+x-1])add(b,a)}
const out=[];while(E.size){const st=E.keys().next().value;let cur=st,P=[];do{const l=E.get(cur),nx=l.pop();if(!l.length)E.delete(cur);P.push([cur%W1,(cur/W1)|0]);cur=nx}while(cur!=st&&E.has(cur));
P=P.filter((p,i)=>{const a=P[(i+P.length-1)%P.length],b=P[(i+1)%P.length];return(p[0]-a[0])*(b[1]-p[1])-(p[1]-a[1])*(b[0]-p[0])!=0});if(P.length<3)continue;
let ar=0;P.forEach((p,i)=>{const q=P[(i+1)%P.length];ar+=p[0]*q[1]-q[0]*p[1]});if(Math.abs(ar/2)<minA)continue;
let f=0,fd=-1;P.forEach((p,i)=>{const d=(p[0]-P[0][0])**2+(p[1]-P[0][1])**2;if(d>fd){fd=d;f=i}});
const S=dp(P.slice(0,f+1),eps).slice(0,-1).concat(dp([...P.slice(f),P[0]],eps).slice(0,-1));if(S.length>=3)out.push(bez(S))}return out}
function dp(P,e){if(P.length<3)return P;const a=P[0],b=P[P.length-1],dx=b[0]-a[0],dy=b[1]-a[1],L=Math.hypot(dx,dy)||1;let m=-1,id=0;for(let i=1;i<P.length-1;i++){const d=Math.abs((P[i][0]-a[0])*dy-(P[i][1]-a[1])*dx)/L;if(d>m){m=d;id=i}}
if(m<=e)return[a,b];return dp(P.slice(0,id+1),e).slice(0,-1).concat(dp(P.slice(id),e))}
function bez(P){const n=P.length,o=[],I=[];for(let i=0;i<n;i++){const p=P[(i+n-1)%n],q=P[i],r=P[(i+1)%n],ax=q[0]-p[0],ay=q[1]-p[1],bx=r[0]-q[0],by=r[1]-q[1],c=(ax*bx+ay*by)/((Math.hypot(ax,ay)*Math.hypot(bx,by))||1);
if(c<.64){o.push(q);I.push(q)}else{const tx=(r[0]-p[0])/6,ty=(r[1]-p[1])/6;o.push([q[0]+tx,q[1]+ty]);I.push([q[0]-tx,q[1]-ty])}}return{P,o,I}}
function mkPath(B,T,col,ex){const L=B.map(b=>({P:b.P.map(T),o:b.o.map(T),I:b.I.map(T)})),A=L.flatMap(l=>[...l.P,...l.o,...l.I]),xs=A.map(p=>p[0]),ys=A.map(p=>p[1]),x0=Math.min(...xs),x1=Math.max(...xs),y0=Math.min(...ys),y1=Math.max(...ys),cx=(x0+x1)/2,cy=(y0+y1)/2,w=Math.max(x1-x0,.01),h=Math.max(y1-y0,.01),f=p=>(p[0]-cx).toFixed(2)+','+(p[1]-cy).toFixed(2);let d='';
L.forEach(l=>{const n=l.P.length;d+='M'+f(l.P[0]);for(let k=0;k<n;k++){const j=(k+1)%n;d+='C'+f(l.o[k])+' '+f(l.I[j])+' '+f(l.P[j])}d+='z'});
return{t:'pd',d,w0:w,h0:h,w,h,x:cx,y:cy,r:0,f:col,s:null,sw:1,fr:'evenodd',...ex}}
// --- A. 文字の図形化: 高解像度で描画した文字の輪郭(穴を含む)をベジェ曲線パスへ。元テキストは ot に保持
// ===== フォント輪郭の直接取得(TTF/OTF[CFF]/WOFF/TTC) =====
// 目的: 文字を画像化してトレースせず、フォントが持つアウトライン(二次/三次ベジェ)をそのままパスにする
const FONTLIB=(()=>{
const u16=(v,o)=>v.getUint16(o),i16=(v,o)=>v.getInt16(o),u32=(v,o)=>v.getUint32(o),tag=(v,o)=>String.fromCharCode(v.getUint8(o),v.getUint8(o+1),v.getUint8(o+2),v.getUint8(o+3));
async function inflate(u8){const ds=new DecompressionStream('deflate'),w=ds.writable.getWriter();w.write(u8);w.close();return new Uint8Array(await new Response(ds.readable).arrayBuffer())}
async function unwrap(buf,face){let v=new DataView(buf);let sig=tag(v,0);
if(sig=='wOF2')throw Error('WOFF2形式は未対応です');
if(sig=='wOFF'){const n=u16(v,12),tabs=[];let out=[];for(let i=0;i<n;i++){const o=44+i*20;tabs.push({tag:tag(v,o),off:u32(v,o+4),cl:u32(v,o+8),ol:u32(v,o+12)})}
const T={};for(const t of tabs){const raw=new Uint8Array(buf,t.off,t.cl);T[t.tag]=t.cl<t.ol?await inflate(raw):raw.slice()}return{T}}
let base=0;if(sig=='ttcf'){const nf=u32(v,8);base=u32(v,12+4*Math.min(face||0,nf-1))}
const nt=u16(v,base+4),T={};for(let i=0;i<nt;i++){const o=base+12+i*16;T[tag(v,o)]=new Uint8Array(buf,u32(v,o+8),u32(v,o+12))}return{T}}
// ---- cmap
function cmapLookup(cm){const v=new DataView(cm.buffer,cm.byteOffset,cm.byteLength),n=u16(v,2);let best=null;
for(let i=0;i<n;i++){const pid=u16(v,4+i*8),eid=u16(v,6+i*8),off=u32(v,8+i*8),f=u16(v,off),score=(f==12&&((pid==3&&eid==10)||pid==0))?4:(pid==3&&eid==1&&f==4)?3:(pid==0&&f==4)?2:(f==4||f==12||f==0||f==6)?1:0;if(score&&(!best||score>best.s))best={s:score,off,f}}
if(!best)return()=>0;const o=best.off,f=best.f;
if(f==12){const ng=u32(v,o+12);return cp=>{let lo=0,hi=ng-1;while(lo<=hi){const m=(lo+hi)>>1,g=o+16+m*12,a=u32(v,g),b=u32(v,g+4);if(cp<a)hi=m-1;else if(cp>b)lo=m+1;else return u32(v,g+8)+cp-a}return 0}}
if(f==4){const sc=u16(v,o+6)/2,eo=o+14,so=eo+sc*2+2,dO=so+sc*2,rO=dO+sc*2;return cp=>{if(cp>0xFFFF)return 0;for(let i=0;i<sc;i++){const e=u16(v,eo+i*2);if(cp<=e){const s=u16(v,so+i*2);if(cp<s)return 0;const ro=u16(v,rO+i*2);if(!ro)return(cp+i16(v,dO+i*2))&0xFFFF;const g=u16(v,rO+i*2+ro+(cp-s)*2);return g?(g+i16(v,dO+i*2))&0xFFFF:0}}return 0}}
if(f==6){const first=u16(v,o+6),cnt=u16(v,o+8);return cp=>cp>=first&&cp<first+cnt?u16(v,o+10+(cp-first)*2):0}
if(f==0)return cp=>cp<256?v.getUint8(o+6+cp):0;return()=>0}
// ---- glyf (TrueType: 二次ベジェ -> 三次へ変換して返す)
function glyfReader(T){const head=new DataView(T.head.buffer,T.head.byteOffset,T.head.byteLength),upm=u16(head,18),locFmt=i16(head,50),maxp=new DataView(T.maxp.buffer,T.maxp.byteOffset,T.maxp.byteLength),ng=u16(maxp,4),hh=new DataView(T.hhea.buffer,T.hhea.byteOffset,T.hhea.byteLength),nh=u16(hh,34),hm=new DataView(T.hmtx.buffer,T.hmtx.byteOffset,T.hmtx.byteLength),lo=new DataView(T.loca.buffer,T.loca.byteOffset,T.loca.byteLength),gl=new DataView(T.glyf.buffer,T.glyf.byteOffset,T.glyf.byteLength);
const loc=i=>locFmt?u32(lo,i*4):u16(lo,i*2)*2;
const adv=g=>u16(hm,Math.min(g,nh-1)*4);
function points(g,depth){const s=loc(g),e=loc(g+1);if(e<=s||depth>6)return[];const nc=i16(gl,s);let p=s+10;
if(nc>=0){const ends=[];for(let i=0;i<nc;i++){ends.push(u16(gl,p));p+=2}const np=nc?ends[nc-1]+1:0,il=u16(gl,p);p+=2+il;const fl=[];while(fl.length<np){const f=gl.getUint8(p++);fl.push(f);if(f&8){let r=gl.getUint8(p++);while(r--&&fl.length<np)fl.push(f)}}
const xs=[],ys=[];let a=0;for(let i=0;i<np;i++){const f=fl[i];if(f&2){const d=gl.getUint8(p++);a+=(f&16)?d:-d}else if(!(f&16)){a+=i16(gl,p);p+=2}xs.push(a)}a=0;for(let i=0;i<np;i++){const f=fl[i];if(f&4){const d=gl.getUint8(p++);a+=(f&32)?d:-d}else if(!(f&32)){a+=i16(gl,p);p+=2}ys.push(a)}
const cs=[];let st=0;for(const en of ends){const c=[];for(let i=st;i<=en;i++)c.push({x:xs[i],y:ys[i],on:!!(fl[i]&1)});cs.push(c);st=en+1}return cs}
// composite
const out=[];let more=1;while(more){const f=u16(gl,p),gi=u16(gl,p+2);p+=4;let dx,dy;if(f&1){dx=i16(gl,p);dy=i16(gl,p+2);p+=4}else{dx=gl.getInt8(p);dy=gl.getInt8(p+1);p+=2}if(!(f&2)){dx=0;dy=0}
let a=1,b=0,c=0,d=1;if(f&8){a=d=i16(gl,p)/16384;p+=2}else if(f&0x40){a=i16(gl,p)/16384;d=i16(gl,p+2)/16384;p+=4}else if(f&0x80){a=i16(gl,p)/16384;b=i16(gl,p+2)/16384;c=i16(gl,p+4)/16384;d=i16(gl,p+6)/16384;p+=8}
for(const c0 of points(gi,depth+1))out.push(c0.map(q=>({x:a*q.x+c*q.y+dx,y:b*q.x+d*q.y+dy,on:q.on})));more=f&0x20}return out}
function toCubic(c){const n=c.length;if(!n)return null;// 輪郭 -> [{x,y}開始, セグメント配列 {t:'L'|'C',...}]
let pts=c.slice();let si=pts.findIndex(q=>q.on);if(si<0){const a=pts[0],b=pts[n-1];pts=[{x:(a.x+b.x)/2,y:(a.y+b.y)/2,on:true},...pts];si=0}else pts=pts.slice(si).concat(pts.slice(0,si));
const segs=[],P0=pts[0];let cur=P0,q=null;const quad=(a,c1,b)=>segs.push({t:'C',x1:a.x+2/3*(c1.x-a.x),y1:a.y+2/3*(c1.y-a.y),x2:b.x+2/3*(c1.x-b.x),y2:b.y+2/3*(c1.y-b.y),x:b.x,y:b.y});
for(let i=1;i<=pts.length;i++){const p=i==pts.length?P0:pts[i];if(i==pts.length&&q){quad(cur,q,P0);q=null;break}if(p.on){if(q){quad(cur,q,p);q=null}else segs.push({t:'L',x:p.x,y:p.y});cur=p}else{if(q){const m={x:(q.x+p.x)/2,y:(q.y+p.y)/2,on:true};quad(cur,q,m);cur=m}q=p}}
if(q)quad(cur,q,P0);return{x:P0.x,y:P0.y,segs}}
return{upm,ng,adv,glyph:g=>points(g,0).map(toCubic).filter(Boolean)}}
// ---- CFF (Type2 charstring。CID-keyed CJKフォント対応)
function cffReader(T){const d=T['CFF '],v=new DataView(d.buffer,d.byteOffset,d.byteLength);
const idx=o=>{const n=u16(v,o);if(!n)return{n:0,end:o+2,get:()=>null};const os=v.getUint8(o+2),offs=[];for(let i=0;i<=n;i++){let x=0;for(let k=0;k<os;k++)x=x*256+v.getUint8(o+3+i*os+k);offs.push(x)}const base=o+3+(n+1)*os-1;return{n,end:base+offs[n],get:i=>d.subarray(base+offs[i],base+offs[i+1])}};
const dict=b=>{const r={};let st=[],i=0;while(i<b.length){const c=b[i++];if(c<=21){let op=c;if(c==12)op=1200+b[i++];r[op]=st;st=[]}else if(c==28){st.push((b[i]<<8|b[i+1])<<16>>16);i+=2}else if(c==29){st.push(b[i]<<24|b[i+1]<<16|b[i+2]<<8|b[i+3]);i+=4}else if(c==30){let s='',done=0;while(!done){const x=b[i++];for(const nb of[x>>4,x&15]){if(nb==15){done=1;break}s+=nb<10?nb:nb==10?'.':nb==11?'E':nb==12?'E-':nb==14?'-':''}}st.push(parseFloat(s))}else if(c>=32&&c<=246)st.push(c-139);else if(c>=247&&c<=250){st.push((c-247)*256+b[i++]+108)}else if(c>=251&&c<=254){st.push(-(c-251)*256-b[i++]-108)}}return r};
const hd=v.getUint8(2),nameI=idx(hd),topI=idx(nameI.end),strI=idx(topI.end),gsubr=idx(strI.end),top=dict(topI.get(0));
const cs=idx(top[17][0]),ng=cs.n,isCID=top[1230]!==undefined,matrix=top[1207]||null;
let upm=1000;if(top[1207])upm=1/top[1207][0];
const priv=(dc)=>{if(!dc[18])return{subrs:null,dw:0,nw:0};const[sz,off]=dc[18],p=dict(d.subarray(off,off+sz));return{subrs:p[19]?idx(off+p[19][0]):null,dw:p[20]?p[20][0]:0,nw:p[21]?p[21][0]:0}};
let privs=[],fdsel=null;if(isCID){const fda=idx(top[1236][0]);for(let i=0;i<fda.n;i++)privs.push(priv(dict(fda.get(i))));
const o=top[1237][0],fmt=v.getUint8(o);fdsel=new Uint8Array(ng);if(fmt==0){for(let i=0;i<ng;i++)fdsel[i]=v.getUint8(o+1+i)}else{const nr=u16(v,o+1);let p=o+3;for(let r=0;r<nr;r++){const first=u16(v,p),fd=v.getUint8(p+2),nxt=u16(v,p+3);for(let g=first;g<nxt&&g<ng;g++)fdsel[g]=fd;p+=3}}}else privs=[priv(top)];
// charset: 文字コード→GID は cmap を使うので不要。ただし CID/名前 は無視
const bias=n=>n<1240?107:n<33900?1131:32768;
function run(gid){const fd=fdsel?fdsel[gid]:0,pv=privs[fd]||privs[0],ls=pv.subrs,gb=bias(gsubr.n),lb=ls?bias(ls.n):0,code=cs.get(gid);if(!code)return[];
const st=[],paths=[];let x=0,y=0,cur=null,nst=0,wd=false,open=false;const cnt=()=>{nst+=st.length>>1};
const mv=(dx,dy)=>{if(cur)paths.push(cur);x+=dx;y+=dy;cur={x,y,segs:[]}};
const ln=(dx,dy)=>{x+=dx;y+=dy;cur.segs.push({t:'L',x,y})};
const cv=(a,b,c,dd,e,f)=>{const x1=x+a,y1=y+b,x2=x1+c,y2=y1+dd;x=x2+e;y=y2+f;cur.segs.push({t:'C',x1,y1,x2,y2,x,y})};
let hints=0,done=false;
const exec=(b,depth)=>{let i=0;while(i<b.length&&!done){const c=b[i++];
if(c>=32||c==28){if(c==28){st.push((b[i]<<8|b[i+1])<<16>>16);i+=2}else if(c<=246)st.push(c-139);else if(c<=250)st.push((c-247)*256+b[i++]+108);else if(c<=254)st.push(-(c-251)*256-b[i++]-108);else{st.push((b[i]<<24|b[i+1]<<16|b[i+2]<<8|b[i+3])/65536);i+=4}continue}
switch(c){
case 1:case 3:case 18:case 23:{if(!wd&&st.length%2){st.shift();}wd=true;hints+=st.length>>1;st.length=0;break}
case 19:case 20:{if(!wd&&st.length%2){st.shift()}wd=true;hints+=st.length>>1;st.length=0;i+=Math.ceil(hints/8);break}
case 21:{if(!wd&&st.length>2)st.shift();wd=true;mv(st[0],st[1]);st.length=0;break}
case 22:{if(!wd&&st.length>1)st.shift();wd=true;mv(st[0],0);st.length=0;break}
case 4:{if(!wd&&st.length>1)st.shift();wd=true;mv(0,st[0]);st.length=0;break}
case 5:{for(let k=0;k+1<st.length;k+=2)ln(st[k],st[k+1]);st.length=0;break}
case 6:case 7:{let h=c==6;for(const q of st){if(h)ln(q,0);else ln(0,q);h=!h}st.length=0;break}
case 8:{for(let k=0;k+5<st.length;k+=6)cv(st[k],st[k+1],st[k+2],st[k+3],st[k+4],st[k+5]);st.length=0;break}
case 24:{let k=0;for(;k+7<st.length;k+=6)cv(st[k],st[k+1],st[k+2],st[k+3],st[k+4],st[k+5]);ln(st[k],st[k+1]);st.length=0;break}
case 25:{let k=0;for(;k+7<st.length;k+=2)ln(st[k],st[k+1]);cv(st[k],st[k+1],st[k+2],st[k+3],st[k+4],st[k+5]);st.length=0;break}
case 26:{let k=0,dx1=0;if(st.length%2){dx1=st[0];k=1}for(;k+3<st.length;k+=4){cv(dx1,st[k],st[k+1],st[k+2],0,st[k+3]);dx1=0}st.length=0;break}
case 27:{let k=0,dy1=0;if(st.length%2){dy1=st[0];k=1}for(;k+3<st.length;k+=4){cv(st[k],dy1,st[k+1],st[k+2],st[k+3],0);dy1=0}st.length=0;break}
case 30:case 31:{let h=c==31,k=0;while(k+3<st.length){const last=(st.length-k==5)?st[k+4]:0;if(h)cv(st[k],0,st[k+1],st[k+2],last,st[k+3]);else cv(0,st[k],st[k+1],st[k+2],st[k+3],last);h=!h;k+=4}st.length=0;break}
case 10:{const n=st.pop()+lb;if(ls&&depth<10){const s=ls.get(n);if(s)exec(s,depth+1)}break}
case 29:{const n=st.pop()+gb;if(depth<10){const s=gsubr.get(n);if(s)exec(s,depth+1)}break}
case 11:return;
case 14:{if(!wd&&(st.length==1||st.length==5))st.shift();done=true;st.length=0;return}
case 12:{const c2=b[i++];if(c2==34){const[a,bb,c3,dd,e,f,g]=st;cv(a,0,bb,c3,dd,0);cv(e,0,f,-c3,g,0)}else if(c2==35){cv(st[0],st[1],st[2],st[3],st[4],st[5]);cv(st[6],st[7],st[8],st[9],st[10],st[11])}else if(c2==36){cv(st[0],st[1],st[2],st[3],st[4],0);cv(st[5],0,st[6],st[7],st[8],-(st[1]+st[3]+st[7]))}else if(c2==37){const dx=st[0]+st[2]+st[4]+st[6]+st[8],dy=st[1]+st[3]+st[5]+st[7]+st[9];cv(st[0],st[1],st[2],st[3],st[4],st[5]);if(Math.abs(dx)>Math.abs(dy))cv(st[6],st[7],st[8],st[9],st[10],-dy);else cv(st[6],st[7],st[8],st[9],-dx,st[10])}st.length=0;break}
default:st.length=0}}};
exec(code,0);if(cur)paths.push(cur);return paths}
return{upm,ng,glyph:run,adv:null}}
// ---- 公開API
function psNameOf(T){try{const n=T.name,v=new DataView(n.buffer,n.byteOffset,n.byteLength),cnt=u16(v,2),so=u16(v,4);for(let i=0;i<cnt;i++){const o=6+i*12;if(u16(v,o+6)==6){const len=u16(v,o+8),off=so+u16(v,o+10),pid=u16(v,o);let s='';if(pid==1||pid==0&&false){for(let k=0;k<len;k++)s+=String.fromCharCode(n[off+k])}else{for(let k=0;k<len;k+=2)s+=String.fromCharCode(u16(v,off+k))}return s}}}catch(e){}return''}
async function load(buf,opt){opt=typeof opt=='number'?{face:opt}:(opt||{});let face=opt.face||0;
if(opt.ps&&tag(new DataView(buf),0)=='ttcf'){const nf=u32(new DataView(buf),8);for(let i=0;i<nf;i++){const{T:T0}=await unwrap(buf,i);if(psNameOf(T0)==opt.ps){face=i;break}}}
const{T}=await unwrap(buf,face);if(!T.cmap||!T.head)throw Error('フォントの表が不足しています');const cm=cmapLookup(T.cmap),hasG=!!(T.glyf&&T.loca);let R;
if(hasG)R=glyfReader(T);else if(T['CFF '])R=cffReader(T);else throw Error('対応していないフォント形式です(CFF2/可変フォントのみ)');
const hh=new DataView(T.hhea.buffer,T.hhea.byteOffset,T.hhea.byteLength),hm=new DataView(T.hmtx.buffer,T.hmtx.byteOffset,T.hmtx.byteLength),nh=u16(hh,34),adv=g=>u16(hm,Math.min(g,nh-1)*4);
const head=new DataView(T.head.buffer,T.head.byteOffset,T.head.byteLength),upm=u16(head,18);
return{upm,gid:cp=>cm(cp),adv,glyph:R.glyph,hasGlyph:cp=>cm(cp)>0}}
return{load}})();

// ===== 幾何ライブラリ(GEO): 多角形の交差解決・ブーリアン・オフセット・曲線あてはめ・輪郭抽出 =====
const GEO=(()=>{
const hyp=Math.hypot;
// ---- 曲線の平坦化(許容誤差 tol)。入力は三次ベジェ列
function flattenCubic(p0,p1,p2,p3,tol,out){const cx=p3[0]-p0[0],cy=p3[1]-p0[1],cl=hyp(cx,cy),dp=q=>cl>1e-12?Math.abs((q[0]-p0[0])*cy-(q[1]-p0[1])*cx)/cl:hyp(q[0]-p0[0],q[1]-p0[1]),dd=Math.max(dp(p1),dp(p2)),n=Math.max(1,Math.min(400,Math.ceil(Math.sqrt(.75*dd/tol))));for(let k=1;k<=n;k++){const t=k/n,u=1-t;out.push([u*u*u*p0[0]+3*u*u*t*p1[0]+3*u*t*t*p2[0]+t*t*t*p3[0],u*u*u*p0[1]+3*u*u*t*p1[1]+3*u*t*t*p2[1]+t*t*t*p3[1]])}}
const area=P=>{let a=0;for(let i=0,n=P.length;i<n;i++){const p=P[i],q=P[(i+1)%n];a+=p[0]*q[1]-q[0]*p[1]}return a/2};
// ---- 交差解決 + 領域抽出
// loops: [{pts:[[x,y]...], set:0}] すべて閉多角形。pred(w) : w=各セットの回転数配列 -> 領域に含めるか
// 戻り値: 領域の境界ループ配列(内部が進行方向の左側)
function region(loops,pred,opt){opt=opt||{};let minx=1e18,maxx=-1e18,miny=1e18,maxy=-1e18,N=0;for(const l of loops)for(const p of l.pts){minx=Math.min(minx,p[0]);maxx=Math.max(maxx,p[0]);miny=Math.min(miny,p[1]);maxy=Math.max(maxy,p[1]);N++}
if(!N)return[];const sc=Math.max(maxx-minx,maxy-miny,1),eps=opt.eps||sc*1e-7,snap=eps*4;
// 1) 入力線分(格子に丸め、長さ0を除く)
const S=[];let nset=0;for(const l of loops){nset=Math.max(nset,l.set+1);const P=l.pts,n=P.length;for(let i=0;i<n;i++){let a=P[i],b=P[(i+1)%n];const ax=Math.round(a[0]/eps)*eps,ay=Math.round(a[1]/eps)*eps,bx=Math.round(b[0]/eps)*eps,by=Math.round(b[1]/eps)*eps;if(ax==bx&&ay==by)continue;S.push({ax,ay,bx,by,set:l.set})}}
const M=S.length;if(!M)return[];const SL=S.map(s=>hyp(s.bx-s.ax,s.by-s.ay)),gr=v=>Math.round(v/eps)*eps;
// 2) 格子で候補ペアを求め、交点を分割点として収集。交点の座標は2本の線分で共有する(別々に計算して食い違うのを防ぐ)
const gs=Math.max(8,Math.min(256,Math.ceil(Math.sqrt(M)))),cw=(maxx-minx)/gs||1,ch=(maxy-miny)/gs||1,grid=new Map(),cl=(v,o,c)=>Math.min(gs-1,Math.max(0,Math.floor((v-o)/c)));
S.forEach((s,i)=>{const x0=cl(Math.min(s.ax,s.bx),minx,cw),x1=cl(Math.max(s.ax,s.bx),minx,cw),y0=cl(Math.min(s.ay,s.by),miny,ch),y1=cl(Math.max(s.ay,s.by),miny,ch);for(let x=x0;x<=x1;x++)for(let y=y0;y<=y1;y++){const k=x*gs+y;let a=grid.get(k);if(!a)grid.set(k,a=[]);a.push(i)}});
const cuts=S.map(()=>[]),seen=new Set(),addCut=(i,t,x,y)=>{cuts[i].push({t,x,y})};
for(const a of grid.values())for(let u=0;u<a.length;u++)for(let v=u+1;v<a.length;v++){const i=a[u],j=a[v],pk=i<j?i*M+j:j*M+i;if(seen.has(pk))continue;seen.add(pk);const s=S[i],t=S[j];
const rx=s.bx-s.ax,ry=s.by-s.ay,qx=t.bx-t.ax,qy=t.by-t.ay,den=rx*qy-ry*qx,wx=t.ax-s.ax,wy=t.ay-s.ay;
if(Math.abs(den)>1e-12*(SL[i]*SL[j])){const ta=(wx*qy-wy*qx)/den,tb=(wx*ry-wy*rx)/den,e1=snap/SL[i],e2=snap/SL[j];
if(ta>=-e1&&ta<=1+e1&&tb>=-e2&&tb<=1+e2){const s0=ta<=e1,s1=ta>=1-e1,t0=tb<=e2,t1=tb>=1-e2;let X;
if(s0)X=[s.ax,s.ay];else if(s1)X=[s.bx,s.by];else if(t0)X=[t.ax,t.ay];else if(t1)X=[t.bx,t.by];else X=[gr(s.ax+rx*ta),gr(s.ay+ry*ta)];
if(!(s0||s1))addCut(i,ta,X[0],X[1]);if(!(t0||t1))addCut(j,tb,X[0],X[1])}}
else{// 平行: 共線なら端点で相互分割
const cr=(wx*ry-wy*rx)/(SL[i]||1);if(Math.abs(cr)<snap){const L1=rx*rx+ry*ry,L2=qx*qx+qy*qy,p=(px,py)=>((px-s.ax)*rx+(py-s.ay)*ry)/L1,q=(px,py)=>((px-t.ax)*qx+(py-t.ay)*qy)/L2;
for(const[k,tt,x,y]of[[i,p(t.ax,t.ay),t.ax,t.ay],[i,p(t.bx,t.by),t.bx,t.by],[j,q(s.ax,s.ay),s.ax,s.ay],[j,q(s.bx,s.by),s.bx,s.by]]){const e=snap/SL[k];if(tt>e&&tt<1-e)addCut(k,tt,x,y)}}}}
// 3) ノード(snap 以内の点は同一ノードに溶接)と辺。同じ辺は向き付き個数(delta)として集約する
const NX=[],NY=[],NG=new Map(),nid=(x,y)=>{const cx=Math.floor(x/snap),cy=Math.floor(y/snap);for(let u=-1;u<=1;u++)for(let v=-1;v<=1;v++){const l=NG.get((cx+u)+','+(cy+v));if(l)for(const id of l)if(Math.abs(NX[id]-x)<=snap&&Math.abs(NY[id]-y)<=snap)return id}
const id=NX.length;NX.push(x);NY.push(y);const k=cx+','+cy;let l=NG.get(k);if(!l)NG.set(k,l=[]);l.push(id);return id};
const EM=new Map();
S.forEach((s,i)=>{const cs=cuts[i];cs.sort((a,b)=>a.t-b.t);let pu=nid(s.ax,s.ay);const pts=cs.map(c=>[c.x,c.y]);pts.push([s.bx,s.by]);
for(const[x,y]of pts){const v=nid(x,y);if(v===pu)continue;const a=Math.min(pu,v),b=Math.max(pu,v),k=a+'|'+b;let e=EM.get(k);if(!e)EM.set(k,e={a,b,d:new Array(nset).fill(0)});e.d[s.set]+=pu<v?1:-1;pu=v}});
const edges=[...EM.values()].filter(e=>e.d.some(v=>v!=0)),nE=edges.length,nN=NX.length;if(!nE)return[];
// 4) 半辺構造。各ノード周りを角度順に並べ、面(左側)を辿る
const nH=2*nE,hu=new Int32Array(nH),hv=new Int32Array(nH),ang=new Float64Array(nH),pos=new Int32Array(nH),nxt=new Int32Array(nH),out=Array.from({length:nN},()=>[]);
edges.forEach((e,k)=>{hu[2*k]=e.a;hv[2*k]=e.b;hu[2*k+1]=e.b;hv[2*k+1]=e.a;out[e.a].push(2*k);out[e.b].push(2*k+1)});
for(let h=0;h<nH;h++)ang[h]=Math.atan2(NY[hv[h]]-NY[hu[h]],NX[hv[h]]-NX[hu[h]]);
for(let v=0;v<nN;v++){const l=out[v];l.sort((p,q)=>ang[p]-ang[q]);l.forEach((h,i)=>{pos[h]=i})}
for(let h=0;h<nH;h++){const l=out[hv[h]],k=pos[h^1];nxt[h]=l[(k-1+l.length)%l.length]}
const face=new Int32Array(nH).fill(-1),fA=[],fH=[];
for(let h=0;h<nH;h++){if(face[h]>=0)continue;const f=fA.length,list=[];let a=0,x=h,g=0;do{face[x]=f;list.push(x);a+=NX[hu[x]]*NY[hv[x]]-NX[hv[x]]*NY[hu[x]];x=nxt[x]}while(x!==h&&g++<nH+5);fA.push(a/2);fH.push(list)}
// 5) 巻き数: 辺を挟んだ左右の差は delta で厳密に決まるので、面から面へ伝播させる。連結成分ごとの外側だけ、光線法で求める
const nF=fA.length,W=new Array(nF).fill(null),seenF=new Uint8Array(nF);
const bins=64,by0=miny,bh=(maxy-miny)/bins||1,B=Array.from({length:bins},()=>[]);S.forEach(s=>{const y0=Math.max(0,Math.min(bins-1,Math.floor((Math.min(s.ay,s.by)-by0)/bh))),y1=Math.max(0,Math.min(bins-1,Math.floor((Math.max(s.ay,s.by)-by0)/bh)));for(let b=y0;b<=y1;b++)B[b].push(s)});
const wind=(px,py)=>{const w=new Array(nset).fill(0),b=Math.max(0,Math.min(bins-1,Math.floor((py-by0)/bh)));for(const s of B[b]){if(s.ay<=py){if(s.by>py){const c=(s.bx-s.ax)*(py-s.ay)-(px-s.ax)*(s.by-s.ay);if(c>0)w[s.set]++}}else if(s.by<=py){const c=(s.bx-s.ax)*(py-s.ay)-(px-s.ax)*(s.by-s.ay);if(c<0)w[s.set]--}}return w};
for(let f0=0;f0<nF;f0++){if(seenF[f0])continue;const comp=[f0];seenF[f0]=1;
for(let qi=0;qi<comp.length;qi++)for(const h of fH[comp[qi]]){const g=face[h^1];if(!seenF[g]){seenF[g]=1;comp.push(g)}}
let root=comp[0];for(const f of comp)if(fA[f]<fA[root])root=f;
let best=-1;for(const f of comp)for(const h of fH[f]){const v=hu[h];if(best<0||NX[v]<NX[best]||(NX[v]==NX[best]&&NY[v]<NY[best]))best=v}
W[root]=wind(NX[best]-snap*5,NY[best]);const q=[root];
for(let qi=0;qi<q.length;qi++){const f=q[qi];for(const h of fH[f]){const g=face[h^1];if(W[g]===null){const d=edges[h>>1].d,sg=h&1?-1:1;W[g]=W[f].map((x,i)=>x-sg*d[i]);q.push(g)}}}}
// 6) 領域の内外が変わる辺だけを残し(内部が左)、つないでループ化。位相から作っているので必ず閉じる
const O=new Map();for(let k=0;k<nE;k++){const h=2*k,iL=pred(W[face[h]]),iR=pred(W[face[h+1]]);if(iL===iR)continue;const a=iL?hu[h]:hv[h],b=iL?hv[h]:hu[h];let l=O.get(a);if(!l)O.set(a,l=[]);l.push(b)}
const res=[];while(O.size){const s0=O.keys().next().value,l0=O.get(s0),b0=l0.pop();if(!l0.length)O.delete(s0);const P=[s0];let cur=b0,prev=s0,guard=0,closed=false;
while(guard++<nE*2+10){if(cur===s0){closed=true;break}P.push(cur);const l=O.get(cur);if(!l||!l.length)break;let bi=0;
if(l.length>1){const dx0=NX[cur]-NX[prev],dy0=NY[cur]-NY[prev];let best=-1e9;l.forEach((nb,i)=>{const ex=NX[nb]-NX[cur],ey=NY[nb]-NY[cur],cr=dx0*ey-dy0*ex,dt=dx0*ex+dy0*ey,an=Math.atan2(cr,dt);if(an>best){best=an;bi=i}})}
const nb=l.splice(bi,1)[0];if(!l.length)O.delete(cur);prev=cur;cur=nb}
if(closed&&P.length>=3){const Q=despike(P.map(id=>[NX[id],NY[id]]),eps*32);if(Q.length>=3&&Math.abs(area(Q))>eps*eps*10)res.push(Q)}}
return res}
// 幅が tol 以下の突起(a→先端→e で a と e がほぼ同じ点)と重複点を取り除く。面積はほぼ変わらない
function despike(P,tol){let ch=true;while(ch&&P.length>=3){ch=false;for(let i=0;i<P.length;i++){const n=P.length,a=P[(i+n-1)%n],b=P[i],e=P[(i+1)%n];
if(hyp(b[0]-a[0],b[1]-a[1])<=tol){P.splice(i,1);ch=true;break}
if(n>3&&hyp(a[0]-e[0],a[1]-e[1])<=tol){const ia=(i+n-1)%n,ie=(i+1)%n;const rm=[i,ie].sort((x,y)=>y-x);P.splice(rm[0],1);P.splice(rm[1],1);ch=true;break}}}return P}
// ---- 整理: 領域規則に従って内部が左になる単純なループへ
function normalize(polys,rule){const L=polys.map(p=>({pts:p,set:0}));return region(L,rule=='nonzero'?(w=>w[0]!=0):(w=>(w[0]&1)!=0))}
// ---- オフセット(d>0: 外側へ。内部が左のループが前提)
function offsetLoops(loops,d,join,miter,sharp){const out=[],ad=Math.abs(d);if(!ad)return loops.map(l=>l.slice());miter=miter||4;
for(const P0 of loops){const P=[];for(const p of P0){const q=P[P.length-1];if(!q||hyp(p[0]-q[0],p[1]-q[1])>1e-9)P.push(p)}if(P.length>1&&hyp(P[0][0]-P[P.length-1][0],P[0][1]-P[P.length-1][1])<1e-9)P.pop();const n=P.length;if(n<3)continue;
const U=[],Nn=[];for(let i=0;i<n;i++){const a=P[i],b=P[(i+1)%n],dx=b[0]-a[0],dy=b[1]-a[1],L=hyp(dx,dy)||1;U.push([dx/L,dy/L]);Nn.push([dy/L*d,-dx/L*d])}// 右法線×d(d<0で左へ)
const R=[];for(let i=0;i<n;i++){const v=P[i],j=(i+n-1)%n,u1=U[j],u2=U[i],n1=Nn[j],n2=Nn[i],cr=u1[0]*u2[1]-u1[1]*u2[0],dt=u1[0]*u2[0]+u1[1]*u2[1],A=[v[0]+n1[0],v[1]+n1[1]],Bp=[v[0]+n2[0],v[1]+n2[1]];
if(Math.abs(cr)<1e-5&&dt>0){R.push([(A[0]+Bp[0])/2,(A[1]+Bp[1])/2]);continue}
const uturn=dt<-1+1e-9,gap=uturn?(d>0):((d>0)?cr>0:cr<0);// 外へ動かす側が開く頂点(Uターンは線の端点=キャップ)
if(!gap){R.push(A,[v[0],v[1]],Bp);continue}
let jj=join;if(join=='orig')jj=(uturn||!(sharp?sharp(v):Math.abs(Math.atan2(cr,dt))>.35))?'round':'miter';/* 元の角を維持: 角ばった頂点はマイター、丸い(なめらかな)頂点は丸のまま */
if(jj=='round'){const a0=Math.atan2(n1[1],n1[0]),a1=Math.atan2(n2[1],n2[0]);let da=a1-a0;while(da>Math.PI)da-=2*Math.PI;while(da<-Math.PI)da+=2*Math.PI;if(uturn)da=Math.PI;const stp=Math.min(Math.PI/18,2*Math.acos(Math.max(0,1-.008/ad))||Math.PI/18),k=Math.max(1,Math.ceil(Math.abs(da)/Math.max(stp,.02)));R.push(A);for(let s=1;s<k;s++){const a=a0+da*s/k;R.push([v[0]+Math.cos(a)*ad,v[1]+Math.sin(a)*ad])}R.push(Bp)}
else if(jj=='miter'){const k=1+(n1[0]*n2[0]+n1[1]*n2[1])/(ad*ad);if(k>1e-9&&1/Math.sqrt((k)/2)<=miter){R.push([v[0]+(n1[0]+n2[0])/k,v[1]+(n1[1]+n2[1])/k])}else R.push(A,Bp)}
else R.push(A,Bp)}
out.push(R)}
return region(out.map(p=>({pts:p,set:0})),w=>w[0]>0)}
// ---- 曲線あてはめ(Schneider法)
const V={add:(a,b)=>[a[0]+b[0],a[1]+b[1]],sub:(a,b)=>[a[0]-b[0],a[1]-b[1]],mul:(a,k)=>[a[0]*k,a[1]*k],dot:(a,b)=>a[0]*b[0]+a[1]*b[1],len:a=>hyp(a[0],a[1]),norm:a=>{const l=hyp(a[0],a[1]);return l>1e-12?[a[0]/l,a[1]/l]:[0,0]}};
const bzAt=(b,t)=>{const u=1-t;return[u*u*u*b[0][0]+3*u*u*t*b[1][0]+3*u*t*t*b[2][0]+t*t*t*b[3][0],u*u*u*b[0][1]+3*u*u*t*b[1][1]+3*u*t*t*b[2][1]+t*t*t*b[3][1]]};
const bz1=(b,t)=>{const u=1-t;return[3*u*u*(b[1][0]-b[0][0])+6*u*t*(b[2][0]-b[1][0])+3*t*t*(b[3][0]-b[2][0]),3*u*u*(b[1][1]-b[0][1])+6*u*t*(b[2][1]-b[1][1])+3*t*t*(b[3][1]-b[2][1])]};
const bz2=(b,t)=>{const u=1-t;return[6*u*(b[2][0]-2*b[1][0]+b[0][0])+6*t*(b[3][0]-2*b[2][0]+b[1][0]),6*u*(b[2][1]-2*b[1][1]+b[0][1])+6*t*(b[3][1]-2*b[2][1]+b[1][1])]};
const chordU=P=>{const u=[0];for(let i=1;i<P.length;i++)u.push(u[i-1]+V.len(V.sub(P[i],P[i-1])));const L=u[u.length-1]||1;return u.map(x=>x/L)};
function genBez(P,u,t1,t2){const p0=P[0],p3=P[P.length-1],C=[[0,0],[0,0]],X=[0,0];for(let i=0;i<P.length;i++){const t=u[i],b1=3*t*(1-t)*(1-t),b2=3*t*t*(1-t),b0=(1-t)**3,b3=t**3,a1=V.mul(t1,b1),a2=V.mul(t2,b2);C[0][0]+=V.dot(a1,a1);C[0][1]+=V.dot(a1,a2);C[1][1]+=V.dot(a2,a2);const tm=V.sub(P[i],V.add(V.mul(p0,b0+b1),V.mul(p3,b2+b3)));X[0]+=V.dot(a1,tm);X[1]+=V.dot(a2,tm)}
C[1][0]=C[0][1];const det=C[0][0]*C[1][1]-C[1][0]*C[0][1],seg=V.len(V.sub(p0,p3));let al=0,ar=0;if(Math.abs(det)>1e-12){al=(X[0]*C[1][1]-X[1]*C[0][1])/det;ar=(C[0][0]*X[1]-C[1][0]*X[0])/det}const e=1e-6*seg;if(!(al>e)||!(ar>e))al=ar=seg/3;return[p0,V.add(p0,V.mul(t1,al)),V.add(p3,V.mul(t2,ar)),p3]}
function maxErr(P,b,u){let m=0,s=Math.floor(P.length/2);for(let i=1;i<P.length-1;i++){const d=V.sub(bzAt(b,u[i]),P[i]),e=V.dot(d,d);if(e>=m){m=e;s=i}}return[m,s]}
function fitCub(P,t1,t2,err,depth){depth=depth||0;if(P.length==2){const d=V.len(V.sub(P[1],P[0]))/3;return[[P[0],V.add(P[0],V.mul(t1,d)),V.add(P[1],V.mul(t2,d)),P[1]]]}
let u=chordU(P),b=genBez(P,u,t1,t2),[m,sp]=maxErr(P,b,u);if(m<err*err)return[b];
if(m<err*err*16)for(let k=0;k<4;k++){u=u.map((t,i)=>{const d=V.sub(bzAt(b,t),P[i]),d1=bz1(b,t),d2=bz2(b,t),den=V.dot(d1,d1)+V.dot(d,d2);return Math.abs(den)<1e-12?t:Math.max(0,Math.min(1,t-V.dot(d,d1)/den))});b=genBez(P,u,t1,t2);[m,sp]=maxErr(P,b,u);if(m<err*err)return[b]}
if(depth>40)return[b];let tc=V.norm(V.sub(P[sp-1],P[sp+1]));if(!V.len(tc))tc=V.norm(V.sub(P[sp-1],P[sp]));return fitCub(P.slice(0,sp+1),t1,tc,err,depth+1).concat(fitCub(P.slice(sp),V.mul(tc,-1),t2,err,depth+1))}
// 1本の三次ベジェで許容誤差内に収まるか(分割はしない)。収まらなければ null
function fitOne(P,t1,t2,err){if(P.length==2){const d=V.len(V.sub(P[1],P[0]))/3;return[P[0],V.add(P[0],V.mul(t1,d)),V.add(P[1],V.mul(t2,d)),P[1]]}
let u=chordU(P),b=genBez(P,u,t1,t2),[m]=maxErr(P,b,u);if(m<err*err)return b;if(m>=err*err*64)return null;
for(let k=0;k<4;k++){u=u.map((t,i)=>{const d=V.sub(bzAt(b,t),P[i]),d1=bz1(b,t),d2=bz2(b,t),den=V.dot(d1,d1)+V.dot(d,d2);return Math.abs(den)<1e-12?t:Math.max(0,Math.min(1,t-V.dot(d,d1)/den))});b=genBez(P,u,t1,t2);[m]=maxErr(P,b,u);if(m<err*err)return b}return null}
const dsegV=(p,a,b)=>{const dx=b[0]-a[0],dy=b[1]-a[1],L2=dx*dx+dy*dy;let t=L2?((p[0]-a[0])*dx+(p[1]-a[1])*dy)/L2:0;t=t<0?0:t>1?1:t;return hyp(p[0]-a[0]-t*dx,p[1]-a[1]-t*dy)};
// 標本点の間でベジェがふくらんでいないか(曲線上を細かくとって折れ線Qまでの距離を確認)
function bezNear(b,Q,lim){const mq=Q.length,u=chordU(Q),ns=Math.min(600,mq*3);let k=0;for(let s=1;s<ns;s++){const t=s/ns,p=bzAt(b,t);while(k<mq-2&&u[k+1]<t)k++;const lo=Math.max(0,k-30),hi=Math.min(mq-2,k+30);let d=1e18;for(let j=lo;j<=hi;j++){const dd=dsegV(p,Q[j],Q[j+1]);if(dd<d)d=dd}if(d>lim)return false}return true}
// 区間 P を「できるだけ少ない本数」の三次ベジェで近似(各セグメントを二分探索で最長にする)。接線は前後の点から広めに推定してなめらかにつなぐ
function fitSpan(P,t1,t2,err){const m=P.length;if(m<=4)return fitCub(P,t1,t2,err);
const kw=Math.max(2,Math.min(6,Math.floor(m/60)+2)),tan=p=>V.norm(V.sub(P[Math.min(m-1,p+kw)],P[Math.max(0,p-kw)])),out=[];let i=0,ts=t1;
while(i<m-1){const tj=j=>{const Q=P.slice(i,j+1),b=fitOne(Q,ts,j==m-1?t2:V.mul(tan(j),-1),err);if(!b)return null;if(Q.length>2){let pl=0;for(let q=1;q<Q.length;q++)pl+=hyp(Q[q][0]-Q[q-1][0],Q[q][1]-Q[q-1][1]);if(hyp(b[1][0]-b[0][0],b[1][1]-b[0][1])>pl*.9||hyp(b[2][0]-b[3][0],b[2][1]-b[3][1])>pl*.9||!bezNear(b,Q,err*1.5))return null}return b};
let c=tj(m-1);if(c){out.push(c);break}
let L=i+1,H=m-1;while(H-L>1){const mid=(L+H)>>1;if(tj(mid))L=mid;else H=mid}
c=tj(L);if(!c)return fitCub(P,t1,t2,err);out.push(c);if(L>=m-1)break;ts=tan(L);if(!V.len(ts))return fitCub(P,t1,t2,err);i=L;if(out.length>m)return fitCub(P,t1,t2,err)}
return out}
// 閉ループ(多角形)を、角を保ったなめらかな三次ベジェ列へ。戻り値: アンカー配列 [{p,i:[dx,dy],o:[dx,dy],c:角か}]
function fitLoop(P,tol,cornerDeg,win,greedy){const n0=P.length;let Q=[];for(const p of P){const q=Q[Q.length-1];if(!q||hyp(p[0]-q[0],p[1]-q[1])>1e-9)Q.push(p)}if(Q.length>1&&hyp(Q[0][0]-Q[Q.length-1][0],Q[0][1]-Q[Q.length-1][1])<1e-9)Q.pop();const n=Q.length;if(n<3)return null;
const cs=Math.cos((cornerDeg||35)*Math.PI/180);win=win||tol*3;
// 弧長の累積
const cum=[0];for(let i=1;i<=n;i++)cum.push(cum[i-1]+hyp(Q[i%n][0]-Q[i-1][0],Q[i%n][1]-Q[i-1][1]));const tot=cum[n];
const at=(i,s)=>{// i から弧長 s だけ進んだ(負なら戻った)点
let k=i,acc=0;if(s>=0){while(acc<s&&k-i<n){const nx=(k+1)%n;acc+=hyp(Q[nx][0]-Q[k%n][0],Q[nx][1]-Q[k%n][1]);k++}return Q[k%n]}else{while(acc<-s&&i-k<n){const pv=(k-1+n)%n;acc+=hyp(Q[pv][0]-Q[((k%n)+n)%n][0],Q[pv][1]-Q[((k%n)+n)%n][1]);k--}return Q[((k%n)+n)%n]}};
const ang=new Array(n);for(let i=0;i<n;i++){const a=at(i,-win),b=at(i,win),v1=V.norm(V.sub(Q[i],a)),v2=V.norm(V.sub(b,Q[i]));ang[i]=V.dot(v1,v2)}
const cor=[];for(let i=0;i<n;i++){if(ang[i]<cs){let isMax=true;for(let dir=-1;dir<=1&&isMax;dir+=2){let acc=0,k=i;for(let c=0;c<n;c++){const nk=(k+dir+n)%n;acc+=hyp(Q[nk][0]-Q[k][0],Q[nk][1]-Q[k][1]);k=nk;if(acc>=win||k==i)break;if(ang[k]<ang[i]-1e-4){isMax=false;break}}}if(isMax)cor.push(i)}}
let br=cor.length?cor:[0];const anchors=[];
const spanPts=(a,b)=>{const P2=[];let i=a;for(;;){P2.push(Q[i%n]);if(i%n==b%n&&P2.length>1)break;i++;if(P2.length>n+2)break}return P2};
const m=br.length;for(let k=0;k<m;k++){const a=br[k],b=br[(k+1)%m],bb=m==1?a:b;const Pp=spanPts(a,b);if(Pp.length<2)continue;
const isC1=cor.length>0,tdir=(p,q)=>V.norm(V.sub(q,p));
let t1,t2;const nearF=at(a,win*.8),nearB=at(b,-win*.8);
if(isC1){t1=V.norm(V.sub(nearF,Q[a]));t2=V.norm(V.sub(nearB,Q[b%n]))}else if(greedy){const kk=Math.max(1,Math.min(4,Math.floor(n/8)));t1=V.norm(V.sub(Q[(a+kk)%n],Q[(a-kk+n)%n]));t2=V.mul(t1,-1)}else{t1=V.norm(V.sub(at(a,win),at(a,-win)));t2=V.mul(t1,-1)}
if(!V.len(t1))t1=tdir(Pp[0],Pp[1]);if(!V.len(t2))t2=tdir(Pp[Pp.length-1],Pp[Pp.length-2]);
const cv=greedy?fitSpan(Pp,t1,t2,tol):fitCub(Pp,t1,t2,tol);cv.forEach((c,j)=>{if(j==0&&k==0)anchors.push({p:c[0],i:[0,0],o:V.sub(c[1],c[0]),c:isC1});else anchors[anchors.length-1].o=V.sub(c[1],c[0]);anchors.push({p:c[3],i:V.sub(c[2],c[3]),o:[0,0],c:false})});
anchors[anchors.length-1].c=isC1}
// 末尾の重複アンカー(始点と同一)を統合
if(anchors.length>1){const f=anchors[0],l=anchors.pop();f.i=l.i}
return anchors}
// ---- マーチングスクエア: アルファ(0..255)の等値線(iso)をサブピクセルで抽出。内部が左側になるループを返す
function contours(a,w,h,iso){const f=(x,y)=>x<0||y<0||x>=w||y>=h?0:a[y*w+x],E=new Map(),add=(k1,p1,k2,p2)=>{E.set(k1,{to:k2,p:p1,q:p2})};
// 辺ID: 水平辺 (x,y)-(x+1,y) -> 'h'+x+','+y ; 垂直辺 (x,y)-(x,y+1) -> 'v'+x+','+y
const pt=(id)=>{const t=id[0],[x,y]=id.slice(1).split(',').map(Number);if(t=='h'){const v0=f(x,y),v1=f(x+1,y),s=(iso-v0)/(v1-v0);return[x+s,y]}const v0=f(x,y),v1=f(x,y+1),s=(iso-v0)/(v1-v0);return[x,y+s]};
const segs=[];
for(let y=-1;y<h;y++)for(let x=-1;x<w;x++){const v=[f(x,y),f(x+1,y),f(x+1,y+1),f(x,y+1)],c=(v[0]>=iso?1:0)|(v[1]>=iso?2:0)|(v[2]>=iso?4:0)|(v[3]>=iso?8:0);if(c==0||c==15)continue;
const T='h'+x+','+y,R='v'+(x+1)+','+y,Bm='h'+x+','+(y+1),Lf='v'+x+','+y;// 上・右・下・左
const E_={1:[[Lf,T]],2:[[T,R]],3:[[Lf,R]],4:[[R,Bm]],6:[[T,Bm]],7:[[Lf,Bm]],8:[[Bm,Lf]],9:[[Bm,T]],11:[[Bm,R]],12:[[R,Lf]],13:[[R,T]],14:[[T,Lf]]};
if(c==5||c==10){const mid=(v[0]+v[1]+v[2]+v[3])/4>=iso;if(c==5)segs.push(mid?[Lf,Bm]:[Lf,T],mid?[R,T]:[R,Bm]);else segs.push(mid?[T,Lf]:[T,R],mid?[Bm,R]:[Bm,Lf]);continue}
for(const s of E_[c])segs.push(s)}
// 向き: 上の表は「内部が右」になっているので反転して「内部が左」へ
const nx=new Map();for(const[a_,b_]of segs){let l=nx.get(b_);if(!l)nx.set(b_,l=[]);l.push(a_)}
const out=[],used=new Set();const from=new Map();for(const[a_,b_]of segs){let l=from.get(b_);if(!l)from.set(b_,l=[]);l.push(a_)}
const P=new Map();const gp=id=>{let p=P.get(id);if(!p){p=pt(id);P.set(id,p)}return p};
const startKeys=[...from.keys()];for(const k0 of startKeys){while(from.get(k0)&&from.get(k0).length){let cur=k0;const loop=[];let guard=0;while(guard++<1e7){const l=from.get(cur);if(!l||!l.length)break;const nxt=l.pop();loop.push(gp(cur));cur=nxt;if(cur==k0){break}}
if(loop.length>=3)out.push(loop)}}
return out}
return{flattenCubic,area,region,normalize,offsetLoops,fitLoop,fitCub,contours,V,bzAt}})();

// ===== 文字のベクター化(フォントの輪郭を直接取得)・オフセットパス =====
const GENERIC=new Set(['serif','sans-serif','monospace','cursive','fantasy','system-ui','ui-serif','ui-sans-serif','ui-monospace','emoji','math','fangsong']);
const famList=css=>{const r=[];let cur='',q='';for(const ch of css+','){if(q){if(ch==q)q='';else cur+=ch}else if(ch=='"'||ch=="'")q=ch;else if(ch==','){if(cur.trim())r.push(cur.trim());cur=''}else cur+=ch}return r};
const FCACHE=new Map();let LOCALF=null,LOCALDENIED=false;
async function localFontList(){if(LOCALDENIED||!window.queryLocalFonts)return null;if(!LOCALF){try{LOCALF=await window.queryLocalFonts()}catch(e){LOCALDENIED=true;return null}}return LOCALF}
// フォントの実データ(輪郭)を取得。取得できなければ null(画像トレースに切り替える)
async function fontFor(css){for(const fam of famList(css||'sans-serif')){if(GENERIC.has(fam.toLowerCase()))break;const key=fam.toLowerCase();if(FCACHE.has(key)){const f=FCACHE.get(key);if(f)return f;continue}
let f=null;const e=fonts.find(x=>x.n==fam&&x.data);if(e){try{f=await FONTLIB.load(await(await fetch(e.data)).arrayBuffer(),0)}catch(err){f=null}}
if(!f){const L=await localFontList();if(L){const m=L.filter(x=>x.family.toLowerCase()==key||x.fullName.toLowerCase()==key);const pick=m.find(x=>x.style=='Regular')||m[0];if(pick){try{f=await FONTLIB.load(await(await pick.blob()).arrayBuffer(),{ps:pick.postscriptName})}catch(err){f=null}}}}
FCACHE.set(key,f);if(f)return f}return null}
const pathAnchors=p=>{const A=[{p:[p.x,p.y],i:[0,0],o:[0,0]}];for(const s of p.segs){const pv=A[A.length-1];if(s.t=='L')A.push({p:[s.x,s.y],i:[0,0],o:[0,0]});else{pv.o=[s.x1-pv.p[0],s.y1-pv.p[1]];A.push({p:[s.x,s.y],i:[s.x2-s.x,s.y2-s.y],o:[0,0]})}}const f=A[0],l=A[A.length-1];if(A.length>1&&Math.hypot(f.p[0]-l.p[0],f.p[1]-l.p[1])<1e-6){f.i=l.i;A.pop()}return A};
// 文字列→グリフ輪郭(テキスト中心基準のローカル座標、y下向き)。失敗(未収録の文字・複雑な文字組)は null
async function textOutlines(s){if(!s.tx||/[\u0590-\u08FF\u0900-\u0DFF\u0E00-\u0E7F\u1000-\u109F\u1780-\u17FF]/.test(s.tx))return null;const f=await fontFor(s.fn);if(!f)return null;const chars=[...s.tx],gids=chars.map(c=>f.gid(c.codePointAt(0)));if(chars.some((c,i)=>!gids[i]&&!/\s/.test(c)))return null;
g.font=`${s.fs}px ${s.fn||'sans-serif'}`;g.textBaseline='middle';g.textAlign='left';const W=t=>g.measureText(t).width,tot=W(s.tx),by=-g.measureText(s.tx).alphabeticBaseline,k=s.fs/f.upm,loops=[];let pre='';
for(let i=0;i<chars.length;i++){const ch=chars[i];pre+=ch;const pen=W(pre)-W(ch)-tot/2;if(gids[i]){const M=(x,y)=>[pen+x*k,by-y*k];for(const p of f.glyph(gids[i]))loops.push(pathAnchors(p).map(a=>({p:M(a.p[0],a.p[1]),i:[a.i[0]*k,-a.i[1]*k],o:[a.o[0]*k,-a.o[1]*k]})))}}
return loops.length?loops:null}
// 閉ループのアンカーごとに「角か」を判定(進入・退出の接線が約1°以上ずれていれば角)
function anchorSharp(A){const n=A.length,F=[];for(let k=0;k<n;k++){const a=A[k],pr=A[(k+n-1)%n],nx=A[(k+1)%n];let din=a.i[0]||a.i[1]?[-a.i[0],-a.i[1]]:null,dout=a.o[0]||a.o[1]?[a.o[0],a.o[1]]:null;
if(!din){const c=pr.o[0]||pr.o[1]?[pr.p[0]+pr.o[0],pr.p[1]+pr.o[1]]:pr.p;din=[a.p[0]-c[0],a.p[1]-c[1]];if(!din[0]&&!din[1])din=[a.p[0]-pr.p[0],a.p[1]-pr.p[1]]}
if(!dout){const c=nx.i[0]||nx.i[1]?[nx.p[0]+nx.i[0],nx.p[1]+nx.i[1]]:nx.p;dout=[c[0]-a.p[0],c[1]-a.p[1]];if(!dout[0]&&!dout[1])dout=[nx.p[0]-a.p[0],nx.p[1]-a.p[1]]}
const l1=Math.hypot(din[0],din[1]),l2=Math.hypot(dout[0],dout[1]);F.push(!l1||!l2||(din[0]*dout[0]+din[1]*dout[1])/(l1*l2)<.9998)}return F}
function anchorsPolyF(A,tol){const P=[],F=[],S=anchorSharp(A),n=A.length;for(let k=0;k<n;k++){const a=A[k],b=A[(k+1)%n],p0=a.p,p3=b.p;P.push(p0);F.push(S[k]);if(a.o[0]||a.o[1]||b.i[0]||b.i[1]){const T=[];GEO.flattenCubic(p0,[p0[0]+a.o[0],p0[1]+a.o[1]],[p3[0]+b.i[0],p3[1]+b.i[1]],p3,tol,T);T.pop();T.forEach(q=>{P.push(q);F.push(false)})}}return[P,F]}
// アンカー列(閉ループ)→多角形
function anchorsPoly(A,tol){const P=[],n=A.length;for(let k=0;k<n;k++){const a=A[k],b=A[(k+1)%n],p0=a.p,p3=b.p;if(!a.o[0]&&!a.o[1]&&!b.i[0]&&!b.i[1]){P.push(p0)}else{P.push(p0);const T=[];GEO.flattenCubic(p0,[p0[0]+a.o[0],p0[1]+a.o[1]],[p3[0]+b.i[0],p3[1]+b.i[1]],p3,tol,T);T.pop();P.push(...T)}}return P}
// 画像トレース(代替): 高解像度で描画し、サブピクセル輪郭 → 角を保ったベジェへあてはめ
function rasterOutlines(s,mode){const sc0=Math.max(1,Math.min(16,3000/Math.max(s.w+s.sw*2+8,s.h+s.sw*2+8)));const pad=Math.ceil(s.s?s.sw:0)+4,W=s.w+pad*2,H=s.h+pad*2;let sc=sc0;while(W*sc*H*sc>14e6&&sc>1)sc*=.8;
const cv=document.createElement('canvas');cv.width=Math.ceil(W*sc);cv.height=Math.ceil(H*sc);const x=cv.getContext('2d',{willReadFrequently:true});x.setTransform(sc,0,0,sc,0,0);
const base={...s,x:W/2,y:H/2,r:0};dsh(x,{...base,f:mode=='fill'?'#000':null,s:mode=='stroke'?'#000':null});
const d=x.getImageData(0,0,cv.width,cv.height).data,a=new Uint8Array(cv.width*cv.height);for(let i=0;i<a.length;i++)a[i]=d[i*4+3];
const out=[];for(const P of GEO.contours(a,cv.width,cv.height,127.5)){const A=GEO.fitLoop(P,.7,42,2.4);if(!A)continue;out.push(A.map(q=>({p:[(q.p[0]-W/2*sc)/sc,(q.p[1]-H/2*sc)/sc],i:[q.i[0]/sc,q.i[1]/sc],o:[q.o[0]/sc,q.o[1]/sc]})))}return out}
// アンカー列 → 'pd' 図形(ワールド座標。回転は座標に焼き込む)
function pdFromLoops(loops,T,TV,col,ex){const L=loops.map(l=>l.map(a=>({p:T(a.p),i:TV(a.i),o:TV(a.o)}))),xs=[],ys=[];
L.forEach(l=>{const n=l.length;for(let k=0;k<n;k++){const a=l[k],b=l[(k+1)%n];xs.push(a.p[0]);ys.push(a.p[1]);if(a.o[0]||a.o[1]||b.i[0]||b.i[1]){const B=[a.p,[a.p[0]+a.o[0],a.p[1]+a.o[1]],[b.p[0]+b.i[0],b.p[1]+b.i[1]],b.p];for(let t=1;t<12;t++){const q=GEO.bzAt(B,t/12);xs.push(q[0]);ys.push(q[1])}}}});
const x0=Math.min(...xs),x1=Math.max(...xs),y0=Math.min(...ys),y1=Math.max(...ys),cx=(x0+x1)/2,cy=(y0+y1)/2,w=Math.max(x1-x0,.01),h=Math.max(y1-y0,.01),f=(p)=>(p[0]-cx).toFixed(3)+' '+(p[1]-cy).toFixed(3);let d='';
L.forEach(l=>{const n=l.length;d+='M'+f(l[0].p);for(let k=0;k<n;k++){const a=l[k],b=l[(k+1)%n],z=!(a.o[0]||a.o[1]||b.i[0]||b.i[1]);if(k==n-1&&z){d+='z';continue}d+=z?'L'+f(b.p):'C'+f([a.p[0]+a.o[0],a.p[1]+a.o[1]])+' '+f([b.p[0]+b.i[0],b.p[1]+b.i[1]])+' '+f(b.p)}if(!/z$/.test(d))d+='z'});
return{t:'pd',d,w0:w,h0:h,w,h,x:cx,y:cy,r:0,f:col,s:null,sw:1,fr:'nonzero',...ex}}
// 文字 → ベクター図形。①フォントの輪郭を直接取得 ②取得できなければ高解像度の輪郭抽出+ベジェあてはめ
async function txtShapes(s){const co=Math.cos(s.r),si=Math.sin(s.r),mm=s.mx?-1:1,T=p=>[s.x+mm*p[0]*co-p[1]*si,s.y+mm*p[0]*si+p[1]*co],TV=v=>[mm*v[0]*co-v[1]*si,mm*v[0]*si+v[1]*co],out=[],g0=++gid+Date.now();let how='outline';
let fillL=null;if(s.f){fillL=await textOutlines(s);if(!fillL){how='trace';fillL=rasterOutlines(s,'fill')}}
if(fillL&&fillL.length)out.push(pdFromLoops(fillL,T,TV,s.f,{}));
if(s.s&&s.sw>0){let ring;if(how=='outline'||!s.f){const base=fillL||await textOutlines(s);if(base){const tol=Math.max(.02,s.fs*.0005),polys=base.map(l=>anchorsPoly(l,tol)),N=GEO.normalize(polys,'nonzero'),A=GEO.offsetLoops(N,s.sw/2,jn(s),10),B=GEO.offsetLoops(N,-s.sw/2,jn(s),10),R=GEO.region([...A.map(p=>({pts:p,set:0})),...B.map(p=>({pts:p,set:1}))],w=>w[0]>0&&w[1]<=0);ring=R.map(P=>GEO.fitLoop(P,tol*1.5,35)).filter(Boolean)}}
if(!ring)ring=rasterOutlines(s,'stroke');if(ring&&ring.length)out.push(pdFromLoops(ring,T,TV,s.s,{}))}
if(!out.length)throw Error('輪郭を取得できませんでした(空白のみ、またはこのフォントで描画できない文字)');
const[a,b,e,f]=ubox(out);if(out.length>1)out.forEach(o=>o.g=g0);if(s.nm)out[0].nm=s.nm;const Lst=out[out.length-1];Lst.ot={s:JSON.parse(JSON.stringify(s)),u:[e-a,f-b],o:[s.x-(a+e)/2,s.y-(b+f)/2]};out.how=how;return out}
async function t2p(list,noHist){const c=C(),L=list.filter(s=>s.t=='txt');if(!L.length)return;try{const out=[];for(const s of L)out.push(await txtShapes(s));if(!noHist)hist();L.forEach((s,i)=>{const k=c.sh.indexOf(s);if(k>=0)c.sh.splice(k,1,...out[i])});sel=out.flat();fin();const tr=out.filter(o=>o.how=='trace').length;if(tr)toast('この文字はフォントの輪郭データを取得できなかったため、高解像度の輪郭抽出で変換しました')}catch(e){alert('文字の図形化に失敗しました。元のテキストは保持されています。\n'+e.message)}}
function toast(t){let e=$('#toast');if(!e){e=document.createElement('div');e.id='toast';e.setAttribute('role','status');document.body.append(e)}e.textContent=t;e.className='show';clearTimeout(toast.t);toast.t=setTimeout(()=>e.className='',4200)}
// ===== オフセットパス =====
const OFS={open:false,dist:10,dir:'out',join:'round',keep:true,miter:4,prev:null,msg:'',busy:0};
const clone2=s=>JSON.parse(JSON.stringify(s,rep));
// 図形 → ワールド座標の多角形列 {polys, open:[...], rule}
// path図形のアンカーが「角」か(両端点・接線が不連続=角)
function ptSharp(t,a0,b0,cl,i){const n=b0-a0,l=i-a0;if(!cl&&(l==0||l==n-1))return true;const q=t.pts[i],pr=t.pts[a0+(l+n-1)%n],nx=t.pts[a0+(l+1)%n],w=t.w,h=t.h,H=(r,k)=>[(r[k]||0)*w,(r[k+1]||0)*h],P=r=>[r[0]*w,r[1]*h];
let din=H(q,2),dout=H(q,4);din=din[0]||din[1]?[-din[0],-din[1]]:null;dout=dout[0]||dout[1]?dout:null;const qp=P(q);
if(!din){const o=H(pr,4),pp=P(pr),c=o[0]||o[1]?[pp[0]+o[0],pp[1]+o[1]]:pp;din=[qp[0]-c[0],qp[1]-c[1]];if(!din[0]&&!din[1])din=[qp[0]-pp[0],qp[1]-pp[1]]}
if(!dout){const o=H(nx,2),np=P(nx),c=o[0]||o[1]?[np[0]+o[0],np[1]+o[1]]:np;dout=[c[0]-qp[0],c[1]-qp[1]];if(!dout[0]&&!dout[1])dout=[np[0]-qp[0],np[1]-qp[1]]}
const l1=Math.hypot(din[0],din[1]),l2=Math.hypot(dout[0],dout[1]);return!l1||!l2||(din[0]*dout[0]+din[1]*dout[1])/(l1*l2)<.9998}
// オフセット後の頂点→もとの図形の同じ位置の頂点が「角」だったか。もとに無い頂点(交差でできた点)は角として扱う
function sharpOracle(Ps,Fs){const cell=.05,M=new Map();Ps.forEach((P,k)=>P.forEach((p,i)=>{const kk=Math.floor(p[0]/cell)+','+Math.floor(p[1]/cell);let l=M.get(kk);if(!l)M.set(kk,l=[]);l.push([p[0],p[1],!!(Fs[k]&&Fs[k][i])])}));
return v=>{const cx=Math.floor(v[0]/cell),cy=Math.floor(v[1]/cell);let best=null,bd=.02;for(let a=-1;a<=1;a++)for(let b=-1;b<=1;b++){const l=M.get((cx+a)+','+(cy+b));if(l)for(const q of l){const d=Math.hypot(q[0]-v[0],q[1]-v[1]);if(d<bd){bd=d;best=q}}}return best?best[2]:true}}
async function shapeGeom(s){const tol=.01;let t;
if(s.t=='txt'){let L=await textOutlines(s);const co=Math.cos(s.r),si=Math.sin(s.r),mm=s.mx?-1:1,T=p=>[s.x+mm*p[0]*co-p[1]*si,s.y+mm*p[0]*si+p[1]*co],MO=a=>s.mx?a.slice().reverse():a;if(L){const PF=L.map(l=>anchorsPolyF(l,Math.max(tol,s.fs*.0005)));return{polys:PF.map(x=>MO(x[0].map(T))),fl:PF.map(x=>MO(x[1])),open:[],ofl:[],rule:'nonzero'}}L=rasterOutlines(s,'fill');{const PF=L.map(l=>anchorsPolyF(l,tol));return{polys:PF.map(x=>MO(x[0].map(T))),fl:PF.map(x=>MO(x[1])),open:[],ofl:[],rule:'nonzero'}}}
if(!['rect','ell','path','pd','line'].includes(s.t))return null;
if(s.t=='rect'&&s.rr>0){t={t:'pd',d:dOf(s),w0:s.w,h0:s.h,w:s.w,h:s.h,x:s.x,y:s.y,r:s.r};toBz(t)}else{t=clone2(s);if(!t.bz)toBz(t)}
const polys=[],open=[],fl=[],ofl=[];for(const[a0,b0,cl]of rng(t)){const P=[],F=[];const n=b0-a0;for(let i=0;i<(cl?n:n-1);i++){const A=t.pts[a0+i],B=t.pts[a0+(i+1)%n],p0=[A[0]*t.w,A[1]*t.h],p3=[B[0]*t.w,B[1]*t.h];P.push(l2w(t,p0[0],p0[1]));F.push(ptSharp(t,a0,b0,cl,a0+i));const Tt=[];GEO.flattenCubic(p0,[p0[0]+A[4]*t.w,p0[1]+A[5]*t.h],[p3[0]+B[2]*t.w,p3[1]+B[3]*t.h],p3,tol,Tt);Tt.pop();Tt.forEach(q=>{P.push(l2w(t,q[0],q[1]));F.push(false)})}
if(!cl){const e=t.pts[b0-1];P.push(l2w(t,e[0]*t.w,e[1]*t.h));F.push(true)}(cl?polys:open).push(P);(cl?fl:ofl).push(F)}
return{polys,open,fl,ofl,rule:t.cmp?(s.fr||'evenodd'):'nonzero'}}
const offDist=()=>OFS.dir=='in'?-OFS.dist:OFS.dist;
// オフセット結果(多角形)を計算。入力が複数ならそれぞれ別々に
async function offsetCompute(){const res=[];for(const s of sel){const G=await shapeGeom(s);if(!G){res.push({s,err:'この種類の図形は対象外です(画像・ビットマップ)'});continue}
const d=offDist();let loops=[];
if(G.polys.length){const N=GEO.normalize(G.polys,G.rule);loops=GEO.offsetLoops(N,d,OFS.join,OFS.miter,OFS.join=='orig'?sharpOracle(G.polys,G.fl):null)}
if(G.open.length){if(d>0){const dbl=G.open.map(P=>P.concat(P.slice(1,-1).reverse())),o=GEO.offsetLoops(dbl,d,OFS.join,OFS.miter,OFS.join=='orig'?sharpOracle(G.open,G.ofl):null);loops=loops.length?GEO.region([...loops.map(p=>({pts:p,set:0})),...o.map(p=>({pts:p,set:0}))],w=>w[0]>0):o}else if(!G.polys.length){res.push({s,err:'内側へのオフセットは閉じたパスだけに使えます'});continue}}
res.push({s,loops})}return res}
let ofsTok=0;async function offsetPreview(){if(!OFS.open)return;const tk=++ofsTok;if(!sel.length||C().k!='v'){OFS.prev=null;OFS.msg='図形を選択してください';ofsUI();draw();return}
OFS.busy=1;ofsUI();let r;try{r=await offsetCompute()}catch(e){if(tk!=ofsTok)return;OFS.prev=null;OFS.msg='計算に失敗しました: '+e.message;OFS.busy=0;ofsUI();draw();return}if(tk!=ofsTok)return;OFS.busy=0;OFS.prev=r;const ok=r.filter(x=>x.loops&&x.loops.length).length,er=r.find(x=>x.err);OFS.msg=ok?'プレビュー: '+ok+'個の図形':(er?er.err:'結果が空になりました(距離が大きすぎます)');ofsUI();draw()}
let ofsT=0;const ofsSoon=()=>{cancelAnimationFrame(ofsT);ofsT=requestAnimationFrame(()=>setTimeout(offsetPreview,0))};
function drawOfs(S){if(!OFS.open||!OFS.prev)return;g.save();g.lineWidth=1.5;g.strokeStyle='#e8590c';g.fillStyle='#e8590c22';g.setLineDash([5,3]);for(const r of OFS.prev){if(!r.loops)continue;g.beginPath();for(const P of r.loops){P.forEach((p,i)=>{const q=S(p[0],p[1]);i?g.lineTo(q[0],q[1]):g.moveTo(q[0],q[1])});g.closePath()}g.fill('nonzero');g.stroke()}g.restore()}
// アンカー列→パス図形(編集可能なベジェ。直線区間は直線として保持)
function straighten(A,tol){const n=A.length;for(let k=0;k<n;k++){const a=A[k],b=A[(k+1)%n],dx=b.p[0]-a.p[0],dy=b.p[1]-a.p[1],L=Math.hypot(dx,dy)||1,c1=[a.o[0],a.o[1]],c2=[b.p[0]+b.i[0]-a.p[0],b.p[1]+b.i[1]-a.p[1]],dist=c=>Math.abs(c[0]*dy-c[1]*dx)/L;if(dist(c1)<tol&&dist(c2)<tol&&(c1[0]*dx+c1[1]*dy)>=-tol*L&&(c2[0]*dx+c2[1]*dy)<=(dx*dx+dy*dy)+tol*L){a.o=[0,0];b.i=[0,0]}}return A}
// ---- オフセット結果(多角形ループ)→ 編集可能なベジェ。
// プレビューと同じ輪郭になることを検証してから採用する。許容誤差(OFS_TOL px)を超える近似は採用せず、
// 元の輪郭点をそのまま頂点として保持した(=プレビューと完全一致する)パスに切り替える。
const OFS_TOL=.03,OFS_REPORT={fit:0,poly:0,maxDev:0};
function ofsClean(P0){const P=[];for(const p of P0){const q=P[P.length-1];if(!q||Math.hypot(p[0]-q[0],p[1]-q[1])>1e-9)P.push([p[0],p[1]])}if(P.length>1&&Math.hypot(P[0][0]-P[P.length-1][0],P[0][1]-P[P.length-1][1])<1e-9)P.pop();
let ch=true;while(ch&&P.length>3){ch=false;for(let k=0;k<P.length;k++){const a=P[(k+P.length-1)%P.length],b=P[k],c=P[(k+1)%P.length],dx=c[0]-a[0],dy=c[1]-a[1],L=Math.hypot(dx,dy);if(L>0&&Math.abs((b[0]-a[0])*dy-(b[1]-a[1])*dx)/L<1e-7&&(b[0]-a[0])*dx+(b[1]-a[1])*dy>0&&(c[0]-b[0])*dx+(c[1]-b[1])*dy>0){P.splice(k,1);ch=true;break}}}// 厳密に一直線上の中間点だけ除去
return P}
function ofsFlat(A,tol){const out=[],n=A.length;for(let k=0;k<n;k++){const a=A[k],b=A[(k+1)%n];out.push(a.p);if(a.o[0]||a.o[1]||b.i[0]||b.i[1]){const T=[];GEO.flattenCubic(a.p,[a.p[0]+a.o[0],a.p[1]+a.o[1]],[b.p[0]+b.i[0],b.p[1]+b.i[1]],b.p,tol,T);T.pop();out.push(...T)}}return out}
// S(閉多角形)の輪郭上のすべての点が T(閉多角形)から tol 以内にあるか。戻り値: 最大距離(tol を超えたら打ち切って tol より大きい値)
function ofsDev(S,T,tol){const n=T.length;let tot=0;for(let i=0;i<n;i++){const a=T[i],b=T[(i+1)%n];tot+=Math.hypot(b[0]-a[0],b[1]-a[1])}const cell=Math.max(tol*4,tot/n,1e-3),G=new Map(),K=(x,y)=>x+','+y;
for(let i=0;i<n;i++){const a=T[i],b=T[(i+1)%n],L=Math.hypot(b[0]-a[0],b[1]-a[1]),m=Math.max(1,Math.ceil(L/(cell/2))),seen=new Set();for(let k=0;k<=m;k++){const x=a[0]+(b[0]-a[0])*k/m,y=a[1]+(b[1]-a[1])*k/m,cx=Math.floor(x/cell),cy=Math.floor(y/cell);for(let u=-1;u<=1;u++)for(let v=-1;v<=1;v++){const key=K(cx+u,cy+v);if(seen.has(key))continue;seen.add(key);let l=G.get(key);if(!l)G.set(key,l=[]);l.push(i)}}}
const dseg=(p,a,b)=>{const dx=b[0]-a[0],dy=b[1]-a[1],L2=dx*dx+dy*dy;let t=L2?((p[0]-a[0])*dx+(p[1]-a[1])*dy)/L2:0;t=Math.max(0,Math.min(1,t));return Math.hypot(p[0]-a[0]-t*dx,p[1]-a[1]-t*dy)};
let ts=0;const sn=S.length;for(let i=0;i<sn;i++){const a=S[i],b=S[(i+1)%sn];ts+=Math.hypot(b[0]-a[0],b[1]-a[1])}const step=Math.max(.25,ts/40000);let worst=0;
for(let i=0;i<sn;i++){const a=S[i],b=S[(i+1)%sn],L=Math.hypot(b[0]-a[0],b[1]-a[1]),m=Math.max(1,Math.ceil(L/step));for(let k=0;k<m;k++){const p=[a[0]+(b[0]-a[0])*k/m,a[1]+(b[1]-a[1])*k/m],l=G.get(K(Math.floor(p[0]/cell),Math.floor(p[1]/cell)));let d=1e18;if(l)for(const j of l){const dd=dseg(p,T[j],T[(j+1)%n]);if(dd<d)d=dd;if(d<=tol*.02)break}if(d>tol)return d;if(d>worst)worst=d}}return worst}
function ofsSame(A,P,tol){const F=ofsFlat(A,tol*.1),d1=ofsDev(P,F,tol);if(d1>tol)return -1;const d2=ofsDev(F,P,tol);if(d2>tol)return -1;return Math.max(d1,d2)}
function ofsCurved(a,b){return a.o[0]||a.o[1]||b.i[0]||b.i[1]}
// なめらかな点を取り除いて、隣り合う2本の曲線を1本にまとめられるだけまとめる(パス数を減らす)
function ofsMerge(A,tolM){let ch=true,guard=0;while(ch&&A.length>3&&guard++<2000){ch=false;for(let k=0;k<A.length&&A.length>3;k++){const n=A.length,a=A[(k+n-1)%n],m=A[k],b=A[(k+1)%n],l1=Math.hypot(m.i[0],m.i[1]),l2=Math.hypot(m.o[0],m.o[1]);
if(!l1||!l2||Math.abs(m.i[0]*m.o[1]-m.i[1]*m.o[0])>1e-3*l1*l2||m.i[0]*m.o[0]+m.i[1]*m.o[1]>0||!ofsCurved(a,m)||!ofsCurved(m,b))continue;
const T1=[],T2=[];GEO.flattenCubic(a.p,[a.p[0]+a.o[0],a.p[1]+a.o[1]],[m.p[0]+m.i[0],m.p[1]+m.i[1]],m.p,tolM*.2,T1);GEO.flattenCubic(m.p,[m.p[0]+m.o[0],m.p[1]+m.o[1]],[b.p[0]+b.i[0],b.p[1]+b.i[1]],b.p,tolM*.2,T2);
const pts=T1.concat(T2.slice(1)),t1=GEO.V.norm(a.o),t2=GEO.V.norm(b.i);let r;try{r=GEO.fitCub(pts,t1,t2,tolM)}catch(e){continue}if(!r||r.length!=1)continue;const c=r[0];
a.o=[c[1][0]-c[0][0],c[1][1]-c[0][1]];b.i=[c[2][0]-c[3][0],c[2][1]-c[3][1]];A.splice(k,1);ch=true;break}}return A}
const ofsCopy=A=>A.map(a=>({p:[a.p[0],a.p[1]],i:[a.i[0],a.i[1]],o:[a.o[0],a.o[1]]}));
function loopToAnchors(P0){const P=ofsClean(P0);if(P.length<3)return null;
/* 許容誤差の緩い順(=アンカー数が少ない順)に試す。どの段階も「元の輪郭から vt 以内」であることを検証して採用 */
for(const[tol,vt,deg]of[[.06,.12,12],[.03,.06,12],[.015,.03,12],[.015,.03,6],[.12,.24,12]]){let A=null;try{A=GEO.fitLoop(P,tol,deg,undefined,true)}catch(e){A=null}
if(!A||A.length<3||A.length>=P.length)continue;straighten(A,vt*.1);{const B=ofsMerge(ofsCopy(A),vt*.3);straighten(B,vt*.1);const d2=ofsSame(B,P,vt);if(d2>=0){OFS_REPORT.fit++;OFS_REPORT.maxDev=Math.max(OFS_REPORT.maxDev,d2);return B}}const d=ofsSame(A,P,vt);if(d>=0){OFS_REPORT.fit++;OFS_REPORT.maxDev=Math.max(OFS_REPORT.maxDev,d);return A}}
OFS_REPORT.poly++;return P.map(p=>({p,i:[0,0],o:[0,0]}))}
function loopsToShape(loops,src){const pts=[];OFS_REPORT.fit=0;OFS_REPORT.poly=0;OFS_REPORT.maxDev=0;loops.forEach(P=>{const A=loopToAnchors(P);if(!A||A.length<3)return;A.forEach((a,j)=>{const m=Math.hypot(a.i[0],a.i[1])*Math.hypot(a.o[0],a.o[1]),sm=m>0&&Math.abs(a.i[0]*a.o[1]-a.i[1]*a.o[0])<1e-3*m&&a.i[0]*a.o[0]+a.i[1]*a.o[1]<0?1:0;pts.push([a.p[0],a.p[1],a.i[0],a.i[1],a.o[0],a.o[1],sm,j==0?1:0])})});if(!pts.length)return null;
const o={t:'path',bz:1,cmp:1,cl:1,x:0,y:0,r:0,w:1,h:1,pts,f:src.t=='line'?src.s:(src.f==null?null:src.f),s:src.s||null,sw:src.sw||1,fr:'nonzero',...(src.sj?{sj:src.sj}:{})};if(src.t=='line'||(src.t=='path'&&!src.cl&&!src.f))o.f=src.s;if(src.g)o.g=src.g;renorm(o);return o}
async function offsetApply(){if(!sel.length)return;await offsetPreview();const R=OFS.prev;if(!R||!R.some(x=>x.loops&&x.loops.length))return;const c=C();hist();const made=[];
for(const r of R){if(!r.loops||!r.loops.length)continue;const o=loopsToShape(r.loops,r.s.t=='txt'?{f:r.s.f,s:r.s.s,sw:r.s.sw,sj:r.s.sj}:r.s);if(!o)continue;if(r.s.t=='txt'&&!r.s.f)o.f=r.s.s;const k=c.sh.indexOf(r.s);if(OFS.keep)c.sh.splice(k+1,0,o);else c.sh.splice(k,1,o);made.push(o)}
if(!made.length){return}sel=made;OFS.prev=null;fin();OFS.msg='オフセットパスを作成しました('+made.length+'個)';ofsUI();ofsSoon()}
function ofsUI(){const p=$('#ofp');if(!p)return;$('#ofd').value!=String(OFS.dist)&&document.activeElement!==$('#ofd')&&($('#ofd').value=OFS.dist);if(document.activeElement!==$('#ofr'))$('#ofr').value=Math.min(+$('#ofr').max,OFS.dist);$('#ofi').className=OFS.dir=='in'?'':'on';$('#ofo').className=OFS.dir=='out'?'on':'';$('#ofi').setAttribute('aria-pressed',OFS.dir=='in');$('#ofo').setAttribute('aria-pressed',OFS.dir=='out');$('#ofj').value=OFS.join;$('#ofmw').hidden=!(OFS.join=='miter'||OFS.join=='orig');$('#ofk').checked=OFS.keep;$('#ofm').textContent=OFS.busy?'計算中…':OFS.msg;$('#ofa').disabled=OFS.busy||!OFS.prev||!OFS.prev.some(x=>x.loops&&x.loops.length)}
(()=>{const css=document.createElement('style');css.textContent=`#toast{position:fixed;left:50%;bottom:70px;transform:translateX(-50%);background:#333c;color:#fff;padding:8px 14px;border-radius:8px;font-size:13px;opacity:0;pointer-events:none;transition:opacity .2s;z-index:80;max-width:90vw}#toast.show{opacity:1}
#ofp{position:absolute;left:6px;bottom:6px;width:min(360px,calc(100% - 12px));background:#fff;border:1px solid #c9d0d9;border-radius:10px;padding:8px;box-shadow:0 2px 10px #0003;z-index:7;display:flex;flex-direction:column;gap:6px}#ofp[hidden]{display:none}#ofp .rw{display:flex;align-items:center;gap:6px;flex-wrap:wrap;font-size:13px}#ofp button{min-height:44px;min-width:0;padding:0 10px;font-size:13px;flex-direction:row}#ofp input[type=number]{width:76px;min-height:40px}#ofp input[type=range]{flex:1;min-width:120px;min-height:40px}#ofp select{min-height:40px;font-size:13px}#ofm{font-size:12px;color:#575e75;min-height:16px}#ofp h4{margin:0;font-size:13px}`;document.head.append(css);
const p=document.createElement('div');p.id='ofp';p.hidden=true;p.setAttribute('role','dialog');p.setAttribute('aria-label','オフセットパス');
p.innerHTML=`<div class="rw"><h4 style="flex:1">オフセットパス</h4><button id="ofx" type="button" title="閉じる(プレビューを消します)">閉じる</button></div>
<div class="rw"><button id="ofo" type="button" title="輪郭を外側へ広げます">外側に拡張</button><button id="ofi" type="button" title="輪郭を内側へ縮めます">内側に縮小</button></div>
<div class="rw"><label>距離<input type="number" id="ofd" min="0" step="0.5" value="10" inputmode="decimal"> px</label><input type="hidden" id="ofr" min="0" max="100" step="0.5" value="10"></div>
<div class="rw"><label>角<select id="ofj"><option value="round">ラウンド(丸める)</option><option value="miter">マイター(尖らせる)</option><option value="bevel">ベベル(斜めに切る)</option><option value="orig">元の角を維持(丸は丸・角は角のまま)</option></select></label><label id="ofmw" hidden>制限<input type="number" id="ofl" min="1" step="0.5" value="4"></label></div>
<div class="rw"><label><input type="checkbox" id="ofk" checked> 元の図形を残す</label><span style="font-size:11px;color:#6b7390">(OFFで置き換え)</span></div>
<div id="ofm" aria-live="polite"></div><div class="rw"><button id="ofa" type="button" title="プレビューの形でパスを作成します" style="flex:1;background:#855cd6;color:#fff;border-color:#855cd6">適用</button></div>`;
$('#main').append(p);const setD=v=>{OFS.dist=Math.max(0,isFinite(v)?v:0);ofsUI();ofsSoon()};
$('#ofd').addEventListener('input',e=>{const v=parseFloat(e.target.value);if(isFinite(v)){OFS.dist=Math.max(0,v);$('#ofr').value=Math.min(+$('#ofr').max,OFS.dist);ofsSoon()}});$('#ofr').addEventListener('input',e=>{OFS.dist=+e.target.value;$('#ofd').value=OFS.dist;ofsSoon()});
$('#ofo').onclick=()=>{OFS.dir='out';ofsUI();ofsSoon()};$('#ofi').onclick=()=>{OFS.dir='in';ofsUI();ofsSoon()};$('#ofj').onchange=e=>{OFS.join=e.target.value;ofsUI();ofsSoon()};$('#ofl').oninput=e=>{OFS.miter=Math.max(1,+e.target.value||4);ofsSoon()};$('#ofk').onchange=e=>{OFS.keep=e.target.checked};
$('#ofa').onclick=()=>offsetApply();
const ob=()=>$('#ofb')||{classList:{add(){},remove(){},toggle(){}}};const close=()=>{OFS.open=false;OFS.prev=null;p.hidden=true;ob().classList.remove('on');draw()};$('#ofx').onclick=close;
window.ofsToggle=()=>{OFS.open=!OFS.open;p.hidden=!OFS.open;ob().classList.toggle('on',OFS.open);if(OFS.open){ofsUI();ofsSoon()}else{OFS.prev=null;draw()}};window.ofsClose=close})();


$('#t2p').onclick=()=>t2p(sel);
$('#p2t').onclick=()=>{const c=C(),b=sel[0];if(!b)return;const L=b.g?c.sh.filter(q=>q.g==b.g):[b],oq=L.find(q=>q.ot);if(!oq)return;const o=oq.ot,[a,y0,e,f]=ubox(L),k=Math.sqrt(((e-a)*(f-y0))/(o.u[0]*o.u[1]))||1,dr=b.r,co=Math.cos(dr),si=Math.sin(dr),t=JSON.parse(JSON.stringify(o.s));
t.fs*=k;t.sw=(t.sw||1)*k;tm(t);t.x=(a+e)/2+(o.o[0]*co-o.o[1]*si)*k;t.y=(y0+f)/2+(o.o[0]*si+o.o[1]*co)*k;t.r=(o.s.r||0)+dr;hist();c.sh.splice(c.sh.indexOf(L[0]),1,t);c.sh=c.sh.filter(q=>q===t||!L.includes(q));sel=[t];fin()};
// --- B. PNGのベクター化: 色数削減→色ごとの領域マスク→輪郭トレース。下の層ほど広く重ね、色の隙間を作らない
function quant(d,n,K){const B=new Map(),key=j=>(d[j]>>3)<<10|(d[j+1]>>3)<<5|d[j+2]>>3;for(let i=0;i<n;i++){const j=i*4;if(d[j+3]<128)continue;const k=key(j);let b=B.get(k);if(!b)B.set(k,b={n:0,r:0,g:0,b:0});b.n++;b.r+=d[j];b.g+=d[j+1];b.b+=d[j+2]}
const L=[...B.values()].sort((a,b)=>b.n-a.n).map(b=>[b.r/b.n,b.g/b.n,b.b/b.n]),P=[];for(let th=56;P.length<Math.min(K,L.length)&&th>=0;th-=14)for(const c of L){if(P.length>=K)break;if(!P.includes(c)&&P.every(p=>(p[0]-c[0])**2+(p[1]-c[1])**2+(p[2]-c[2])**2>th*th))P.push(c)}
if(!P.length)return{cols:[]};const idx=new Int16Array(n).fill(-1),ca=new Map(),S=P.map(()=>[0,0,0,0]);
for(let i=0;i<n;i++){const j=i*4;if(d[j+3]<128)continue;const k=key(j);let m=ca.get(k);if(m===undefined){let bd=1e9;m=0;P.forEach((p,t)=>{const e=(p[0]-d[j])**2+(p[1]-d[j+1])**2+(p[2]-d[j+2])**2;if(e<bd){bd=e;m=t}});ca.set(k,m)}idx[i]=m;const s=S[m];s[0]+=d[j];s[1]+=d[j+1];s[2]+=d[j+2];s[3]++}
const ord=S.map((s,i)=>i).filter(i=>S[i][3]).sort((a,b)=>S[b][3]-S[a][3]),rk=[];ord.forEach((o,i)=>rk[o]=i);for(let i=0;i<n;i++)if(idx[i]>=0)idx[i]=rk[idx[i]];
return{idx,cols:ord.map(o=>'#'+[0,1,2].map(t=>Math.round(S[o][t]/S[o][3]).toString(16).padStart(2,'0')).join(''))}}
async function vecPNG(im,o,P,X){const nw=im.naturalWidth,nh=im.naturalHeight,k=Math.min(1,o.max/Math.max(nw,nh)),w=Math.max(1,Math.round(nw*k)),h=Math.max(1,Math.round(nh*k)),cv=document.createElement('canvas');cv.width=w;cv.height=h;const x=cv.getContext('2d',{willReadFrequently:true});x.drawImage(im,0,0,w,h);const d=x.getImageData(0,0,w,h).data,n=w*h;
P('色を解析中…');await tick();const q=quant(d,n,o.K);if(!q.cols.length)throw Error('不透明な部分がありません(完全に透明な画像)');
const T=p=>[(o.c.w-nw)/2+p[0]*nw/w,(o.c.h-nh)/2+p[1]*nh/h],out=[];
for(let r=0;r<q.cols.length;r++){if(X())return null;P(`輪郭を抽出中 ${r+1}/${q.cols.length}色`);await tick();const m=new Uint8Array(n);for(let i=0;i<n;i++)m[i]=q.idx[i]>=r;const B=traceLoops(m,w,h,o.eps,o.minA);if(B.length)out.push(mkPath(B,T,q.cols[r],{}))}
if(!out.length)throw Error('図形を生成できませんでした(ノイズ除去が強すぎる可能性)');const g=++gid+Date.now();out.forEach((s,i)=>{s.g=g;s.nm='PNG色'+(i+1)});return out}
function pngDlg(f){const c=C(),D=document.createElement('div');D.className='dlg';D.style.cssText='background:none;pointer-events:none;align-items:flex-end';
D.innerHTML=`<div style="pointer-events:auto;box-shadow:0 2px 12px #0005"><b>PNGの読み込み方法</b><label>ベクター図形に変換する(初期値:OFF)<input type="checkbox" id="pv"></label><div id="po" hidden>${[['pk','色数',2,32,12],['pm','精度(最大px)',128,1024,400],['pe','なめらかさ',3,40,12],['pn','ノイズ除去(面積px)',0,60,4]].map(a=>`<label>${a[1]}<input type="number" id="${a[0]}" min="${a[2]}" max="${a[3]}" step="1" value="${a[4]}" inputmode="numeric" data-clamp="1"><output hidden></output></label>`).join('')}</div><small id="pst">OFFのときは従来どおりビットマップ/画像として読み込みます。変換は完全一致ではなく、半透明はしきい値で透明/不透明に分けます。</small><span class="grp"><button data-x>取り消し</button><button id="pre" hidden>再変換</button><button id="pgo" class="on">読み込む</button></span></div>`;
document.body.append(D);const $$=i=>D.querySelector('#'+i);let img=new Image,ph=0,hs=0,added=[],cancel=false;img.src=URL.createObjectURL(f);
const outs=()=>D.querySelectorAll('output').forEach(o=>o.textContent=o.previousSibling.value);outs();D.oninput=outs;
const clear=()=>{C().sh=C().sh.filter(s=>!added.includes(s));added=[];draw();thumbs()},lab=()=>{$$('po').hidden=!$$('pv').checked;$$('pgo').textContent=$$('pv').checked?'変換して追加':'読み込む'};$$('pv').onchange=lab;
const end=()=>{URL.revokeObjectURL(img.src);D.remove()};
D.querySelector('[data-x]').onclick=()=>{cancel=true;if(ph==2||hs){clear();if(hs)c.u.pop()}end()};
const run=async()=>{cancel=false;ph=1;clear();$$('pgo').textContent='中断';$$('pre').hidden=true;try{if(!hs){hist();hs=1;grow(c,img.naturalWidth,img.naturalHeight)}
const sh=await vecPNG(img,{K:+$$('pk').value,max:+$$('pm').value,eps:+$$('pe').value/10,minA:+$$('pn').value,c},m=>$$('pst').textContent=m,()=>cancel);
if(!sh){$$('pst').textContent='中断しました。設定を変えて再度実行できます。';ph=0;lab();return}c.sh.push(...sh);added=sh;draw();thumbs();ph=2;$$('pst').textContent=`変換しました: 図形${sh.length}個(色ごと)・パス${sh.reduce((a,s)=>a+(s.d.match(/M/g)||[]).length,0)}本。よければ「完了」、設定を変えるなら「再変換」。`;$$('pgo').textContent='完了';$$('pre').hidden=false}
catch(e){ph=0;lab();$$('pst').textContent='変換に失敗しました: '+e.message+'(元のデータは変更されていません)'}};
$$('pre').onclick=run;$$('pgo').onclick=()=>{if(ph==1)cancel=true;else if(ph==2){sel=added;tool=tool;fin();end()}else if(!$$('pv').checked){end();$('#imp').onchange({target:{files:[f],value:''},__s:1})}else run()}}

// ===== プレビュー(全体 / アニメーション)。編集データ・編集画面のズームには一切触れない =====
function cbounds(cl){let a=0,b=0,e=1,f=1;cl.forEach((c,i)=>{let x0=0,y0=0,x1=c.w/RS(c),y1=c.h/RS(c);if(c.k=='v'){const L=c.sh.filter(s=>!s.hid);if(L.length){const u=ubox(L);x0=Math.min(x0,u[0]);y0=Math.min(y0,u[1]);x1=Math.max(x1,u[2]);y1=Math.max(y1,u[3])}}
if(!i){a=x0;b=y0;e=x1;f=y1}else{a=Math.min(a,x0);b=Math.min(b,y0);e=Math.max(e,x1);f=Math.max(f,y1)}});return[a,b,e,f]}
function paintPrev(cvs,c,B,zm,px,py){const d=devicePixelRatio||1,W=cvs.clientWidth,H=cvs.clientHeight;if(cvs.width!=Math.round(W*d)||cvs.height!=Math.round(H*d)){cvs.width=Math.round(W*d);cvs.height=Math.round(H*d)}
const x=cvs.getContext('2d'),bw=B[2]-B[0],bh=B[3]-B[1],k=Math.min(W/bw,H/bh)*.94*zm;x.setTransform(d,0,0,d,0,0);x.clearRect(0,0,W,H);x.fillStyle='#fff';x.fillRect(0,0,W,H);x.fillStyle='#e3e8ef';const q=12;for(let i=0;i*q<W;i++)for(let j=0;j*q<H;j++)if((i+j)&1)x.fillRect(i*q,j*q,q,q);
x.save();x.translate(W/2+px,H/2+py);x.scale(k,k);x.translate(-(B[0]+bw/2),-(B[1]+bh/2));{const R=RS(c);x.imageSmoothingEnabled=(c.k=='b'&&!$('#aa').checked)?false:k/R<2;x.scale(1/R,1/R)}dc(x,c);x.restore();
x.strokeStyle='#855cd688';x.setLineDash([4,3]);x.strokeRect(W/2+px+(0-(B[0]+bw/2))*k,H/2+py+(0-(B[1]+bh/2))*k,c.w/RS(c)*k,c.h/RS(c)*k)}
function openPrev(){if(cs[ci].k=='b')bcommit();const D=document.createElement('div');D.className='dlg';let mode=0,zm=1,px=0,py=0,fr=0,tm_=0,play=0,dir=1;
const opt=cs.map((c,i)=>`<option value="${i}">${i+1}: ${esc(c.n)}</option>`).join('');
D.innerHTML=`<div role="dialog" aria-label="プレビュー" style="width:min(760px,calc(100vw - 12px))"><span class="grp"><button id="pm0" class="on">全体表示</button><button id="pm1">アニメーション</button><span class="fill"></span><button data-x>閉じる</button></span>
<canvas id="pc" style="width:100%;height:min(48vh,380px);border:1px solid #c9d0d9;border-radius:8px;touch-action:none"></canvas>
<span class="grp" id="pz"><button id="pzo" aria-label="縮小">−</button><button id="pzi" aria-label="拡大">＋</button><button id="pzf">全体に戻す</button><output id="pzv">100%</output></span>
<div id="pa" hidden><label>開始<select id="pas">${opt}</select></label><label>終了<select id="pae">${opt}</select></label>
<label>表示時間(ミリ秒/枚)<span><input type="number" id="pms" min="20" max="5000" step="10" value="200" style="width:84px"> <select id="ppre"><option value="">選択</option><option>100</option><option>200</option><option>500</option><option>1000</option></select></span></label>
<label>ループ再生<input type="checkbox" id="plp" checked></label><span class="grp"><button id="ppl" class="on">▶ 再生</button><button id="ppa">⏸ 一時停止</button><button id="pst">■ 停止</button></span></div><small id="pin"></small></div>`;
document.body.append(D);const $$=i=>D.querySelector('#'+i),cvs=$$('pc'),rng=()=>{let a=+$$('pas').value,b=+$$('pae').value;dir=a<=b?1:-1;const L=[];for(let i=a;i!=b+dir;i+=dir)L.push(i);return L};
$$('pas').value=ci;$$('pae').value=Math.min(cs.length-1,ci+Math.max(0,Math.min(cs.length-1,4)));
const bc_={k:''},bnd=L=>{const k=L.join(',')+'|'+ONG+'|'+cs.length;if(bc_.k!=k){bc_.k=k;bc_.v=cbounds(L.map(i=>cs[i]))}return bc_.v},info=()=>{if(!mode){$$('pin').textContent=`${ci+1}/${cs.length}: ${cs[ci].n}(編集中の内容を表示。点線は${+(cs[ci].w/RS(cs[ci])).toFixed(1)}×${+(cs[ci].h/RS(cs[ci])).toFixed(1)}の枠)`;return}const L=rng();$$('pin').textContent=`${fr+1}/${L.length}枚目 — コスチューム${L[fr]+1}「${cs[L[fr]].n}」 / ${(+$$('pms').value/1000).toFixed(2)}秒/枚${dir<0?' / 逆順再生':''}${play?' / 再生中':''}`},
show=()=>{if(!mode){paintPrev(cvs,cs[ci],cbounds([cs[ci]]),zm,px,py)}else{const L=rng();fr=Math.min(fr,L.length-1);paintPrev(cvs,cs[L[fr]],bnd(L),zm,px,py)}$$('pzv').textContent=Math.round(zm*100)+'%';info()},
stop=()=>{clearTimeout(tm_);play=0},tick_=()=>{if(!play)return;const L=rng();if(fr+1<L.length)fr++;else if($$('plp').checked)fr=0;else{play=0;show();return}show();tm_=setTimeout(tick_,Math.max(20,+$$('pms').value||200))},
setM=m=>{mode=m;stop();$$('pm0').classList.toggle('on',!m);$$('pm1').classList.toggle('on',!!m);$$('pa').hidden=!m;show()};
$$('pm0').onclick=()=>setM(0);$$('pm1').onclick=()=>setM(1);
$$('pzi').onclick=()=>{zm=Math.min(16,zm*1.4);show()};$$('pzo').onclick=()=>{zm=Math.max(.2,zm/1.4);show()};$$('pzf').onclick=()=>{zm=1;px=py=0;show()};
cvs.onwheel=e=>{e.preventDefault();zm=Math.min(16,Math.max(.2,zm*(e.deltaY<0?1.15:1/1.15)));show()};
/* ドラッグで移動、2本指でピンチ拡大縮小(全体表示・アニメーション共通) */
const PT=new Map();let dg=null,pn=null;const pinS=()=>{const a=[...PT.values()];return[Math.hypot(a[0][0]-a[1][0],a[0][1]-a[1][1])||1,(a[0][0]+a[1][0])/2,(a[0][1]+a[1][1])/2]};
cvs.onpointerdown=e=>{PT.set(e.pointerId,[e.clientX,e.clientY]);cvs.setPointerCapture(e.pointerId);if(PT.size==1){dg=[e.clientX,e.clientY,px,py];pn=null}else if(PT.size==2){dg=null;pn={s:pinS(),zm,px,py}}};
cvs.onpointermove=e=>{if(!PT.has(e.pointerId))return;PT.set(e.pointerId,[e.clientX,e.clientY]);
if(PT.size>=2&&pn){const s=pinS(),r=cvs.getBoundingClientRect(),k=Math.min(16,Math.max(.2,pn.zm*s[0]/pn.s[0])),f=k/pn.zm,cx=pn.s[1]-r.left-r.width/2,cy=pn.s[2]-r.top-r.height/2;zm=k;px=(s[1]-pn.s[1])+cx*(1-f)+pn.px*f;py=(s[2]-pn.s[2])+cy*(1-f)+pn.py*f;show()}
else if(dg){px=dg[2]+e.clientX-dg[0];py=dg[3]+e.clientY-dg[1];show()}};
cvs.onpointerup=cvs.onpointercancel=e=>{PT.delete(e.pointerId);pn=null;dg=PT.size==1?(a=>[a[0],a[1],px,py])([...PT.values()][0]):null};
$$('ppl').onclick=()=>{stop();play=1;if(!rng().length)return;tm_=setTimeout(tick_,Math.max(20,+$$('pms').value||200));show()};$$('ppa').onclick=()=>{stop();show()};$$('pst').onclick=()=>{stop();fr=0;show()};
$$('ppre').onchange=e=>{if(e.target.value){$$('pms').value=e.target.value;show()}};['pas','pae','pms','plp'].forEach(i=>$$(i).onchange=()=>{if(i=='pas'||i=='pae')fr=0;show()});
D.querySelector('[data-x]').onclick=()=>{stop();removeEventListener('resize',show);D.remove()};addEventListener('resize',show);show()}
$('#pvw').onclick=openPrev;

// ===== UI再配置: Scratch風メニューバー + 上部ツール =====
(()=>{const T=$('#top'),M=$('#mbar'),mkG=(ids,id)=>{const g=document.createElement('span');g.className='grp';if(id)g.id=id;ids.forEach(i=>{const e=$('#'+i);g.append(e);const n=e.nextElementSibling;if(n&&n.tagName=='INPUT'&&n.type=='file')g.append(n)});return g};
try{const u=JSON.parse(localStorage.getItem('ced_ui')||'null');if(u){if(u.bg&&typeof u.bg.c=='string')BG={c:u.bg.c,chk:u.bg.chk!==false};if('snap'in u)SNAP=!!u.snap;if(u.lvn>=1)LVN=Math.min(12,Math.max(1,Math.round(u.lvn)));if(u.on&&typeof u.on=='object')ON={...ON,...u.on,op:Math.min(.8,Math.max(.1,+u.on.op||ON.op)),n:Math.min(20,Math.max(1,Math.round(+u.on.n||1)))}}}catch(e){}
window.uiSave=()=>{try{localStorage.setItem('ced_ui',JSON.stringify({bg:BG,snap:SNAP,on:ON,lvn:LVN}))}catch(e){}};
const lh=$('#lhead');[['addv','ベクター'],['addb','ビット'],['expb','書き出し']].forEach(([i,l])=>{const e=$('#'+i);e.dataset.l=l;lh.append(e)});
const lab={undo:'戻す',redo:'進む',tp:'パネル',pvw:'確認',flt:'補正',v2b:'ビット化',bcp:'コピー',bct:'切取',bps:'貼付',dp:'複製',dl:'削除',bdel:'削除',mu:'複数選択',fr:'前面',bkb:'背面',gp:'グループ',ug:'解除',arr:'配置'};Object.keys(lab).forEach(i=>$('#'+i).dataset.l=lab[i]);
// --- メニューバー
M.innerHTML='<b class="mt">コスチュームエディター</b>';const menus=[],closeM=()=>menus.forEach(([b,p])=>{p.hidden=true;b.classList.remove('on');b.setAttribute('aria-expanded','false')});
function addMenu(id,label,build){const w=document.createElement('span');w.className='mw';const b=document.createElement('button');b.className='mbtn';b.id=id;b.setAttribute('aria-haspopup','true');b.setAttribute('aria-expanded','false');b.textContent=label+' ▾';const p=document.createElement('div');p.className='mpop';p.id=id+'_p';p.hidden=true;p.setAttribute('role','menu');w.append(b,p);M.append(w);build(p);
b.onclick=e=>{e.stopPropagation();const open=p.hidden;closeM();if(open){p.hidden=false;b.classList.add('on');b.setAttribute('aria-expanded','true')}};p.addEventListener('click',e=>{if(e.target.closest('button.mi'))closeM()});menus.push([b,p])}
const FM=[[['sv','プロジェクトを保存(JSON)'],['ld','プロジェクトを読み込む'],['bk','自動バックアップを復元']],[['impb','画像を読み込む(原寸)'],['svi','SVGを図形として読み込む'],['s3i','.sprite3 / .sb3を読み込む(Scratch)']],[['s3o','現在のスプライトを.sprite3で書き出す(Scratch)'],['sb3o','全体を.sb3で書き出す(Scratch)']]];
addMenu('m_file','ファイル',p=>{FM.forEach((grp,k)=>{if(k)p.append(document.createElement('hr'));grp.forEach(([i,l])=>{const e=$('#'+i);e.classList.add('mi');e.dataset.l=l;p.append(e);const n=e.nextElementSibling;if(n&&n.tagName=='INPUT'&&n.type=='file')p.append(n)})})});
const SW=[['#ffffff','白'],['#f0f0f0','明るい灰色'],['#bdbdbd','灰色'],['#424242','濃い灰色'],['#000000','黒'],['#fff4c2','クリーム'],['#cfe8ff','空色'],['#d4f5d4','うす緑'],['#ffd6e7','ピンク']];
addMenu('m_view','表示',p=>{p.innerHTML='<div class="mh">編集画面の背景色(書き出しには影響しません)</div><div class="sws" id="sws"></div><label class="mrow">自由な色<input type="color" id="bgc" aria-label="背景色を選ぶ"></label><label class="mrow"><input type="checkbox" id="bgk">市松模様で透明部分を示す</label><button class="mi" id="bgr" style="padding:0 10px"><small>背景を初期状態(白+市松模様)に戻す</small></button>';
const sw=p.querySelector('#sws');SW.forEach(([c,n])=>{const b=document.createElement('button');b.style.background=c;b.title=n;b.setAttribute('aria-label','背景色: '+n);b.dataset.c=c;sw.append(b)});
const sync_=()=>{sw.querySelectorAll('button').forEach(b=>b.classList.toggle('on',b.dataset.c==BG.c));p.querySelector('#bgk').checked=BG.chk;const q=parseC(BG.c);if(q)p.querySelector('#bgc').value='#'+h2(q.r)+h2(q.g)+h2(q.b)},set=()=>{sync_();uiSave();draw()};
sw.onclick=e=>{const b=e.target.closest('button');if(b){BG.c=b.dataset.c;set()}};p.querySelector('#bgc').oninput=e=>{BG.c=e.target.value;set()};p.querySelector('#bgk').onchange=e=>{BG.chk=e.target.checked;set()};p.querySelector('#bgr').onclick=()=>{BG={c:'#ffffff',chk:true};set()};sync_()});
const sp=document.createElement('span');sp.className='fill';const hl=$('#hlp');hl.dataset.l='ヘルプ';M.append(sp,hl);
addEventListener('pointerdown',e=>{if(!e.target.closest('.mw'))closeM()},true);addEventListener('keydown',e=>{if(e.key=='Escape')closeM()});
// --- 詳細パネル(図形演算・整列・画像補正・形式変換)。ファイル系の項目はメニューバーへ移動済み
$('#more').innerHTML='<h4>図形演算(複数選択)</h4><div class="grp" id="m1"></div><h4>整列</h4><div class="grp" id="m2"></div><h4>画像・変換</h4><div class="grp" id="m3"></div>';
['bmg','bmk','bsb','bft'].forEach(i=>$('#m1').append($('#'+i)));$('#m2').append($('#al'));['flt','v2b'].forEach(i=>$('#m3').append($('#'+i)));
const mre=document.createElement('button');mre.id='mre';mre.dataset.i='merge';mre.dataset.t='詳細機能(図形演算・整列・画像補正・形式変換)';mre.dataset.l='詳細';
mre.onclick=()=>{$('#more').hidden=!$('#more').hidden;mre.classList.toggle('on',!$('#more').hidden)};
addEventListener('pointerdown',e=>{if(!$('#more').hidden&&!e.target.closest('#more,#mre,#flt,#v2b')){$('#more').hidden=true;mre.classList.remove('on')}},true);
$('#more').addEventListener('click',e=>{if(e.target.closest('#flt,#v2b')){$('#more').hidden=true;mre.classList.remove('on')}});
// --- 下部から上部へ移した操作(重複する元のボタンは残さない)
const snapb=document.createElement('button');snapb.id='snapb';snapb.dataset.i='ctr';snapb.dataset.l='中心吸着';snapb.dataset.t='中心スナップ: 図形をドラッグするとキャンバスの中心に吸着(Altキーで一時的に解除)';snapb.onclick=()=>{SNAP=!SNAP;uiSave();sync()};
const sp2=document.createElement('span');sp2.className='fill';
const gs=mkG([],'g_snap');gs.append(snapb);T.append(mkG(['undo','redo']),mkG(['bcp','bct','bps','dp','dl','bdel'],'g_edit'),mkG(['mu','fr','bkb','gp','ug','arr'],'g_arr'),gs,mkG(['zi','zo','zf','z1','pvw']),sp2,mre,$('#tp'));
$('#g_ops').remove();T.querySelectorAll('.sep').forEach(e=>e.remove());
const tp=$('#tp');tp.addEventListener('click',()=>tp.classList.toggle('on',!$('#side').hidden));tp.classList.toggle('on',!$('#side').hidden)})();

// ===== 配置(整列/等間隔/グリッド)とパス操作 =====
Object.assign(IC,{alignp:'<path d="M4 3v18M8 7h12M8 12h8M8 17h11"/>',pathop:'<path d="M4 18C8 4 16 20 20 6"/><circle cx="4" cy="18" r="1.6"/><circle cx="20" cy="6" r="1.6"/>'});
const SPA={s:null,a:[]};
const spHas=(s,i)=>SPA.s===s&&SPA.a.includes(i);
function spTog(s,i){if(SPA.s!==s){SPA.s=s;SPA.a=selPt>=0?[selPt]:[]}const k=SPA.a.indexOf(i);if(k<0){SPA.a.push(i);selPt=i}else{SPA.a.splice(k,1);selPt=SPA.a.length?SPA.a[SPA.a.length-1]:-1}}
function selPts(){const s=sel[0];if(!s||!s.bz)return[];if(SPA.s!==s)return selPt>=0?[selPt]:[];let a=SPA.a.filter(i=>i<s.pts.length);if(selPt>=0&&selPt<s.pts.length&&!a.includes(selPt))a=[...a,selPt];return a}
const free=()=>sel.filter(s=>!s.lk&&!s.hid),W_=(s,i)=>{const q=s.pts[i];return l2w(s,q[0]*s.w,q[1]*s.h)},setW=(s,i,x,y)=>{const l=w2l(s,x,y);s.pts[i][0]=l[0]/s.w;s.pts[i][1]=l[1]/s.h};
// --- 図形の整列(外接矩形=回転後の表示範囲)
function alignObj(m,cm){const c=C(),L=free(),ref=$('#a_ref').value;if(!L.length)return alert('図形を選択してください');let R=ref=='c'||L.length<2&&ref!='f'?[0,0,c.w,c.h]:ref=='f'?ubox([sel[0]]):ubox(L);if(ref=='f'&&L.length<2)return alert('「最初に選択した図形」を基準にするには2個以上選択してください');
hist();if(cm){const U=ubox(L),dx=cm!='v'?c.w/2-(U[0]+U[2])/2:0,dy=cm!='h'?c.h/2-(U[1]+U[3])/2:0;L.forEach(s=>{s.x+=dx;s.y+=dy})}
else L.forEach(s=>{if(ref=='f'&&s===sel[0])return;const[a,b,e,f]=ubox([s]);if(m=='l')s.x+=R[0]-a;if(m=='c')s.x+=(R[0]+R[2])/2-(a+e)/2;if(m=='r')s.x+=R[2]-e;if(m=='t')s.y+=R[1]-b;if(m=='m')s.y+=(R[1]+R[3])/2-(b+f)/2;if(m=='b')s.y+=R[3]-f});fin()}
// --- 等間隔: e=両端固定で隙間を均等 / c=両端の中心固定で中心を均等 / g=数値の隙間(先頭の位置から)
function distObj(ax,mode){const L=free(),g=+$('#a_gap').value||0;if(L.length<(mode=='g'?2:3))return alert(mode=='g'?'2個以上の図形を選択してください':'等間隔には3個以上の図形を選択してください');const i0=ax=='x'?0:1,i1=i0+2,B=L.map(s=>({s,b:ubox([s])})).sort((p,q)=>p.b[i0]+p.b[i1]-q.b[i0]-q.b[i1]),n=B.length;hist();
if(mode=='c'){const c0=(B[0].b[i0]+B[0].b[i1])/2,c1=(B[n-1].b[i0]+B[n-1].b[i1])/2;B.forEach((o,k)=>o.s[ax]+=c0+k*(c1-c0)/(n-1)-(o.b[i0]+o.b[i1])/2)}
else{const lo=B[0].b[i0],tot=B.reduce((a,o)=>a+o.b[i1]-o.b[i0],0),gap=mode=='g'?g:(Math.max(...B.map(o=>o.b[i1]))-lo-tot)/(n-1);let p=lo;B.forEach(o=>{o.s[ax]+=p-o.b[i0];p+=o.b[i1]-o.b[i0]+gap})}fin()}
// --- グリッド(選択した順に左上から行方向へ。サイズは維持。セルは最大の幅・高さ)
function gridObj(){const L=free(),n=L.length;if(n<2)return alert('2個以上の図形を選択してください');let cols=Math.floor(+$('#a_gc').value||0),rows=Math.floor(+$('#a_gr').value||0);if(cols<1&&rows<1)cols=Math.ceil(Math.sqrt(n));if(cols<1)cols=Math.ceil(n/rows);if(rows<1)rows=Math.ceil(n/cols);
if(cols*rows<n)return alert(`${cols}列×${rows}行では${n}個が入りません`);const B=L.map(s=>ubox([s])),U=ubox(L),cw=Math.max(...B.map(b=>b[2]-b[0])),ch=Math.max(...B.map(b=>b[3]-b[1])),hg=+$('#a_hg').value||0,vg=+$('#a_vg').value||0,sx=$('#a_sx').value===''?U[0]:+$('#a_sx').value,sy=$('#a_sy').value===''?U[1]:+$('#a_sy').value;
hist();L.forEach((s,k)=>{const b=B[k],X=sx+(k%cols)*(cw+hg)+cw/2,Y=sy+Math.floor(k/cols)*(ch+vg)+ch/2;s.x+=X-(b[0]+b[2])/2;s.y+=Y-(b[1]+b[3])/2});fin()}
// --- ポイント操作(位置のみ変更。ハンドル・滑らか/角の状態は保持。回転した図形は画面座標で処理)
function ptOp(f,min=2){const s=sel[0],I=selPts();if(!s||!s.bz)return alert('パス編集ツールで曲線を選択してください');if(I.length<min)return alert(`${min}点以上を選択してください(「複数選択」をONにして点をタップ)`);hist();f(s,I,I.map(i=>W_(s,i)));renorm(s);SPA.s=s;fin()}
const pAl=m=>ptOp((s,I,P)=>{const X=P.map(p=>p[0]),Y=P.map(p=>p[1]),a=Math.min(...X),b=Math.max(...X),c=Math.min(...Y),d=Math.max(...Y);I.forEach((i,k)=>{let[x,y]=P[k];if(m=='l')x=a;if(m=='c')x=(a+b)/2;if(m=='r')x=b;if(m=='t')y=c;if(m=='m')y=(c+d)/2;if(m=='b')y=d;setW(s,i,x,y)})});
const pFlat=ax=>ptOp((s,I,P)=>{const k=ax=='y'?1:0,v=$('#a_pref').value=='a'?P.reduce((a,p)=>a+p[k],0)/P.length:P[0][k];I.forEach((i,j)=>{const p=P[j].slice();p[k]=v;setW(s,i,p[0],p[1])})});
const pDist=ax=>ptOp((s,I,P)=>{const k=ax=='y'?1:0,o=P.map((p,j)=>j).sort((a,b)=>P[a][k]-P[b][k]),lo=P[o[0]][k],hi=P[o[o.length-1]][k];o.forEach((j,r)=>{const p=P[j].slice();p[k]=lo+r*(hi-lo)/(o.length-1);setW(s,I[j],p[0],p[1])})},3);
const pMove=()=>{const dx=+$('#a_dx').value||0,dy=+$('#a_dy').value||0;ptOp((s,I,P)=>I.forEach((i,j)=>setW(s,i,P[j][0]+dx,P[j][1]+dy)),1)};
const wpts=s=>{const c=Math.cos(s.r),n=Math.sin(s.r),rv=(a,b)=>[a*s.w*c-b*s.h*n,a*s.w*n+b*s.h*c];return s.pts.map(q=>{const p=l2w(s,q[0]*s.w,q[1]*s.h),i=rv(q[2]||0,q[3]||0),o=rv(q[4]||0,q[5]||0);return[p[0],p[1],i[0],i[1],o[0],o[1],q[6]||0]})},
rev=P=>P.slice().reverse().map(q=>[q[0],q[1],q[4],q[5],q[2],q[3],q[6]]),
openOk=s=>s&&s.bz&&!s.cmp&&!s.cl&&s.pts.length>=2;
function fromW(base,P,closed){const n={...base,w:1,h:1,x:0,y:0,r:0,pts:P.map(q=>q.slice()),cl:!!closed};delete n.cmp;renorm(n);return n}
const mpos=(a,b)=>$('#a_mp').value=='m'?[(a[0]+b[0])/2,(a[1]+b[1])/2]:[a[0],a[1]];
// 端点結合(同一パスの端点2つ→閉じる)/ 点の結合(隣り合う2点→1点)
function endJoin(){const s=sel[0],I=selPts();if(!s||!s.bz||s.cmp)return alert('結合できるのは単一の曲線パスです');if(I.length!=2)return alert('端点を2つ選択してください(複数選択をONにして点をタップ)');const n=s.pts.length;
if(!openOk(s)||n<3||!(I.includes(0)&&I.includes(n-1)))return alert('同一パスの結合は、開いたパスの両端(先頭と末尾の点)を選択してください。別々のパスは「連結」を使います');
hist();const a=W_(s,I[0]),b=W_(s,I[1]),p=mpos(a,b);setW(s,0,p[0],p[1]);const f=s.pts[0],l=s.pts[n-1];f[2]=l[2];f[3]=l[3];s.pts.pop();s.cl=true;renorm(s);SPA.a=[];selPt=-1;fin()}
function nodeMerge(){const s=sel[0],I=selPts();if(!s||!s.bz||s.cmp)return alert('点の結合は単一の曲線パスが対象です');if(I.length!=2)return alert('2点を選択してください');const[a,b]=I.slice().sort((x,y)=>x-y);if(b-a!=1)return alert('点の結合は隣り合う2点が対象です(両端どうしは「端点を結合」)');if(s.pts.length-1<(s.cl?3:2))return alert('点が少なくなりすぎるため結合できません');
hist();const qa=s.pts[a],qb=s.pts[b],p=$('#a_mp').value=='m'?[(qa[0]+qb[0])/2,(qa[1]+qb[1])/2]:(I[0]==a?[qa[0],qa[1]]:[qb[0],qb[1]]);s.pts.splice(a,2,[p[0],p[1],qa[2],qa[3],qb[4],qb[5],qa[6]||qb[6]?1:0,qa[7]]);renorm(s);SPA.a=[];selPt=-1;fin()}
// 連結: 選択した2本の開いたパスの最も近い端点どうしを1点に統合して1本に
function joinPaths(){const c=C();if(sel.length!=2||!sel.every(openOk))return alert('開いた曲線パスを2本選択してください(選択ツールで2本選ぶ)。閉じたパス・複合パス・図形/文字/画像は対象外です');const[A,B]=sel,PA=wpts(A),PB=wpts(B);let best=null;[[0,0],[0,1],[1,0],[1,1]].forEach(([ea,eb])=>{const p=PA[ea?PA.length-1:0],q=PB[eb?PB.length-1:0],d=Math.hypot(p[0]-q[0],p[1]-q[1]);if(!best||d<best.d)best={d,ea,eb}});
const X=best.ea?PA:rev(PA),Y=best.eb?rev(PB):PB.slice(),e=X[X.length-1],f=Y[0],p=mpos(e,f);hist();const m=[p[0],p[1],e[2],e[3],f[4],f[5],e[6]||f[6]?1:0],n=fromW(A,[...X.slice(0,-1),m,...Y.slice(1)],false);c.sh[c.sh.indexOf(A)]=n;c.sh=c.sh.filter(q=>q!==B);sel=[n];selPt=-1;SPA.a=[];fin()}
function splitPath(){const c=C(),s=sel[0],I=selPts();if(!s||!s.bz||s.cmp)return alert('分割できるのは単一の曲線パスです');if(I.length!=1)return alert('分割する点を1つだけ選択してください');const i=I[0],n=s.pts.length,P=s.pts.map(q=>q.slice());
if(s.cl){if(n<3)return;hist();s.pts=[...P.slice(i),...P.slice(0,i),P[i].slice()];s.cl=false;renorm(s)}
else{if(i<=0||i>=n-1)return alert('端の点では分割できません(途中の点を選択)');hist();const t={...s,pts:P.slice(i).map(q=>q.slice())};s.pts=P.slice(0,i+1);renorm(s);renorm(t);c.sh.splice(c.sh.indexOf(s)+1,0,t)}SPA.a=[];selPt=-1;fin()}
// 簡略化: ハンドルを持たない直線上の点(許容誤差0.5px)のみ削除。曲線部分は変更しない
function simplifyPath(){const s=sel[0];if(!s||!s.bz||s.cmp)return alert('単一の曲線パスを選択してください');const z0=q=>!q[2]&&!q[3]&&!q[4]&&!q[5];let P=s.pts.map(q=>q.slice()),rm=0,ch=1;const mn=s.cl?3:2;
while(ch&&P.length>mn){ch=0;for(let i=s.cl?0:1;i<(s.cl?P.length:P.length-1);i++){const a=P[(i+P.length-1)%P.length],b=P[i],e=P[(i+1)%P.length];if(!(z0(a)&&z0(b)&&z0(e)))continue;const ax=a[0]*s.w,ay=a[1]*s.h,ex=e[0]*s.w,ey=e[1]*s.h,L=Math.hypot(ex-ax,ey-ay)||1,d=Math.abs((b[0]*s.w-ax)*(ey-ay)-(b[1]*s.h-ay)*(ex-ax))/L;if(d<.5){P.splice(i,1);rm++;ch=1;break}}}
if(!rm)return alert('削除できる点がありません(直線上でハンドルのない点のみ対象です)');hist();s.pts=P;renorm(s);SPA.a=[];selPt=-1;fin()}
// --- 操作パネル(キャンバスを隠さない下部シート)
function openArr(tab){if($('#arrd')){$('#arrd').remove()}const D=document.createElement('div');D.id='arrd';D.className='dlg';D.style.cssText='background:none;pointer-events:none;align-items:flex-end;justify-content:flex-end';
const B=(a,t,tip)=>`<button data-a="${a}" title="${tip||t}">${t}</button>`;
D.innerHTML=`<div style="pointer-events:auto;box-shadow:0 2px 12px #0005;max-height:52vh;width:min(430px,calc(100vw - 12px))"><span class="tb" id="a_tb">${['整列','等間隔','グリッド','パス操作'].map((t,i)=>`<button data-t="${i}">${t}</button>`).join('')}<button data-s title="パネルを左右に移動(キャンバスの点を隠さないように)">⇄ 左右</button><button data-x>閉じる</button></span><small id="a_st"></small>
<div class="pn"><h5>基準</h5><div class="r"><select id="a_ref"><option value="a">選択範囲全体</option><option value="f">最初に選択した図形</option><option value="c">キャンバス</option></select></div><div class="r">${B('al_l','左揃え')}${B('al_c','左右中央')}${B('al_r','右揃え')}${B('al_t','上揃え')}${B('al_m','上下中央')}${B('al_b','下揃え')}</div><h5>キャンバスの中央へ(選択全体を移動)</h5><div class="r">${B('cc_h','水平中央')}${B('cc_v','垂直中央')}${B('cc_c','中央')}</div></div>
<div class="pn"><small>3個以上の図形。位置のみ変更し、サイズは維持します。</small><div class="r">${B('d_xe','水平:両端を基準に均等','左端・右端の図形を固定し、隙間を均等にします')}${B('d_ye','垂直:両端を基準に均等','上端・下端の図形を固定し、隙間を均等にします')}</div><div class="r">${B('d_xc','水平:中心を均等')}${B('d_yc','垂直:中心を均等')}</div><h5>数値で隙間を指定(先頭の位置から)</h5><div class="r"><input type="number" id="a_gap" value="10">px ${B('d_xg','水平に配置')}${B('d_yg','垂直に配置')}</div></div>
<div class="pn"><small>選択した順に、左上から行方向へ並べます(サイズは維持)。開始位置が空欄なら選択範囲の左上です。</small><div class="r"><label>列数<input type="number" id="a_gc" min="1" value="3"></label><label>行数<input type="number" id="a_gr" min="1" placeholder="自動"></label></div><div class="r"><label>横間隔<input type="number" id="a_hg" value="10"></label><label>縦間隔<input type="number" id="a_vg" value="10"></label></div><div class="r"><label>開始X<input type="number" id="a_sx"></label><label>開始Y<input type="number" id="a_sy"></label></div>${B('grid','グリッドに配置')}</div>
<div class="pn"><small>パス編集ツールで曲線を選び、「複数選択」をONにして点をタップします。</small><h5>ポイント整列</h5><div class="r">${B('p_l','左端へ')}${B('p_c','水平中央へ')}${B('p_r','右端へ')}${B('p_t','上端へ')}${B('p_m','垂直中央へ')}${B('p_b','下端へ')}</div><h5>水平化・垂直化・等間隔</h5><div class="r"><select id="a_pref"><option value="f">先頭の選択点を基準</option><option value="a">平均位置を基準</option></select>${B('p_hy','水平化(同じY)')}${B('p_vx','垂直化(同じX)')}</div><div class="r">${B('p_dx','点を水平に等間隔')}${B('p_dy','点を垂直に等間隔')}<label>移動X<input type="number" id="a_dx" value="0"></label><label>Y<input type="number" id="a_dy" value="0"></label>${B('p_mv','移動')}</div>
<h5>結合</h5><div class="r"><select id="a_mp"><option value="f">先頭の選択点の位置</option><option value="m">2点の中間位置</option></select>${B('j_end','端点を結合(閉じる)')}${B('j_mrg','点を結合(隣り合う2点)')}</div><h5>パス操作</h5><div class="r">${B('o_join','連結(2本のパス)','選択ツールで開いたパスを2本選びます')}${B('o_split','選択点で分割')}${B('o_simp','簡略化(直線上の点)')}</div><small>未対応: アウトライン化、複合パス化(既存の「結合」ボタンは図形の合体用)</small></div></div>`;
document.body.append(D);const pn=D.querySelectorAll('.pn'),tb=D.querySelectorAll('#a_tb [data-t]'),T=i=>{pn.forEach((p,k)=>p.classList.toggle('on',k==i));tb.forEach((b,k)=>b.classList.toggle('on',k==i))};T(tab);tb.forEach(b=>b.onclick=()=>T(+b.dataset.t));
const A={grid:gridObj,d_xe:()=>distObj('x','e'),d_ye:()=>distObj('y','e'),d_xc:()=>distObj('x','c'),d_yc:()=>distObj('y','c'),d_xg:()=>distObj('x','g'),d_yg:()=>distObj('y','g'),cc_h:()=>alignObj('','h'),cc_v:()=>alignObj('','v'),cc_c:()=>alignObj('','c'),p_hy:()=>pFlat('y'),p_vx:()=>pFlat('x'),p_dx:()=>pDist('x'),p_dy:()=>pDist('y'),p_mv:pMove,j_end:endJoin,j_mrg:nodeMerge,o_join:joinPaths,o_split:splitPath,o_simp:simplifyPath};['l','c','r','t','m','b'].forEach(m=>{A['al_'+m]=()=>alignObj(m);A['p_'+m]=()=>pAl(m)});
D.onclick=e=>{const b=e.target.closest('button[data-a]');if(b)A[b.dataset.a]();if(e.target.closest('[data-s]'))D.style.justifyContent=D.style.justifyContent=='flex-start'?'flex-end':'flex-start';if(e.target.closest('[data-x]')){clearInterval(iv);D.remove()}};
const iv=setInterval(()=>{if(!D.isConnected)return clearInterval(iv);const c=C();$('#a_st').textContent=c.k!='v'?'ベクターのコスチュームで使えます':`図形${sel.length}個選択 / 点${selPts().length}個選択`},250)}
$('#arr').onclick=()=>openArr(0);$('#pth').onclick=()=>openArr(3);
{const o1=$('#bcp').onclick,o2=$('#bct').onclick,o3=$('#bps').onclick;
/* ベクターでコピーした図形をビットマップに貼る: 現在のアンチエイリアス設定でラスタライズし、浮動選択として置く(位置はコスチュームの中心基準、サイズは解像度に合わせて等倍) */
async function vpasteToBitmap(){const c=C();if(!vclip||!VCI||c.k!='b')return;const shapes=JSON.parse(vclip);
await Promise.all(shapes.map(q=>{if(q.src){ld(q);if(q.im&&!q.im.complete)return new Promise(r=>{q.im.addEventListener('load',r);q.im.addEventListener('error',r)})}}));
const kt=RS(c)/VCI.res,sw=VCI.w,sh=VCI.h,m=Math.max(...shapes.map(s=>(s.sw||0)*6+4));let[x0,y0,x1,y1]=ubox(shapes);x0-=m;y0-=m;x1+=m;y1+=m;
const tx0=Math.max(0,Math.floor(c.w/2+(x0-sw/2)*kt)),ty0=Math.max(0,Math.floor(c.h/2+(y0-sh/2)*kt)),tx1=Math.min(c.w,Math.ceil(c.w/2+(x1-sw/2)*kt)),ty1=Math.min(c.h,Math.ceil(c.h/2+(y1-sh/2)*kt)),W=tx1-tx0,H=ty1-ty0;
if(W<=0||H<=0){await uiAlert('貼り付ける図形が、ビットマップの範囲の外です');return}
const o=document.createElement('canvas');o.width=W;o.height=H;rasterVec(o,shapes,kt,(sw/2*kt+tx0-c.w/2)/kt,(sh/2*kt+ty0-c.h/2)/kt);
if(!opaqueN(o)){await uiAlert('貼り付ける内容が空です');return}
o.pi=[tx0+W/2,ty0+H/2,RS(c)];const keep=clip;clip=o;try{o3()}finally{clip=keep}}
$('#bcp').onclick=()=>{if(isV()){vcopy();sync()}else{const b=clip;o1();if(clip!==b)LASTCLIP='b'}};$('#bct').onclick=()=>{if(isV()){if(!sel.length)return;vcopy();$('#dl').onclick();sync()}else o2()};$('#bps').onclick=()=>{if(isV())vpaste();else if(vclip&&(LASTCLIP=='v'||!clip))vpasteToBitmap();else o3()}}
// ===== オニオンスキン(編集画面だけの表示レイヤー。編集データ・保存・書き出しには一切触れない) =====
Object.assign(IC,{onion:'<circle cx="9" cy="12" r="6" stroke-dasharray="3 2"/><circle cx="15" cy="12" r="6"/>',onprev:'<circle cx="15" cy="12" r="5" stroke-dasharray="3 2"/><path d="M8 7l-5 5 5 5M3 12h8"/>',onnext:'<circle cx="9" cy="12" r="5" stroke-dasharray="3 2"/><path d="M16 7l5 5-5 5M21 12h-8"/>',oncol:'<circle cx="9" cy="12" r="5.5" fill="#ff4d4d" fill-opacity=".55" stroke="#ff4d4d"/><circle cx="15" cy="12" r="5.5" fill="#2f7bff" fill-opacity=".55" stroke="#2f7bff"/>',sym:'<path d="M12 3v18" stroke-dasharray="2 2.5"/><path d="M3 17C5 7 9 7 12 12M21 17C19 7 15 7 12 12"/>'});
const OC=new WeakMap();
function onionImg(n,tint){const key=(tint||'-')+'|'+ONG+'|'+n.w+'x'+n.h;const e=OC.get(n);if(e&&e.k==key)return e.cv;const o=document.createElement('canvas');o.width=n.w;o.height=n.h;const x=o.getContext('2d');dc(x,n);if(tint){x.globalCompositeOperation='source-atop';x.globalAlpha=.6;x.fillStyle=tint;x.fillRect(0,0,n.w,n.h)}
if(!(n.k=='v'&&n.sh.some(s=>s.t=='img'&&!(s.im&&s.im.complete))))OC.set(n,{k:key,cv:o});return o}
function onionDraw(c){const N=Math.min(20,Math.max(1,Math.round(+ON.n||1)));[[-1,'prev','#ff4d4d'],[1,'next','#2f7bff']].forEach(([d,key,col])=>{if(!ON[key])return;for(let j=N;j>=1;j--){const n=cs[ci+d*j];if(!n)continue;const o=onionImg(n,ON.col?col:null),k=RS(c)/RS(n);g.save();g.globalAlpha=ON.op*Math.pow(.7,j-1);g.translate(c.cx-n.cx*k,c.cy-n.cy*k);g.scale(k,k);g.drawImage(o,0,0);g.restore()}})}
/* 数値入力に置き換えた項目(data-clamp)は、確定時に最小〜最大へ丸め、input イベントを再送して画面へ反映する */
document.addEventListener('change',e=>{const el=e.target;if(!(el instanceof HTMLInputElement)||el.type!='number'||!el.hasAttribute('data-clamp'))return;let v=parseFloat(el.value);const mn=el.min!==''?+el.min:-Infinity,mx=el.max!==''?+el.max:Infinity;if(!isFinite(v))v=el.defaultValue!==''?+el.defaultValue:(isFinite(mn)?mn:0);const c=Math.min(mx,Math.max(mn,v));if(String(c)!==el.value){el.value=c;el.dispatchEvent(new Event('input',{bubbles:true}))}},true);
function onSync(){const b=$('#onb');if(!b)return;b.className=ON.on?'on':'';b.setAttribute('aria-pressed',!!ON.on);$('#onx').hidden=!ON.on;[['onp','prev'],['onn','next'],['onc','col']].forEach(([i,k])=>{$('#'+i).className=ON[k]?'on':'';$('#'+i).setAttribute('aria-pressed',!!ON[k])});
if(document.activeElement!==$('#onop'))$('#onop').value=Math.round(ON.op*100);if(document.activeElement!==$('#onnum'))$('#onnum').value=ON.n||1;const p=cs[ci-1],n=cs[ci+1];$('#onp').title='一つ前のコスチュームを表示'+(p?'(「'+p.n+'」)':'(なし: これが最初のコスチュームです)');$('#onn').title='一つ後のコスチュームを表示'+(n?'(「'+n.n+'」)':'(なし: これが最後のコスチュームです)')}
(()=>{const set=()=>{uiSave();onSync();draw()};$('#onb').onclick=()=>{ON.on=!ON.on;set()};$('#onp').onclick=()=>{ON.prev=!ON.prev;set()};$('#onn').onclick=()=>{ON.next=!ON.next;set()};$('#onc').onclick=()=>{ON.col=!ON.col;set()};
$('#onop').oninput=e=>{ON.op=Math.min(.8,Math.max(.1,(+e.target.value||0)/100));draw()};$('#onop').onchange=()=>uiSave();$('#onnum').oninput=e=>{const v=Math.round(+e.target.value);if(isFinite(v)&&v>=1){ON.n=Math.min(20,v);draw()}};$('#onnum').onchange=()=>{ON.n=Math.min(20,Math.max(1,Math.round(+$('#onnum').value)||1));uiSave();draw()};
$('#symb').onclick=()=>{SYM=!SYM;sync()}})();
// ===== ベクター文字: キャンバス上で直接入力 + 独自フォント一覧 =====
function teGeom(){const t=TE;if(t.s){const s=t.s;return{fs:s.fs,fn:s.fn||'sans-serif',r:s.r,A:t.A,col:typeof s.f=='string'?s.f:null}}const f=fv();return{fs:Math.max(12,sty().sw*6),fn:curFont(),r:0,A:[t.ax,t.ay],col:typeof f=='string'?f:null}}
function teLayout(){if(!TE)return;const q=teGeom(),inp=$('#te_in'),pad=4;g.save();g.font=`${q.fs}px ${q.fn}`;const w=Math.max(4,g.measureText(inp.value||'').width);g.restore();
const H=q.fs*1.2*z,cr=cv.getBoundingClientRect(),mr=$('#main').getBoundingClientRect(),sx=cr.left-mr.left+ox+q.A[0]*z,sy=cr.top-mr.top+oy+q.A[1]*z,col=q.col||'#000000',pc=parseC(col),lum=pc?(.299*pc.r+.587*pc.g+.114*pc.b)/255:0,st=inp.style;
st.font=`${q.fs*z}px ${q.fn}`;st.lineHeight=H+'px';st.height=H+'px';st.width=(w*z+pad*2+6)+'px';st.left=(sx-pad)+'px';st.top=(sy-H/2)+'px';st.transformOrigin=pad+'px 50%';st.transform=`rotate(${q.r}rad)`;st.color=col;st.caretColor=col;st.background=lum>.8?'#303030e6':'#ffffffe0'}
function teStart(s,p){if(TE)teEnd();const c=C();if(c.k!='v')return;const inp=$('#te_in');
if(s){const co=Math.cos(s.r),si=Math.sin(s.r);TE={s,orig:s.tx,w0:s.w,A:[s.x-s.w/2*co,s.y-s.w/2*si]};sel=[s]}else{TE={s:null,ax:p[0],ay:p[1]};sel=[]}
TEH=s||null;inp.value=s?s.tx:'';inp.hidden=false;sync();draw();teLayout();inp.focus();if(s)inp.select()}
function teEnd(){if(!TE)return;const t=TE,inp=$('#te_in'),v=inp.value,c=C();TE=null;TEH=null;inp.hidden=true;if(document.activeElement===inp)inp.blur();
if(!t.s){if(v){hist();const y=sty(),s={t:'txt',x:t.ax,y:t.ay,r:0,fs:Math.max(12,y.sw*6),tx:v,f:fv(),s:null,sw:2,sj:SJ,fn:curFont()};tm(s);s.x=t.ax+s.w/2;c.sh.push(s);sel=[s];fin();if($('#tov').checked)t2p([s],1)}}
else{const s=t.s;if(!c.sh.includes(s)){sync();draw();return}if(!v){hist();c.sh.splice(c.sh.indexOf(s),1);sel=[];fin()}else if(v!==t.orig){hist();s.tx=v;tm(s);const co=Math.cos(s.r),si=Math.sin(s.r);s.x=t.A[0]+s.w/2*co;s.y=t.A[1]+s.w/2*si;fin()}}
sync();draw()}
(()=>{const inp=$('#te_in');inp.addEventListener('input',()=>{teLayout()});inp.addEventListener('keydown',e=>{e.stopPropagation();if((e.key=='Enter'||e.key=='Escape')&&!e.isComposing&&e.keyCode!==229){e.preventDefault();teEnd()}});inp.addEventListener('blur',()=>{setTimeout(()=>{if(TE&&document.activeElement!==inp)teEnd()},0)});
cv.addEventListener('click',e=>{const t=TT;TT=null;if(!t||Math.hypot(e.clientX-t.x,e.clientY-t.y)>8||C().k!='v')return;if(t.h)teStart(t.h);else if(tool=='txt')teStart(null,t.p)})})();
// --- 独自フォント一覧
function fnRefresh(){const f=FL[+$('#fn').value]||FL[0],b=$('#fnb');if(!b)return;const t=b.querySelector('.fnt');t.textContent=f.n;t.style.fontFamily=f.css;$('#fpop').querySelectorAll('.fi').forEach((x,i)=>{x.classList.toggle('on',i==+$('#fn').value);x.setAttribute('aria-selected',i==+$('#fn').value)})}
(()=>{const e=$('#fn'),d=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value');Object.defineProperty(e,'value',{get(){return d.get.call(this)},set(v){d.set.call(this,v);fnRefresh()},configurable:true})})();
function buildFpop(){const P=$('#fpop');if(!P)return;P.innerHTML='';FL.forEach((f,i)=>{const b=document.createElement('button');b.type='button';b.className='fi';b.setAttribute('role','option');b.dataset.i=i;const alt=badFont.has(f.n)||(f.web&&webFail.has(f.fam)&&!webOk.has(f.fam)&&!fonts.some(x=>x.n==f.fam));
b.innerHTML=`<span class="nm"></span><span class="sm"></span>${alt?'<span class="alt">代替表示</span>':''}`;const nm=b.querySelector('.nm'),sm=b.querySelector('.sm');nm.textContent=f.n;sm.textContent='Abc あいう';nm.style.fontFamily=sm.style.fontFamily=f.css;P.append(b)});fnRefresh()}
async function prevWeb(f){if(!f.web||webPrev.has(f.fam)||webFail.has(f.fam)||fonts.some(x=>x.n==f.fam))return;webPrev.add(f.fam);try{const css=await(await fetch('https://fonts.googleapis.com/css2?family='+encodeURIComponent(f.fam).replace(/%20/g,'+')+'&display=swap')).text();const m=css.match(/\/\* latin \*\/\s*@font-face\s*\{[^}]*?url\((https:[^)]+)\)/)||css.match(/url\((https:[^)]+)\)/);const buf=await(await fetch(m[1])).arrayBuffer();const ff=new FontFace(f.fam,buf);await ff.load();document.fonts.add(ff);webOk.add(f.fam)}catch(e){webPrev.delete(f.fam);webFail.add(f.fam)}buildFpop()}
(()=>{const P=$('#fpop'),B=$('#fnb'),close=()=>{P.hidden=true;B.setAttribute('aria-expanded','false')},keep=e=>e.preventDefault();
P.addEventListener('mousedown',keep);B.addEventListener('mousedown',keep);
B.onclick=()=>{if(!P.hidden)return close();FL.forEach(prevWeb);P.hidden=false;B.setAttribute('aria-expanded','true');const r=B.getBoundingClientRect(),w=P.offsetWidth,h=P.offsetHeight;P.style.left=Math.max(8,Math.min(r.left,innerWidth-w-8))+'px';const up=r.top-h-6>=8;P.style.top=(up?r.top-h-6:Math.min(r.bottom+6,innerHeight-h-8))+'px';fnRefresh();const on=P.querySelector('.fi.on');if(on)on.scrollIntoView({block:'nearest'})};
P.addEventListener('click',e=>{const b=e.target.closest('.fi');if(!b)return;const f=$('#fn');f.value=b.dataset.i;f.dispatchEvent(new Event('change'));close()});
addEventListener('pointerdown',e=>{if(!P.hidden&&!e.target.closest('#fpop,#fnb'))close()},true);addEventListener('keydown',e=>{if(e.key=='Escape'&&!P.hidden)close()});addEventListener('resize',close)})();
// ===== 追加のUI再配置: 下部の操作ボタン→上部 / 図形演算→上部(ベクター時のみ) / オニオン→下部 / コスチューム表示数 =====
(()=>{const T=$('#top'),mkG=(ids,id)=>{const g=document.createElement('span');g.className='grp';g.id=id;ids.forEach(i=>{const e=$('#'+i);g.append(e);const n=e.nextElementSibling;if(n&&n.tagName=='INPUT'&&n.type=='file')g.append(n)});return g};
const B=[['bmg','結合','結合: 複数の図形を一つの形状にまとめます。'],['bsb','型抜き','型抜き: 図形同士の重なりを利用して、背面の図形から前面の図形を取り除きます。'],['bmk','重なり','重なり部分: 複数の図形が重なっている部分だけを残します。'],['bft','排他','排他的領域: 重なっている部分を除き、それ以外の領域を残します。']];
B.forEach(([i,l,t])=>{const e=$('#'+i);e.dataset.l=l;e.dataset.t=t;e.title=t;e.setAttribute('aria-label',t)});
const gb=mkG(B.map(b=>b[0]),'g_bool');
const m1=$('#m1');if(m1){const h=m1.previousElementSibling;if(h&&h.tagName=='H4')h.remove();m1.remove()}
[['addf','追加'],['sysf','システム'],['te','編集']].forEach(([i,l])=>$('#'+i).dataset.l=l);const ft=mkG(['addf','ff','sysf','te','t2p','p2t'],'g_ftt');
const nd=mkG(['nl','nu','nd','nr'],'g_ndt');const rs_=$('#g_rsh');rs_.querySelectorAll('button').forEach(b=>{const l={delpt:'点削除',ptm:'角/曲線'}[b.id];if(l)b.dataset.l=l});[['bfh','左右反転'],['bfv','上下反転']].forEach(([i,l])=>$('#'+i).dataset.l=l);
Object.assign(IC,{offset:'<rect x="7" y="7" width="10" height="10" rx="1.5"/><rect x="3" y="3" width="18" height="18" rx="3" stroke-dasharray="3 2.5"/>'});const ob=document.createElement('button');ob.id='ofb';ob.dataset.i='offset';ob.dataset.l='オフセット';ob.dataset.t='オフセットパス: 選択した図形の輪郭を、内側または外側へ一定距離ずらした新しいパスを作ります。';ob.setAttribute('aria-haspopup','dialog');ob.onclick=()=>ofsToggle();const go=document.createElement('span');go.className='grp';go.id='g_ofs';go.append(ob);
const sp=T.querySelector('.fill');[gb,go,ft,rs_,$('#g_bo'),nd].forEach(g=>T.insertBefore(g,sp));
$('#prop').append($('#onion'));
// コスチューム表示数
window.lvnApply=()=>{const L=$('#list');if(!L)return;L.style.setProperty('--n',LVN);L.dataset.n=LVN;$('#lvv').textContent=LVN;$('#lvm').disabled=LVN<=1;$('#lvp').disabled=LVN>=12;const on=L.querySelector('.ci.on');if(on)on.scrollIntoView({block:'nearest',inline:'nearest'})};
const setN=n=>{LVN=Math.min(12,Math.max(1,n));lvnApply();uiSave()};$('#lvm').onclick=()=>setN(LVN-1);$('#lvp').onclick=()=>setN(LVN+1)})();
Object.assign(IC,{spadd:'<path d="M12 5v14M5 12h14"/>'});initIcons();fillFonts();buildPK();cs=[mk('v','コスチューム1')];SPS[0].cs=cs;go(0);spInit();refChips();
